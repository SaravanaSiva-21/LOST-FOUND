import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { logAudit, createNotification } from "@/lib/tce";
import { StatusBadge } from "@/components/StatusBadge";
import { Check, X, MessageSquareWarning, StickyNote, ChevronDown, ChevronUp } from "lucide-react";

type ReportRow = any;

export function AdminReportCard({ item, onChange }: { item: ReportRow; onChange: () => void }) {
  const [open, setOpen] = useState(false);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  const act = async (status: "approved" | "rejected", noteText?: string) => {
    setBusy(true);
    try {
      const patch: any = { status };
      if (noteText) patch.admin_notes = appendNote(item.admin_notes, noteText);
      const { error } = await supabase.from("items").update(patch).eq("id", item.id);
      if (error) throw error;
      await logAudit({ action: `item_${status}`, entity: "items", entity_id: item.id, metadata: { case_id: item.case_id } });
      if (item.reporter_id) {
        await createNotification({
          user_id: item.reporter_id,
          type: status === "approved" ? "report_approved" : "report_rejected",
          title: `Report ${status}`,
          message: `Your report ${item.case_id} has been ${status}.`,
          case_id: item.case_id,
        });
      }
      toast.success(`Report ${status}`);
      onChange();
    } catch (e: any) {
      toast.error(e.message ?? "Failed");
    } finally {
      setBusy(false);
    }
  };

  const requestInfo = async () => {
    if (!note.trim()) return toast.error("Add a note explaining what is needed");
    setBusy(true);
    try {
      const merged = appendNote(item.admin_notes, `[More info requested] ${note.trim()}`);
      const { error } = await supabase.from("items").update({ admin_notes: merged }).eq("id", item.id);
      if (error) throw error;
      await logAudit({ action: "item_more_info_requested", entity: "items", entity_id: item.id });
      if (item.reporter_id) {
        await createNotification({
          user_id: item.reporter_id,
          type: "more_info_requested",
          title: "More information requested",
          message: `Admin needs more info on ${item.case_id}: ${note.trim()}`,
          case_id: item.case_id,
        });
      }
      setNote("");
      toast.success("Request sent");
      onChange();
    } finally {
      setBusy(false);
    }
  };

  const savePrivateNote = async () => {
    if (!note.trim()) return;
    setBusy(true);
    try {
      const merged = appendNote(item.admin_notes, note.trim());
      const { error } = await supabase.from("items").update({ admin_notes: merged }).eq("id", item.id);
      if (error) throw error;
      await logAudit({ action: "item_note_added", entity: "items", entity_id: item.id });
      setNote("");
      toast.success("Note saved");
      onChange();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="rounded-2xl border border-border bg-card p-4 space-y-3">
      <div className="flex justify-between gap-3 flex-wrap">
        <div className="min-w-0">
          <div className="text-[11px] font-mono text-muted-foreground">{item.case_id}</div>
          <div className="font-medium truncate">{item.item_name}</div>
          <div className="text-xs text-muted-foreground">
            {item.category} · {item.general_location} · {item.incident_date}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className={`text-[10px] font-bold uppercase ${item.report_type === "lost" ? "text-red-600" : "text-emerald-600"}`}>{item.report_type}</span>
          <StatusBadge status={item.status} />
        </div>
      </div>

      <button onClick={() => setOpen((o) => !o)} className="text-xs text-muted-foreground inline-flex items-center gap-1 hover:text-foreground">
        {open ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />} {open ? "Hide details" : "Show details"}
      </button>

      {open && (
        <div className="space-y-3 border-t border-border pt-3">
          <DetailGrid item={item} />
          {item.image_urls?.length > 0 && (
            <div className="flex gap-2 flex-wrap">
              {item.image_urls.map((u: string, i: number) => (
                <div key={i} className="h-20 w-20 rounded-md bg-muted overflow-hidden">
                  <img src={u} alt="" className="h-full w-full object-cover" />
                </div>
              ))}
            </div>
          )}
          {item.admin_notes && (
            <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-3">
              <div className="text-[11px] font-semibold uppercase text-amber-700 dark:text-amber-400 mb-1">Private Notes</div>
              <pre className="text-xs whitespace-pre-wrap font-sans">{item.admin_notes}</pre>
            </div>
          )}
          <Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Add a private note or reason for rejection…" rows={2} />
          <div className="flex flex-wrap gap-2">
            <Button size="sm" disabled={busy} onClick={() => act("approved", note.trim() || undefined)} className="gap-1"><Check className="h-4 w-4" /> Approve</Button>
            <Button size="sm" disabled={busy} variant="destructive" onClick={() => act("rejected", note.trim() || undefined)} className="gap-1"><X className="h-4 w-4" /> Reject</Button>
            <Button size="sm" disabled={busy} variant="outline" onClick={requestInfo} className="gap-1"><MessageSquareWarning className="h-4 w-4" /> Request Info</Button>
            <Button size="sm" disabled={busy} variant="ghost" onClick={savePrivateNote} className="gap-1"><StickyNote className="h-4 w-4" /> Save Note</Button>
          </div>
        </div>
      )}
    </div>
  );
}

function DetailGrid({ item }: { item: ReportRow }) {
  const rows: [string, any][] = [
    ["Brand", item.brand],
    ["Colour", item.colour],
    ["Location", item.location],
    ["Marks", item.identification_marks],
    ["Reward", item.reward],
    ["Contact", item.contact_number],
    ["Current holder", item.current_holder],
    ["Description", item.description],
  ];
  return (
    <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
      {rows.filter(([, v]) => v).map(([k, v]) => (
        <div key={k}>
          <dt className="text-muted-foreground">{k}</dt>
          <dd className="text-foreground">{v}</dd>
        </div>
      ))}
    </dl>
  );
}

function appendNote(existing: string | null, note: string) {
  const stamp = new Date().toISOString();
  const line = `[${stamp}] ${note}`;
  return existing ? `${existing}\n${line}` : line;
}