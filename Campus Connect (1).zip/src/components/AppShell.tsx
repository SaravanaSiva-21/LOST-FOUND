import { Link, useRouter } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { Bell, LayoutDashboard, LogOut, Menu, Moon, Sun, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useTheme } from "@/hooks/useTheme";
import { Logo } from "./Logo";
import { APP_NAME, COLLEGE_NAME } from "@/lib/tce";
import { Button } from "@/components/ui/button";

export function AppShell({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const { theme, toggle } = useTheme();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("notifications")
      .select("id", { count: "exact", head: true })
      .eq("user_id", user.id)
      .eq("read", false)
      .then(({ count }) => setUnread(count ?? 0));
  }, [user]);

  const publicLinks = [
    { to: "/", label: "Home" },
    { to: "/search", label: "Search" },
    { to: "/about", label: "About" },
  ];

  const signOut = async () => {
    await supabase.auth.signOut();
    router.navigate({ to: "/" });
  };

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur-xl">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 h-16 flex items-center gap-4">
          <Link to="/" className="flex items-center gap-3 min-w-0">
            <Logo size={36} />
            <div className="hidden sm:flex flex-col leading-tight">
              <span className="text-sm font-semibold tracking-tight">{APP_NAME}</span>
              <span className="text-[11px] text-muted-foreground">TCE Madurai</span>
            </div>
          </Link>
          <nav className="hidden md:flex items-center gap-1 ml-6">
            {publicLinks.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                className="px-3 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
                activeProps={{ className: "text-foreground bg-accent" }}
              >
                {l.label}
              </Link>
            ))}
          </nav>
          <div className="flex-1" />
          <button
            onClick={toggle}
            className="h-9 w-9 grid place-items-center rounded-lg hover:bg-accent transition-colors"
            aria-label="Toggle theme"
          >
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>
          {user ? (
            <>
              <Link
                to="/dashboard/notifications"
                className="relative h-9 w-9 grid place-items-center rounded-lg hover:bg-accent transition-colors"
                aria-label="Notifications"
              >
                <Bell className="h-4 w-4" />
                {unread > 0 && (
                  <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-destructive" />
                )}
              </Link>
              <Link to="/dashboard">
                <Button size="sm" variant="secondary" className="hidden sm:inline-flex gap-2">
                  <LayoutDashboard className="h-4 w-4" /> Dashboard
                </Button>
              </Link>
              <button
                onClick={signOut}
                className="hidden sm:inline-flex h-9 w-9 items-center justify-center rounded-lg hover:bg-accent"
                aria-label="Sign out"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </>
          ) : (
            <>
              <Link to="/auth" search={{ tab: "login" }} className="hidden sm:inline-flex">
                <Button size="sm" variant="ghost">Login</Button>
              </Link>
              <Link to="/auth" search={{ tab: "register" }} className="hidden sm:inline-flex">
                <Button size="sm">Register</Button>
              </Link>
            </>
          )}
          <button
            className="md:hidden h-9 w-9 grid place-items-center rounded-lg hover:bg-accent"
            onClick={() => setOpen(!open)}
            aria-label="Menu"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
        {open && (
          <div className="md:hidden border-t border-border px-4 py-3 space-y-1 bg-background">
            {publicLinks.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                className="block px-3 py-2 rounded-lg text-sm hover:bg-accent"
              >
                {l.label}
              </Link>
            ))}
            {user ? (
              <>
                <Link
                  to="/dashboard"
                  onClick={() => setOpen(false)}
                  className="block px-3 py-2 rounded-lg text-sm hover:bg-accent"
                >
                  Dashboard
                </Link>
                <button
                  onClick={signOut}
                  className="w-full text-left px-3 py-2 rounded-lg text-sm hover:bg-accent"
                >
                  Sign out
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/auth"
                  search={{ tab: "login" }}
                  onClick={() => setOpen(false)}
                  className="block px-3 py-2 rounded-lg text-sm hover:bg-accent"
                >
                  Login
                </Link>
                <Link
                  to="/auth"
                  search={{ tab: "register" }}
                  onClick={() => setOpen(false)}
                  className="block px-3 py-2 rounded-lg text-sm hover:bg-accent"
                >
                  Register
                </Link>
              </>
            )}
          </div>
        )}
      </header>
      <main className="flex-1">{children}</main>
      <footer className="border-t border-border bg-secondary/40 mt-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-10 grid gap-8 md:grid-cols-4">
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-3">
              <Logo size={36} />
              <div>
                <div className="font-semibold">{APP_NAME}</div>
                <div className="text-xs text-muted-foreground">{COLLEGE_NAME}</div>
              </div>
            </div>
            <p className="text-sm text-muted-foreground max-w-md">
              A secure, admin-verified portal for students and faculty to report and recover lost items on campus.
            </p>
          </div>
          <div>
            <div className="text-xs font-semibold uppercase tracking-[0.15em] text-muted-foreground mb-3">Portal</div>
            <ul className="space-y-2 text-sm">
              <li><Link to="/" className="hover:text-foreground text-muted-foreground">Home</Link></li>
              <li><Link to="/search" className="hover:text-foreground text-muted-foreground">Search</Link></li>
              <li><Link to="/about" className="hover:text-foreground text-muted-foreground">About</Link></li>
            </ul>
          </div>
          <div>
            <div className="text-xs font-semibold uppercase tracking-[0.15em] text-muted-foreground mb-3">Legal</div>
            <ul className="space-y-2 text-sm">
              <li><Link to="/about" hash="privacy" className="hover:text-foreground text-muted-foreground">Privacy Policy</Link></li>
              <li><Link to="/about" hash="terms" className="hover:text-foreground text-muted-foreground">Terms of Use</Link></li>
              <li><Link to="/about" hash="disclaimer" className="hover:text-foreground text-muted-foreground">Disclaimer</Link></li>
              <li><Link to="/about" hash="contact" className="hover:text-foreground text-muted-foreground">Contact</Link></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-border">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 py-4 text-xs text-muted-foreground flex flex-wrap gap-2 justify-between">
            <span>© {new Date().getFullYear()} Thiagarajar College of Engineering — All rights reserved.</span>
            <span>Developed for TCE, Madurai.</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
