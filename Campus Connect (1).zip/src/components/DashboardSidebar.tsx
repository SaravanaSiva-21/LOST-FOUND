import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Activity,
  Bell,
  ClipboardList,
  FileSearch,
  Home,
  ListChecks,
  Mail,
  Search,
  Settings as SettingsIcon,
  Shield,
  User,
  Users,
  History,
  BarChart3,
  Bookmark,
  Archive,
  Star,
  Download,
  GitCompare,
  Handshake,
  Building2,
  LineChart as LineIcon,
  Database,
  Activity as ActivityIcon,
  Contact,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export function DashboardSidebar() {
  const { user, isAdmin } = useAuth();
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    if (!user) return;
    let alive = true;
    const refresh = async () => {
      const { count } = await supabase
        .from("notifications")
        .select("id", { count: "exact", head: true })
        .eq("user_id", user.id)
        .eq("read", false);
      if (alive) setUnread(count ?? 0);
    };
    refresh();
    const ch = supabase
      .channel(`sidebar-notif-${user.id}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "notifications", filter: `user_id=eq.${user.id}` },
        refresh,
      )
      .subscribe();
    return () => {
      alive = false;
      supabase.removeChannel(ch);
    };
  }, [user?.id]);

  const studentLinks = [
    { to: "/dashboard", label: "Overview", icon: Home },
    { to: "/dashboard/report-lost", label: "Report Lost", icon: FileSearch },
    { to: "/dashboard/report-found", label: "Report Found", icon: ClipboardList },
    { to: "/dashboard/search", label: "Search Items", icon: Search },
    { to: "/dashboard/my-reports", label: "My Reports", icon: ListChecks },
    { to: "/dashboard/my-claims", label: "My Claims", icon: Mail },
    { to: "/dashboard/shared-contacts", label: "Shared User Details", icon: Contact },
    { to: "/dashboard/bookmarks", label: "Bookmarks", icon: Bookmark },
    { to: "/dashboard/archive", label: "Archive", icon: Archive },
    { to: "/dashboard/notifications", label: "Notifications", icon: Bell, badge: unread },
    { to: "/dashboard/activity", label: "Activity", icon: Activity },
    { to: "/dashboard/profile", label: "Profile", icon: User },
    { to: "/dashboard/settings", label: "Settings", icon: SettingsIcon },
  ];

  const adminLinks = [
    { to: "/dashboard/admin", label: "Admin Overview", icon: BarChart3 },
    { to: "/dashboard/admin/lost", label: "Lost Reports", icon: FileSearch },
    { to: "/dashboard/admin/found", label: "Found Reports", icon: ClipboardList },
    { to: "/dashboard/admin/claims", label: "Claims", icon: Shield },
    { to: "/dashboard/admin/matches", label: "Potential Matches", icon: GitCompare },
    { to: "/dashboard/admin/handover", label: "Handover Confirmation", icon: Handshake },
    { to: "/dashboard/admin/users", label: "Users", icon: Users },
    { to: "/dashboard/admin/whitelist", label: "Approved Emails", icon: Mail },
    { to: "/dashboard/admin/departments", label: "Departments", icon: Building2 },
    { to: "/dashboard/admin/notifications", label: "Notifications", icon: Bell },
    { to: "/dashboard/admin/analytics", label: "Analytics", icon: LineIcon },
    { to: "/dashboard/admin/feedback", label: "Feedback", icon: Star },
    { to: "/dashboard/admin/reports", label: "Reports", icon: Download },
    { to: "/dashboard/admin/export", label: "Quick Export", icon: Download },
    { to: "/dashboard/admin/audit", label: "Audit Logs", icon: History },
    { to: "/dashboard/admin/health", label: "System Health", icon: ActivityIcon },
    { to: "/dashboard/admin/backups", label: "Backups", icon: Database },
    { to: "/dashboard/admin/settings", label: "System Settings", icon: SettingsIcon },
  ];

  return (
    <aside className="lg:sticky lg:top-20 lg:self-start rounded-2xl border border-border bg-card p-3 space-y-1 h-fit">
      <div className="text-[11px] font-semibold uppercase tracking-[0.15em] text-muted-foreground px-3 pt-2 pb-1">
        Menu
      </div>
      {studentLinks.map((l) => (
        <SideLink key={l.to} to={l.to} label={l.label} Icon={l.icon} badge={l.badge} />
      ))}
      {isAdmin && (
        <>
          <div className="text-[11px] font-semibold uppercase tracking-[0.15em] text-muted-foreground px-3 pt-4 pb-1">
            Administrator
          </div>
          {adminLinks.map((l) => (
            <SideLink key={l.to} to={l.to} label={l.label} Icon={l.icon} />
          ))}
        </>
      )}
    </aside>
  );
}

function SideLink({ to, label, Icon, badge }: { to: string; label: string; Icon: any; badge?: number }) {
  return (
    <Link
      to={to}
      className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
      activeOptions={{ exact: to === "/dashboard" }}
      activeProps={{ className: "bg-primary/10 text-primary hover:bg-primary/10" }}
    >
      <Icon className="h-4 w-4" />
      <span className="flex-1">{label}</span>
      {typeof badge === "number" && badge > 0 && (
        <span className="inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full bg-primary text-primary-foreground text-[10px] font-semibold">
          {badge > 99 ? "99+" : badge}
        </span>
      )}
    </Link>
  );
}