import { AlertTriangle } from "lucide-react";
import { useState } from "react";
import { Checkbox } from "@/components/ui/checkbox";

export function DisclaimerBox({
  onAgreeChange,
  agreed,
}: {
  onAgreeChange: (v: boolean) => void;
  agreed: boolean;
}) {
  return (
    <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 space-y-3">
      <div className="flex items-start gap-3">
        <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-400 mt-0.5" />
        <div className="space-y-2 text-sm">
          <div className="font-semibold text-foreground">Disclaimer & User Agreement</div>
          <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
            <li>False reports or claims are strictly prohibited.</li>
            <li>Misuse may result in disciplinary action by the college.</li>
            <li>Your personal information is protected and shared only after mutual consent and administrator verification.</li>
            <li>All activity on this portal is logged for audit purposes.</li>
            <li>The administrator has authority to verify, reject, or archive any report or claim.</li>
          </ul>
        </div>
      </div>
      <label className="flex items-start gap-3 text-sm cursor-pointer">
        <Checkbox
          checked={agreed}
          onCheckedChange={(v) => onAgreeChange(Boolean(v))}
          className="mt-0.5"
        />
        <span className="text-foreground">
          I confirm that all information provided is true and accurate, and I agree to the terms above.
        </span>
      </label>
    </div>
  );
}

export function useAgreement() {
  const [agreed, setAgreed] = useState(false);
  return { agreed, setAgreed };
}
