import { GraduationCap } from "lucide-react";

export function Logo({ size = 36 }: { size?: number }) {
  return (
    <div
      className="flex items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm"
      style={{ width: size, height: size }}
    >
      <GraduationCap style={{ width: size * 0.6, height: size * 0.6 }} strokeWidth={2.2} />
    </div>
  );
}
