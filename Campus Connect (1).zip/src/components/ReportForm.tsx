import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { CheckCircle2, Loader2, Upload, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { DisclaimerBox } from "@/components/DisclaimerBox";
import { GENERAL_LOCATIONS, ITEM_CATEGORIES, createNotification, logAudit } from "@/lib/tce";
import {
  ALLOWED_IMAGE_TYPES,
  MAX_IMAGES,
  compressImage,
  validateImageFile,
} from "@/lib/image";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export function ReportForm({ type }: { type: "lost" | "found" }) {
  const nav = useNavigate();
  const { user, profile } = useAuth();
  const [agreed, setAgreed] = useState(false);
  const [saving, setSaving] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [duplicateWarning, setDuplicateWarning] = useState<string | null>(null);
  const [showDupConfirm, setShowDupConfirm] = useState(false);
  const [submitted, setSubmitted] = useState<{ caseId: string; id: string } | null>(null);
  const [f, setF] = useState({
    item_name: "",
    category: "",
    brand: "",
    colour: "",
    description: "",
    identification_marks: "",
    incident_date: new Date().toISOString().slice(0, 10),
    incident_time: "",
    location: "",
    general_location: "",
    reward: "",
    contact_number: "",
    current_holder: "",
  });

  useEffect(() => {
    if (profile?.phone && !f.contact_number) setF((s) => ({ ...s, contact_number: profile.phone ?? "" }));
  }, [profile]);

  // Duplicate detection: check by name+category+date
  useEffect(() => {
    if (!user || !f.item_name || !f.category) {
      setDuplicateWarning(null);
      return;
    }
    const t = setTimeout(async () => {
      const { data } = await supabase
        .from("items")
        .select("id,case_id")
        .eq("reporter_id", user.id)
        .eq("report_type", type)
        .ilike("item_name", `%${f.item_name}%`)
        .eq("category", f.category)
        .limit(1);
      if (data && data.length > 0) {
        setDuplicateWarning(`You may have already reported a similar item (${data[0].case_id}). Please review before submitting.`);
      } else {
        setDuplicateWarning(null);
      }
    }, 500);
    return () => clearTimeout(t);
  }, [user, type, f.item_name, f.category]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!agreed) return toast.error("You must accept the disclaimer.");
    if (!f.item_name || !f.category || !f.description || !f.location || !f.general_location || !f.contact_number) {
      return toast.error("Please fill all required fields.");
    }
    if (duplicateWarning && !showDupConfirm) {
      // Show confirm dialog once; user can choose to continue.
      setShowDupConfirm(true);
      return;
    }
    setSaving(true);
    try {
      // Generate case ID
      const { data: cid, error: cidErr } = await supabase.rpc("generate_case_id", { _type: type });
      if (cidErr) throw cidErr;

      // Upload images (compressed) to dedicated bucket
      const bucket = type === "lost" ? "lost-items" : "found-items";
      const imageUrls: string[] = [];
      for (const file of files) {
        const compressed = await compressImage(file);
        const safeName = compressed.name.replace(/[^a-zA-Z0-9._-]/g, "_");
        const path = `${user.id}/${cid}/${Date.now()}-${safeName}`;
        const { error: upErr } = await supabase.storage
          .from(bucket)
          .upload(path, compressed, { upsert: false, contentType: compressed.type });
        if (upErr) throw upErr;
        imageUrls.push(path);
      }

      const { data: inserted, error } = await supabase
        .from("items")
        .insert({
          case_id: cid as unknown as string,
          report_type: type,
          reporter_id: user.id,
          item_name: f.item_name.trim(),
          category: f.category,
          brand: f.brand.trim() || null,
          colour: f.colour.trim() || null,
          description: f.description.trim(),
          identification_marks: f.identification_marks.trim() || null,
          incident_date: f.incident_date,
          incident_time: f.incident_time || null,
          location: f.location.trim(),
          general_location: f.general_location,
          reward: type === "lost" ? f.reward.trim() || null : null,
          contact_number: f.contact_number.trim(),
          current_holder: type === "found" ? f.current_holder.trim() || null : null,
          image_urls: imageUrls,
        })
        .select("id,case_id")
        .single();
      if (error) throw error;

      await createNotification({
        user_id: user.id,
        type: "report_submitted",
        title: `${type === "lost" ? "Lost" : "Found"} report submitted`,
        message: `Your report ${inserted.case_id} is pending administrator verification.`,
        case_id: inserted.case_id,
      });
      await logAudit({ action: `report_${type}_submitted`, entity: "item", entity_id: inserted.id, metadata: { case_id: inserted.case_id } });

      toast.success(`Report ${inserted.case_id} submitted for verification.`);
      setSubmitted({ caseId: inserted.case_id, id: inserted.id });
    } catch (err: any) {
      toast.error(err.message ?? "Failed to submit report");
    } finally {
      setSaving(false);
      setShowDupConfirm(false);
    }
  };

  const onFilesPicked = (list: FileList | null) => {
    if (!list) return;
    const incoming = Array.from(list);
    const accepted: File[] = [];
    for (const file of incoming) {
      const err = validateImageFile(file);
      if (err) {
        toast.error(err);
        continue;
      }
      accepted.push(file);
    }
    const combined = [...files, ...accepted].slice(0, MAX_IMAGES);
    if (files.length + accepted.length > MAX_IMAGES) {
      toast.warning(`You can upload up to ${MAX_IMAGES} images. Extra files ignored.`);
    }
    setFiles(combined);
  };

  if (submitted) {
    return (
      <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/5 p-8 text-center space-y-4">
        <div className="mx-auto h-14 w-14 rounded-full bg-emerald-500/15 grid place-items-center">
          <CheckCircle2 className="h-8 w-8 text-emerald-600 dark:text-emerald-400" />
        </div>
        <div>
          <h2 className="text-xl font-bold">Report submitted successfully</h2>
          <p className="text-sm text-muted-foreground mt-2">
            Your case ID is <span className="font-mono font-semibold text-foreground">{submitted.caseId}</span>.<br />
            An administrator will review your submission and update the status shortly.
          </p>
        </div>
        <div className="flex flex-wrap justify-center gap-2">
          <Button asChild variant="outline">
            <Link to="/dashboard/my-reports">View my reports</Link>
          </Button>
          <Button asChild>
            <Link to="/dashboard/case/$id" params={{ id: submitted.id }}>Open case</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-6">
      <DisclaimerBox agreed={agreed} onAgreeChange={setAgreed} />
      {duplicateWarning && (
        <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-3 text-sm text-amber-800 dark:text-amber-300">
          {duplicateWarning}
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-4">
        <Fld label="Item Name *" v={f.item_name} on={(v) => setF({ ...f, item_name: v })} />
        <div className="space-y-1.5">
          <Label>Category *</Label>
          <select value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm">
            <option value="">Select</option>
            {ITEM_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <Fld label="Brand" v={f.brand} on={(v) => setF({ ...f, brand: v })} />
        <Fld label="Colour" v={f.colour} on={(v) => setF({ ...f, colour: v })} />
        <div className="md:col-span-2 space-y-1.5">
          <Label>Description *</Label>
          <Textarea rows={3} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
        </div>
        <div className="md:col-span-2 space-y-1.5">
          <Label>Unique Identification Marks</Label>
          <Textarea rows={2} value={f.identification_marks} onChange={(e) => setF({ ...f, identification_marks: e.target.value })} placeholder="Distinguishing features only the owner would know" />
        </div>
        <Fld label={`${type === "lost" ? "Lost" : "Found"} Date *`} type="date" v={f.incident_date} on={(v) => setF({ ...f, incident_date: v })} />
        <Fld label={`${type === "lost" ? "Lost" : "Found"} Time`} type="time" v={f.incident_time} on={(v) => setF({ ...f, incident_time: v })} />
        <div className="space-y-1.5">
          <Label>General Location *</Label>
          <select value={f.general_location} onChange={(e) => setF({ ...f, general_location: e.target.value })} className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm">
            <option value="">Select area</option>
            {GENERAL_LOCATIONS.map((l) => <option key={l} value={l}>{l}</option>)}
          </select>
        </div>
        <Fld label="Approximate / Exact Location *" v={f.location} on={(v) => setF({ ...f, location: v })} placeholder="Room, hall, seat, etc." />
        {type === "lost" && <Fld label="Reward (optional)" v={f.reward} on={(v) => setF({ ...f, reward: v })} />}
        {type === "found" && <Fld label="Current Holder / Handed to" v={f.current_holder} on={(v) => setF({ ...f, current_holder: v })} placeholder="Security office, self, etc." />}
        <Fld label="Contact Number *" v={f.contact_number} on={(v) => setF({ ...f, contact_number: v })} />
      </div>

      <div className="space-y-2">
        <Label>Upload Images (JPG / PNG, max 5, up to 5 MB each)</Label>
        <label className="flex flex-col items-center justify-center border-2 border-dashed border-border rounded-xl p-6 cursor-pointer hover:border-primary/40 transition-colors">
          <Upload className="h-6 w-6 text-muted-foreground mb-2" />
          <span className="text-sm text-muted-foreground">Click to upload photos</span>
          <input
            type="file"
            accept={ALLOWED_IMAGE_TYPES.join(",")}
            multiple
            className="hidden"
            onChange={(e) => {
              onFilesPicked(e.target.files);
              e.currentTarget.value = "";
            }}
          />
        </label>
        {files.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {files.map((file, i) => (
              <div key={i} className="relative">
                <img src={URL.createObjectURL(file)} className="h-16 w-16 object-cover rounded-lg border border-border" alt="" />
                <button type="button" onClick={() => setFiles(files.filter((_, j) => j !== i))} className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-destructive text-destructive-foreground grid place-items-center">
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      <Button type="submit" disabled={saving || !agreed} className="w-full">
        {saving ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Submitting...</> : `Submit ${type === "lost" ? "Lost" : "Found"} Report`}
      </Button>

      <AlertDialog open={showDupConfirm} onOpenChange={setShowDupConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Similar report already exists</AlertDialogTitle>
            <AlertDialogDescription>
              {duplicateWarning} Do you still want to continue and submit this new report?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                setShowDupConfirm(false);
                // Re-invoke submit programmatically bypassing the guard.
                submit(new Event("submit") as any);
              }}
            >
              Yes, submit anyway
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </form>
  );
}

function Fld({ label, v, on, type = "text", placeholder }: { label: string; v: string; on: (v: string) => void; type?: string; placeholder?: string }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      <Input type={type} value={v} onChange={(e) => on(e.target.value)} placeholder={placeholder} />
    </div>
  );
}