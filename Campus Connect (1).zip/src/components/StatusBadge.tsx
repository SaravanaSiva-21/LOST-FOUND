import { classify } from "@/lib/tce";

export function StatusBadge({ status }: { status: string }) {
  const { label, tone } = classify(status);
  return (
    <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium ${tone}`}>
      {label}
    </span>
  );
}
