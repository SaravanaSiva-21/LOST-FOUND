import { useEffect, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export type AppRole = "student" | "admin";

export interface AuthProfile {
  id: string;
  full_name: string;
  register_no: string | null;
  department: string | null;
  email: string;
  phone: string | null;
  photo_url: string | null;
  is_suspended: boolean;
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<AuthProfile | null>(null);
  const [role, setRole] = useState<AppRole | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    const load = async (u: User | null) => {
      if (!u) {
        if (mounted) {
          setUser(null);
          setProfile(null);
          setRole(null);
          setLoading(false);
        }
        return;
      }
      const [{ data: p }, { data: r }] = await Promise.all([
        supabase.from("profiles").select("*").eq("id", u.id).maybeSingle(),
        supabase.from("user_roles").select("role").eq("user_id", u.id).maybeSingle(),
      ]);
      if (!mounted) return;
      setUser(u);
      setProfile((p as AuthProfile) ?? null);
      setRole((r?.role as AppRole) ?? null);
      setLoading(false);
    };

    supabase.auth.getUser().then(({ data }) => load(data.user));

    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_OUT") {
        setUser(null);
        setProfile(null);
        setRole(null);
        setLoading(false);
        return;
      }
      if (session?.user) load(session.user);
    });
    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  return { user, profile, role, loading, isAdmin: role === "admin" };
}
