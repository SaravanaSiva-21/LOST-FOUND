export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      audit_logs: {
        Row: {
          action: string
          created_at: string
          entity: string | null
          entity_id: string | null
          id: string
          ip_address: string | null
          metadata: Json | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          entity?: string | null
          entity_id?: string | null
          id?: string
          ip_address?: string | null
          metadata?: Json | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          entity?: string | null
          entity_id?: string | null
          id?: string
          ip_address?: string | null
          metadata?: Json | null
          user_id?: string | null
        }
        Relationships: []
      }
      backups: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          name: string
          notes: string | null
          restored_at: string | null
          restored_by: string | null
          size_bytes: number
          status: string
          table_counts: Json
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          name: string
          notes?: string | null
          restored_at?: string | null
          restored_by?: string | null
          size_bytes?: number
          status?: string
          table_counts?: Json
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          name?: string
          notes?: string | null
          restored_at?: string | null
          restored_by?: string | null
          size_bytes?: number
          status?: string
          table_counts?: Json
          updated_at?: string
        }
        Relationships: []
      }
      bookmarks: {
        Row: {
          created_at: string
          id: string
          item_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          item_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          item_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bookmarks_item_id_fkey"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "items"
            referencedColumns: ["id"]
          },
        ]
      }
      claims: {
        Row: {
          additional_desc: string | null
          admin_notes: string | null
          approx_date: string | null
          approx_location: string | null
          approx_time: string | null
          brand: string | null
          case_id: string
          claimant_id: string
          claimant_reveal_ok: boolean
          colour: string | null
          contact_revealed: boolean
          contact_shared_at: string | null
          contact_shared_by: string | null
          created_at: string
          finder_confirm_remarks: string | null
          finder_confirmed: boolean
          finder_confirmed_at: string | null
          id: string
          identification_marks: string | null
          item_id: string
          owner_confirm_remarks: string | null
          owner_confirmed: boolean
          owner_confirmed_at: string | null
          proof_urls: string[]
          reason: string
          reminder_sent: boolean
          reminder_sent_at: string | null
          reporter_reveal_ok: boolean
          resolved_at: string | null
          status: Database["public"]["Enums"]["claim_status"]
          updated_at: string
        }
        Insert: {
          additional_desc?: string | null
          admin_notes?: string | null
          approx_date?: string | null
          approx_location?: string | null
          approx_time?: string | null
          brand?: string | null
          case_id: string
          claimant_id: string
          claimant_reveal_ok?: boolean
          colour?: string | null
          contact_revealed?: boolean
          contact_shared_at?: string | null
          contact_shared_by?: string | null
          created_at?: string
          finder_confirm_remarks?: string | null
          finder_confirmed?: boolean
          finder_confirmed_at?: string | null
          id?: string
          identification_marks?: string | null
          item_id: string
          owner_confirm_remarks?: string | null
          owner_confirmed?: boolean
          owner_confirmed_at?: string | null
          proof_urls?: string[]
          reason: string
          reminder_sent?: boolean
          reminder_sent_at?: string | null
          reporter_reveal_ok?: boolean
          resolved_at?: string | null
          status?: Database["public"]["Enums"]["claim_status"]
          updated_at?: string
        }
        Update: {
          additional_desc?: string | null
          admin_notes?: string | null
          approx_date?: string | null
          approx_location?: string | null
          approx_time?: string | null
          brand?: string | null
          case_id?: string
          claimant_id?: string
          claimant_reveal_ok?: boolean
          colour?: string | null
          contact_revealed?: boolean
          contact_shared_at?: string | null
          contact_shared_by?: string | null
          created_at?: string
          finder_confirm_remarks?: string | null
          finder_confirmed?: boolean
          finder_confirmed_at?: string | null
          id?: string
          identification_marks?: string | null
          item_id?: string
          owner_confirm_remarks?: string | null
          owner_confirmed?: boolean
          owner_confirmed_at?: string | null
          proof_urls?: string[]
          reason?: string
          reminder_sent?: boolean
          reminder_sent_at?: string | null
          reporter_reveal_ok?: boolean
          resolved_at?: string | null
          status?: Database["public"]["Enums"]["claim_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "claims_claimant_id_fkey"
            columns: ["claimant_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "claims_item_id_fkey"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "items"
            referencedColumns: ["id"]
          },
        ]
      }
      departments: {
        Row: {
          code: string
          created_at: string
          id: string
          name: string
        }
        Insert: {
          code: string
          created_at?: string
          id?: string
          name: string
        }
        Update: {
          code?: string
          created_at?: string
          id?: string
          name?: string
        }
        Relationships: []
      }
      faqs: {
        Row: {
          active: boolean
          answer: string
          created_at: string
          id: string
          question: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          active?: boolean
          answer: string
          created_at?: string
          id?: string
          question: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          active?: boolean
          answer?: string
          created_at?: string
          id?: string
          question?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      feedback: {
        Row: {
          claim_id: string
          comment: string | null
          created_at: string
          id: string
          rating: number
          recommend: boolean | null
          suggestions: string | null
          user_id: string
        }
        Insert: {
          claim_id: string
          comment?: string | null
          created_at?: string
          id?: string
          rating: number
          recommend?: boolean | null
          suggestions?: string | null
          user_id: string
        }
        Update: {
          claim_id?: string
          comment?: string | null
          created_at?: string
          id?: string
          rating?: number
          recommend?: boolean | null
          suggestions?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "feedback_claim_id_fkey"
            columns: ["claim_id"]
            isOneToOne: false
            referencedRelation: "claims"
            referencedColumns: ["id"]
          },
        ]
      }
      items: {
        Row: {
          admin_notes: string | null
          brand: string | null
          case_id: string
          category: string
          colour: string | null
          contact_number: string
          created_at: string
          current_holder: string | null
          description: string
          general_location: string
          id: string
          identification_marks: string | null
          image_urls: string[]
          incident_date: string
          incident_time: string | null
          item_name: string
          location: string
          report_type: Database["public"]["Enums"]["report_type"]
          reporter_id: string
          reward: string | null
          status: Database["public"]["Enums"]["item_status"]
          updated_at: string
        }
        Insert: {
          admin_notes?: string | null
          brand?: string | null
          case_id: string
          category: string
          colour?: string | null
          contact_number: string
          created_at?: string
          current_holder?: string | null
          description: string
          general_location: string
          id?: string
          identification_marks?: string | null
          image_urls?: string[]
          incident_date: string
          incident_time?: string | null
          item_name: string
          location: string
          report_type: Database["public"]["Enums"]["report_type"]
          reporter_id: string
          reward?: string | null
          status?: Database["public"]["Enums"]["item_status"]
          updated_at?: string
        }
        Update: {
          admin_notes?: string | null
          brand?: string | null
          case_id?: string
          category?: string
          colour?: string | null
          contact_number?: string
          created_at?: string
          current_holder?: string | null
          description?: string
          general_location?: string
          id?: string
          identification_marks?: string | null
          image_urls?: string[]
          incident_date?: string
          incident_time?: string | null
          item_name?: string
          location?: string
          report_type?: Database["public"]["Enums"]["report_type"]
          reporter_id?: string
          reward?: string | null
          status?: Database["public"]["Enums"]["item_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "items_reporter_id_fkey"
            columns: ["reporter_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          case_id: string | null
          created_at: string
          id: string
          link: string | null
          message: string
          read: boolean
          title: string
          type: Database["public"]["Enums"]["notification_type"]
          user_id: string
        }
        Insert: {
          case_id?: string | null
          created_at?: string
          id?: string
          link?: string | null
          message: string
          read?: boolean
          title: string
          type: Database["public"]["Enums"]["notification_type"]
          user_id: string
        }
        Update: {
          case_id?: string | null
          created_at?: string
          id?: string
          link?: string | null
          message?: string
          read?: boolean
          title?: string
          type?: Database["public"]["Enums"]["notification_type"]
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          department: string | null
          email: string
          full_name: string
          id: string
          is_suspended: boolean
          phone: string | null
          photo_url: string | null
          register_no: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          department?: string | null
          email: string
          full_name?: string
          id: string
          is_suspended?: boolean
          phone?: string | null
          photo_url?: string | null
          register_no?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          department?: string | null
          email?: string
          full_name?: string
          id?: string
          is_suspended?: boolean
          phone?: string | null
          photo_url?: string | null
          register_no?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      search_history: {
        Row: {
          created_at: string
          id: string
          keyword: string | null
          kind: string
          user_id: string
          viewed_item_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          keyword?: string | null
          kind: string
          user_id: string
          viewed_item_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          keyword?: string | null
          kind?: string
          user_id?: string
          viewed_item_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "search_history_viewed_item_id_fkey"
            columns: ["viewed_item_id"]
            isOneToOne: false
            referencedRelation: "items"
            referencedColumns: ["id"]
          },
        ]
      }
      system_settings: {
        Row: {
          key: string
          updated_at: string
          updated_by: string | null
          value: Json
        }
        Insert: {
          key: string
          updated_at?: string
          updated_by?: string | null
          value?: Json
        }
        Update: {
          key?: string
          updated_at?: string
          updated_by?: string | null
          value?: Json
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      whitelist_emails: {
        Row: {
          created_at: string
          created_by: string | null
          email: string
          id: string
          notes: string | null
          role: Database["public"]["Enums"]["app_role"]
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          email: string
          id?: string
          notes?: string | null
          role?: Database["public"]["Enums"]["app_role"]
        }
        Update: {
          created_at?: string
          created_by?: string | null
          email?: string
          id?: string
          notes?: string | null
          role?: Database["public"]["Enums"]["app_role"]
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      generate_case_id: {
        Args: { _type: Database["public"]["Enums"]["report_type"] }
        Returns: string
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      notify_all_admins: {
        Args: {
          _case_id?: string
          _link?: string
          _message: string
          _title: string
          _type: Database["public"]["Enums"]["notification_type"]
        }
        Returns: undefined
      }
      send_handover_reminders: { Args: never; Returns: undefined }
    }
    Enums: {
      app_role: "student" | "admin"
      claim_status:
        | "pending"
        | "approved"
        | "rejected"
        | "more_info"
        | "withdrawn"
        | "under_review"
        | "contact_shared"
        | "meeting_scheduled"
        | "completed"
        | "resolved"
      item_status:
        | "pending_verification"
        | "approved"
        | "rejected"
        | "matched"
        | "claimed"
        | "handed_over"
        | "resolved"
        | "archived"
      notification_type:
        | "registration"
        | "password_reset"
        | "report_submitted"
        | "report_approved"
        | "report_rejected"
        | "claim_submitted"
        | "claim_approved"
        | "claim_rejected"
        | "more_info_requested"
        | "possible_match"
        | "meeting_scheduled"
        | "contact_reveal_request"
        | "contact_revealed"
        | "item_handed_over"
        | "item_received"
        | "case_resolved"
        | "generic"
        | "handover_reminder"
      report_type: "lost" | "found"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["student", "admin"],
      claim_status: [
        "pending",
        "approved",
        "rejected",
        "more_info",
        "withdrawn",
        "under_review",
        "contact_shared",
        "meeting_scheduled",
        "completed",
        "resolved",
      ],
      item_status: [
        "pending_verification",
        "approved",
        "rejected",
        "matched",
        "claimed",
        "handed_over",
        "resolved",
        "archived",
      ],
      notification_type: [
        "registration",
        "password_reset",
        "report_submitted",
        "report_approved",
        "report_rejected",
        "claim_submitted",
        "claim_approved",
        "claim_rejected",
        "more_info_requested",
        "possible_match",
        "meeting_scheduled",
        "contact_reveal_request",
        "contact_revealed",
        "item_handed_over",
        "item_received",
        "case_resolved",
        "generic",
        "handover_reminder",
      ],
      report_type: ["lost", "found"],
    },
  },
} as const
