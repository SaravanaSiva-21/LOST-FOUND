// Client-side image utilities: validation + compression

export const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/jpg", "image/png"];
export const MAX_IMAGE_BYTES = 5 * 1024 * 1024; // 5 MB
export const MAX_IMAGES = 5;

export function validateImageFile(file: File): string | null {
  const type = file.type.toLowerCase();
  if (!ALLOWED_IMAGE_TYPES.includes(type)) {
    return `${file.name}: only JPG, JPEG, and PNG images are allowed.`;
  }
  if (file.size > MAX_IMAGE_BYTES) {
    return `${file.name}: file exceeds the 5 MB limit.`;
  }
  return null;
}

// Compress an image to max width, JPEG quality 0.82. Returns a new File.
export async function compressImage(file: File, maxDim = 1600): Promise<File> {
  if (typeof window === "undefined") return file;
  try {
    const bitmap = await createImageBitmap(file);
    const scale = Math.min(1, maxDim / Math.max(bitmap.width, bitmap.height));
    const w = Math.round(bitmap.width * scale);
    const h = Math.round(bitmap.height * scale);
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) return file;
    ctx.drawImage(bitmap, 0, 0, w, h);
    const blob: Blob | null = await new Promise((res) =>
      canvas.toBlob((b) => res(b), "image/jpeg", 0.82),
    );
    if (!blob) return file;
    const base = file.name.replace(/\.(png|jpe?g)$/i, "");
    return new File([blob], `${base}.jpg`, { type: "image/jpeg" });
  } catch {
    return file;
  }
}