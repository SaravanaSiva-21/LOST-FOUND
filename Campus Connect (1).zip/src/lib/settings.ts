import { supabase } from "@/integrations/supabase/client";

export type GeneralSettings = {
  website_name: string;
  website_logo_url: string;
  college_logo_url: string;
  college_name: string;
  contact_email: string;
  contact_phone: string;
  footer_text: string;
  copyright_text: string;
};

export type HomepageSettings = {
  hero_banner_url: string;
  announcement: string;
  announcement_active: boolean;
  welcome_message: string;
  contact_address: string;
  contact_hours: string;
};

export const DEFAULT_GENERAL: GeneralSettings = {
  website_name: "TCE Lost & Found",
  website_logo_url: "",
  college_logo_url: "",
  college_name: "Thiagarajar College of Engineering, Madurai",
  contact_email: "",
  contact_phone: "",
  footer_text: "Campus Lost & Found Portal — helping the TCE community reunite with what matters.",
  copyright_text: `© ${new Date().getFullYear()} Thiagarajar College of Engineering`,
};

export const DEFAULT_HOMEPAGE: HomepageSettings = {
  hero_banner_url: "",
  announcement: "",
  announcement_active: false,
  welcome_message: "Report lost belongings, browse found items, and claim what's yours — securely and quickly.",
  contact_address: "",
  contact_hours: "Mon–Fri, 9:00 AM – 5:00 PM",
};

export async function loadSetting<T extends object>(key: string, defaults: T): Promise<T> {
  const { data } = await supabase.from("system_settings").select("value").eq("key", key).maybeSingle();
  return { ...defaults, ...((data?.value as any) ?? {}) };
}

export async function saveSetting(key: string, value: Record<string, any>) {
  const { data: { user } } = await supabase.auth.getUser();
  const { error } = await supabase
    .from("system_settings")
    .upsert({ key, value: value as any, updated_by: user?.id ?? null, updated_at: new Date().toISOString() }, { onConflict: "key" });
  if (error) throw error;
}

/** Upload a site asset (logo/banner) into the private site-assets bucket, returns a long-lived signed URL. */
export async function uploadSiteAsset(file: File, prefix: string): Promise<string> {
  const ext = file.name.split(".").pop()?.toLowerCase() ?? "png";
  const path = `${prefix}/${Date.now()}.${ext}`;
  const { error: upErr } = await supabase.storage.from("site-assets").upload(path, file, { upsert: true, contentType: file.type });
  if (upErr) throw upErr;
  const { data, error } = await supabase.storage.from("site-assets").createSignedUrl(path, 60 * 60 * 24 * 365 * 5);
  if (error) throw error;
  return data.signedUrl;
}
