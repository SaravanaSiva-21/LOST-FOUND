import { supabase } from "@/integrations/supabase/client";

export const APP_NAME = "TCE Lost & Found";
export const COLLEGE_NAME = "Thiagarajar College of Engineering, Madurai";

export const ITEM_CATEGORIES = [
  "Electronics",
  "Books & Notes",
  "ID Card / Documents",
  "Bag / Backpack",
  "Wallet / Purse",
  "Keys",
  "Water Bottle",
  "Umbrella",
  "Clothing",
  "Jewellery / Accessories",
  "Stationery",
  "Sports Equipment",
  "Other",
];

export const GENERAL_LOCATIONS = [
  "Main Block",
  "Library",
  "Canteen",
  "Hostels",
  "Auditorium",
  "Sports Ground",
  "Parking",
  "Department Block",
  "Administrative Block",
  "Other",
];

/** Record a search keyword or item view in the user's history. */
export async function recordHistory(params: { user_id: string; keyword?: string; viewed_item_id?: string; kind: "search" | "view" }) {
  try {
    await supabase.from("search_history").insert({
      user_id: params.user_id,
      keyword: params.keyword ?? null,
      viewed_item_id: params.viewed_item_id ?? null,
      kind: params.kind,
    });
  } catch { /* non-blocking */ }
}

/** Convert an array of records to CSV text. */
export function toCSV(rows: Record<string, any>[]): string {
  if (rows.length === 0) return "";
  const set = new Set<string>();
  rows.forEach((r) => Object.keys(r).forEach((k) => set.add(k)));
  const headers = Array.from(set);
  const esc = (v: any) => {
    if (v === null || v === undefined) return "";
    const s = typeof v === "string" ? v : JSON.stringify(v);
    if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
    return s;
  };
  return [headers.join(","), ...rows.map((r) => headers.map((h) => esc(r[h])).join(","))].join("\n");
}

/** Trigger a browser download of a text/csv file. */
export function downloadFile(content: string, filename: string, mime = "text/csv") {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 500);
}

export async function createNotification(params: {
  user_id: string;
  type: any;
  title: string;
  message: string;
  case_id?: string | null;
  link?: string | null;
}) {
  await supabase.from("notifications").insert(params);
}

export async function logAudit(params: {
  action: string;
  entity?: string;
  entity_id?: string;
  metadata?: Record<string, unknown>;
}) {
  const { data } = await supabase.auth.getUser();
  const client = typeof window !== "undefined" ? parseClientInfo(navigator.userAgent) : null;
  await supabase.from("audit_logs").insert({
    user_id: data.user?.id ?? null,
    action: params.action,
    entity: params.entity ?? null,
    entity_id: params.entity_id ?? null,
    metadata: { ...(params.metadata ?? {}), ...(client ?? {}) } as any,
  });
}

function parseClientInfo(ua: string) {
  const browser = /Edg\//.test(ua) ? "Edge"
    : /OPR\//.test(ua) ? "Opera"
    : /Chrome\//.test(ua) ? "Chrome"
    : /Firefox\//.test(ua) ? "Firefox"
    : /Safari\//.test(ua) ? "Safari"
    : "Unknown";
  const os = /Windows/.test(ua) ? "Windows"
    : /Android/.test(ua) ? "Android"
    : /iPhone|iPad|iPod/.test(ua) ? "iOS"
    : /Mac OS X/.test(ua) ? "macOS"
    : /Linux/.test(ua) ? "Linux"
    : "Unknown";
  const device = /Mobi|Android|iPhone|iPod/.test(ua) ? "Mobile"
    : /iPad|Tablet/.test(ua) ? "Tablet"
    : "Desktop";
  return { browser, os, device, user_agent: ua };
}

export function classify(status: string): { label: string; tone: string } {
  const map: Record<string, { label: string; tone: string }> = {
    pending_verification: { label: "Pending Verification", tone: "bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30" },
    approved: { label: "Approved", tone: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30" },
    rejected: { label: "Rejected", tone: "bg-red-500/15 text-red-700 dark:text-red-400 border-red-500/30" },
    matched: { label: "Match Found", tone: "bg-blue-500/15 text-blue-700 dark:text-blue-400 border-blue-500/30" },
    claimed: { label: "Claim Pending", tone: "bg-purple-500/15 text-purple-700 dark:text-purple-400 border-purple-500/30" },
    handed_over: { label: "Handed Over", tone: "bg-cyan-500/15 text-cyan-700 dark:text-cyan-400 border-cyan-500/30" },
    resolved: { label: "Resolved", tone: "bg-emerald-600/15 text-emerald-700 dark:text-emerald-400 border-emerald-600/30" },
    archived: { label: "Archived", tone: "bg-muted text-muted-foreground border-border" },
    pending: { label: "Pending", tone: "bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30" },
    under_review: { label: "Under Review", tone: "bg-blue-500/15 text-blue-700 dark:text-blue-400 border-blue-500/30" },
    contact_shared: { label: "Contact Shared", tone: "bg-cyan-500/15 text-cyan-700 dark:text-cyan-400 border-cyan-500/30" },
    waiting_handover: { label: "Waiting for Handover Confirmation", tone: "bg-blue-500/15 text-blue-700 dark:text-blue-400 border-blue-500/30" },
    waiting_finder: { label: "Waiting for Finder Confirmation", tone: "bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30" },
    waiting_owner: { label: "Waiting for Owner Confirmation", tone: "bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30" },
    finder_confirmed: { label: "Finder Confirmed", tone: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30" },
    owner_confirmed: { label: "Owner Confirmed", tone: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30" },
    completed: { label: "Completed", tone: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30" },
    more_info: { label: "More Info Requested", tone: "bg-orange-500/15 text-orange-700 dark:text-orange-400 border-orange-500/30" },
    withdrawn: { label: "Withdrawn", tone: "bg-muted text-muted-foreground border-border" },
    waiting: { label: "Waiting", tone: "bg-muted text-muted-foreground border-border" },
    scheduled: { label: "Scheduled", tone: "bg-blue-500/15 text-blue-700 dark:text-blue-400 border-blue-500/30" },
    cancelled: { label: "Cancelled", tone: "bg-red-500/15 text-red-700 dark:text-red-400 border-red-500/30" },
  };
  return map[status] ?? { label: status, tone: "bg-muted text-muted-foreground border-border" };
}

// Human-friendly labels for notification types (used across UI)
export const NOTIFICATION_LABELS: Record<string, string> = {
  registration: "Registration",
  password_reset: "Password reset",
  report_submitted: "Report submitted",
  report_approved: "Report approved",
  report_rejected: "Report rejected",
  claim_submitted: "Claim submitted",
  claim_approved: "Claim approved",
  claim_rejected: "Claim rejected",
  more_info_requested: "More info requested",
  possible_match: "Potential match",
  contact_reveal_request: "Contact reveal request",
  contact_revealed: "Contact revealed",
  handover_reminder: "Handover reminder",
  item_handed_over: "Item handed over",
  item_received: "Item received",
  case_resolved: "Case resolved",
  generic: "Update",
};
