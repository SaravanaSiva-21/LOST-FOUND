import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { APP_NAME, COLLEGE_NAME } from "@/lib/tce";
import { Mail, MapPin, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About & Policies — TCE Lost & Found" },
      { name: "description", content: "About the TCE Lost & Found Portal, privacy policy, terms of use, disclaimer, and contact information." },
    ],
  }),
  component: About,
});

function About() {
  return (
    <AppShell>
      <div className="mx-auto max-w-4xl px-4 sm:px-6 py-12 space-y-12">
        <header>
          <h1 className="text-4xl font-bold">About {APP_NAME}</h1>
          <p className="mt-3 text-muted-foreground">
            An official secure portal built for {COLLEGE_NAME} to help students and faculty recover lost items on campus.
          </p>
        </header>

        <section id="privacy" className="rounded-2xl border border-border bg-card p-6">
          <div className="flex items-center gap-2 mb-3">
            <ShieldCheck className="h-5 w-5 text-primary" />
            <h2 className="text-xl font-semibold">Privacy Policy</h2>
          </div>
          <ul className="list-disc pl-5 space-y-2 text-sm text-muted-foreground">
            <li>Public visitors only see item name, category, general location, date, and status.</li>
            <li>Descriptions, photos, contact numbers, exact locations, and identification marks are visible only to the administrator.</li>
            <li>Contact details are shared with another user only after admin approval and mutual consent from both parties.</li>
            <li>All activity is logged for audit and dispute resolution purposes.</li>
            <li>Data is stored securely within the college's authorized backend infrastructure.</li>
          </ul>
        </section>

        <section id="terms" className="rounded-2xl border border-border bg-card p-6">
          <h2 className="text-xl font-semibold mb-3">Terms of Use</h2>
          <ul className="list-disc pl-5 space-y-2 text-sm text-muted-foreground">
            <li>Registration is restricted to whitelisted @tce.edu, @student.tce.edu, and @admin.tce.edu email addresses.</li>
            <li>Users must provide truthful information in every report and claim.</li>
            <li>Users must not attempt to claim items they do not own.</li>
            <li>The administrator's verification is final.</li>
          </ul>
        </section>

        <section id="disclaimer" className="rounded-2xl border border-amber-500/30 bg-amber-500/5 p-6">
          <h2 className="text-xl font-semibold mb-3">Disclaimer</h2>
          <ul className="list-disc pl-5 space-y-2 text-sm text-muted-foreground">
            <li>False reports are prohibited.</li>
            <li>False claims are prohibited.</li>
            <li>Misuse may result in disciplinary action.</li>
            <li>Personal information is protected.</li>
            <li>Administrators have authority to verify, approve, reject, or archive all reports.</li>
            <li>All activities are logged.</li>
          </ul>
        </section>

        <section id="contact" className="rounded-2xl border border-border bg-card p-6">
          <h2 className="text-xl font-semibold mb-3">Contact</h2>
          <div className="space-y-2 text-sm text-muted-foreground">
            <div className="flex items-center gap-2"><MapPin className="h-4 w-4" /> Thiagarajar College of Engineering, Madurai — 625015</div>
            <div className="flex items-center gap-2"><Mail className="h-4 w-4" /> admin@admin.tce.edu</div>
          </div>
        </section>
      </div>
    </AppShell>
  );
}