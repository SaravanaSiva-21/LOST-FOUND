import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { DisclaimerBox } from "@/components/DisclaimerBox";
import { APP_NAME } from "@/lib/tce";
import { Eye, EyeOff, KeyRound, LogIn, UserPlus } from "lucide-react";

function extractErrorMessage(err: unknown, fallback = "An unexpected error occurred. Please try again."): string {
  if (!err) return fallback;
  if (typeof err === "string") return err;
  if (err instanceof z.ZodError) {
    return err.issues.map((i) => i.message).join(", ") || fallback;
  }
  if (err instanceof Error && err.message) return err.message;
  if (typeof err === "object") {
    const anyErr = err as Record<string, any>;
    const msg =
      anyErr.message ||
      anyErr.error_description ||
      anyErr.error?.message ||
      anyErr.msg ||
      anyErr.hint ||
      anyErr.details;
    if (typeof msg === "string" && msg.trim()) return msg;
  }
  try {
    const s = JSON.stringify(err);
    if (s && s !== "{}") return s;
  } catch {}
  return fallback;
}

function friendlySignupError(raw: string): string {
  const m = raw.toLowerCase();
  if (m.includes("already registered") || m.includes("already been registered") || m.includes("user already"))
    return "This email is already registered. Please sign in instead.";
  if (m.includes("whitelist"))
    return "Registration blocked: your email is not in the approved whitelist. Please contact the administrator.";
  if (m.includes("only @tce.edu") || m.includes("@student.tce.edu") || m.includes("@gmail.com") || m.includes("invalid domain") || m.includes("email domain"))
    return "Only @tce.edu, @student.tce.edu, or @gmail.com email addresses are permitted.";
  if (m.includes("admin accounts must use"))
    return "Admin accounts must use a @gmail.com email address.";
  if (m.includes("password"))
    return raw; // password rule messages are already clear
  if (m.includes("rate limit") || m.includes("too many"))
    return "Too many attempts. Please wait a moment and try again.";
  if (m.includes("network") || m.includes("fetch"))
    return "Network error. Check your connection and try again.";
  if (m.includes("database error saving new user"))
    return "We couldn't create your account. Your email may not be whitelisted, or the details don't match your assigned role. Please contact the administrator.";
  return raw;
}

type Tab = "login" | "register" | "forgot";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — TCE Lost & Found" },
      { name: "description", content: "Sign in or register with your TCE email to access the Lost & Found portal." },
      { name: "robots", content: "noindex" },
    ],
  }),
  validateSearch: (s: Record<string, unknown>) => ({
    tab: (s.tab as Tab) ?? "login",
  }),
  component: AuthPage,
});

const pwSchema = z
  .string()
  .min(8, "At least 8 characters")
  .regex(/[A-Z]/, "Must contain an uppercase letter")
  .regex(/[a-z]/, "Must contain a lowercase letter")
  .regex(/[0-9]/, "Must contain a number")
  .regex(/[^A-Za-z0-9]/, "Must contain a special character");

const emailSchema = z
  .string()
  .trim()
  .toLowerCase()
  .email("Invalid email")
  .refine(
    (v) => v.endsWith("@tce.edu") || v.endsWith("@student.tce.edu") || v.endsWith("@gmail.com"),
    "Only @tce.edu, @student.tce.edu, or @gmail.com emails are permitted"
  );

function AuthPage() {
  const search = Route.useSearch();
  const [tab, setTab] = useState<Tab>(search.tab);
  useEffect(() => setTab(search.tab), [search.tab]);

  return (
    <AppShell>
      <div className="min-h-[80vh] grid place-items-center px-4 py-12">
        <div className="w-full max-w-md">
          <div className="text-center mb-6">
            <div className="inline-flex mx-auto mb-4">
              <Logo size={48} />
            </div>
            <h1 className="text-2xl font-bold">{APP_NAME}</h1>
            <p className="text-sm text-muted-foreground mt-1">Secure access for TCE Madurai</p>
          </div>

          <div className="grid grid-cols-3 gap-1 rounded-lg bg-secondary p-1 mb-6">
            {(["login", "register", "forgot"] as Tab[]).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`text-xs font-medium py-2 rounded-md transition-colors ${
                  tab === t ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {t === "login" ? "Login" : t === "register" ? "Register" : "Forgot"}
              </button>
            ))}
          </div>

          <div className="rounded-2xl border border-border bg-card p-6">
            {tab === "login" && <LoginForm />}
            {tab === "register" && <RegisterForm />}
            {tab === "forgot" && <ForgotForm />}
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function LoginForm() {
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const em = emailSchema.parse(email);
      const { error } = await supabase.auth.signInWithPassword({ email: em, password });
      if (error) throw error;
      if (!remember) {
        // best-effort session timeout hint (Supabase persists by default)
        sessionStorage.setItem("tce-no-remember", "1");
      }
      toast.success("Signed in");
      nav({ to: "/dashboard" });
    } catch (err) {
      console.error("[Login] error:", err);
      const raw = extractErrorMessage(err, "Sign in failed");
      const lower = raw.toLowerCase();
      const friendly = lower.includes("invalid login")
        ? "Invalid email or password."
        : lower.includes("email not confirmed")
        ? "Please verify your email before signing in."
        : raw;
      toast.error(friendly);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="space-y-1.5">
        <Label htmlFor="li-email">Email</Label>
        <Input id="li-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@tce.edu" required />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="li-pw">Password</Label>
        <div className="relative">
          <Input id="li-pw" type={show ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} required />
          <button type="button" onClick={() => setShow(!show)} className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8 grid place-items-center text-muted-foreground">
            {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>
      </div>
      <label className="flex items-center gap-2 text-sm text-muted-foreground">
        <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
        Remember me on this device
      </label>
      <Button type="submit" className="w-full gap-2" disabled={loading}>
        <LogIn className="h-4 w-4" /> {loading ? "Signing in..." : "Sign in"}
      </Button>
    </form>
  );
}

function RegisterForm() {
  const nav = useNavigate();
  const [form, setForm] = useState({
    full_name: "",
    register_no: "",
    department: "",
    email: "",
    phone: "",
    password: "",
    confirm: "",
  });
  const [departments, setDepartments] = useState<{ code: string; name: string }[]>([]);
  const [agreed, setAgreed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [show, setShow] = useState(false);

  useEffect(() => {
    supabase
      .from("departments")
      .select("code,name")
      .order("name")
      .then(({ data }) => setDepartments(data ?? []));
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log("[Register] submit start for:", form.email);

    // 1. Client-side validation (per-field, clear messages)
    if (!agreed) {
      toast.error("You must accept the disclaimer to continue.");
      return;
    }
    if (!form.full_name.trim()) return toast.error("Please enter your full name.");
    if (!form.register_no.trim()) return toast.error("Please enter your Register No. / Employee ID.");
    if (!form.department) return toast.error("Please select your department.");
    if (!form.email.trim()) return toast.error("Please enter your email.");

    const emailParsed = emailSchema.safeParse(form.email);
    if (!emailParsed.success) {
      const msg = emailParsed.error.issues[0]?.message ?? "Invalid email.";
      console.error("[Register] email validation failed:", emailParsed.error);
      toast.error(msg);
      return;
    }
    const em = emailParsed.data;

    const pwParsed = pwSchema.safeParse(form.password);
    if (!pwParsed.success) {
      const msg = pwParsed.error.issues[0]?.message ?? "Password requirements not met.";
      console.error("[Register] password validation failed:", pwParsed.error);
      toast.error(`Password requirements not met: ${msg}`);
      return;
    }
    if (form.password !== form.confirm) {
      toast.error("Passwords do not match.");
      return;
    }

    setLoading(true);
    try {
      console.log("[Register] calling supabase.auth.signUp for:", em);
      const signUpResp = await supabase.auth.signUp({
        email: em,
        password: form.password,
        options: {
          emailRedirectTo: `${window.location.origin}/auth`,
          data: {
            full_name: form.full_name.trim(),
            register_no: form.register_no.trim(),
            department: form.department,
            phone: form.phone.trim(),
          },
        },
      });
      console.log("[Register] signUp response:", signUpResp);

      if (signUpResp.error) {
        console.error("[Register] signUp error object:", signUpResp.error);
        const raw = extractErrorMessage(signUpResp.error, "Registration failed");
        toast.error(friendlySignupError(raw));
        return;
      }

      if (!signUpResp.data?.user) {
        console.error("[Register] signUp returned no user:", signUpResp);
        toast.error("Registration did not complete. Please try again.");
        return;
      }

      toast.success("Account created. Check your email to verify.", { duration: 6000 });
      nav({ to: "/auth", search: { tab: "login" } });
    } catch (err) {
      console.error("[Register] unexpected error:", err);
      const raw = extractErrorMessage(err, "An unexpected error occurred. Please try again.");
      toast.error(friendlySignupError(raw));
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <DisclaimerBox agreed={agreed} onAgreeChange={setAgreed} />
      <div className="grid grid-cols-1 gap-4">
        <Field label="Full Name" v={form.full_name} on={(v) => setForm({ ...form, full_name: v })} required />
        <Field label="Register No. / Employee ID" v={form.register_no} on={(v) => setForm({ ...form, register_no: v })} required />
        <div className="space-y-1.5">
          <Label>Department</Label>
          <select
            className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
            value={form.department}
            onChange={(e) => setForm({ ...form, department: e.target.value })}
            required
          >
            <option value="">Select department</option>
            {departments.map((d) => (
              <option key={d.code} value={d.code}>{d.name}</option>
            ))}
          </select>
        </div>
        <Field label="Email (TCE)" type="email" v={form.email} on={(v) => setForm({ ...form, email: v })} placeholder="you@tce.edu" required />
        <Field label="Phone (optional)" v={form.phone} on={(v) => setForm({ ...form, phone: v })} placeholder="+91 ..." />
        <div className="space-y-1.5">
          <Label>Password</Label>
          <div className="relative">
            <Input type={show ? "text" : "password"} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required />
            <button type="button" onClick={() => setShow(!show)} className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8 grid place-items-center text-muted-foreground">
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
          <p className="text-[11px] text-muted-foreground">
            Min 8 characters, with uppercase, lowercase, number, and special character.
          </p>
        </div>
        <Field label="Confirm Password" type={show ? "text" : "password"} v={form.confirm} on={(v) => setForm({ ...form, confirm: v })} required />
      </div>
      <Button type="submit" className="w-full gap-2" disabled={loading || !agreed}>
        <UserPlus className="h-4 w-4" /> {loading ? "Creating account..." : "Create Account"}
      </Button>
      <p className="text-[11px] text-center text-muted-foreground">
        Only whitelisted TCE email addresses can register. Contact administration if you cannot register.
      </p>
    </form>
  );
}

function ForgotForm() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const em = emailSchema.parse(email);
      const { error } = await supabase.auth.resetPasswordForEmail(em, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) throw error;
      toast.success("Password reset email sent (if account exists).");
    } catch (err) {
      console.error("[Forgot] error:", err);
      toast.error(extractErrorMessage(err, "Failed to send reset email"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Enter your TCE email and we'll send a secure link to reset your password.
      </p>
      <Field label="Email" type="email" v={email} on={setEmail} required />
      <Button type="submit" className="w-full gap-2" disabled={loading}>
        <KeyRound className="h-4 w-4" /> {loading ? "Sending..." : "Send Reset Link"}
      </Button>
      <div className="text-center text-xs">
        <Link to="/auth" search={{ tab: "login" }} className="text-primary hover:underline">
          Back to login
        </Link>
      </div>
    </form>
  );
}

function Field({
  label, v, on, type = "text", required, placeholder,
}: { label: string; v: string; on: (v: string) => void; type?: string; required?: boolean; placeholder?: string }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      <Input type={type} value={v} onChange={(e) => on(e.target.value)} required={required} placeholder={placeholder} />
    </div>
  );
}