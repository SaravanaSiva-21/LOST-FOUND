import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Clock, Filter } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/dashboard/activity")({
  component: Activity,
});

interface Row {
  id: string;
  action: string;
  entity: string | null;
  entity_id: string | null;
  metadata: any;
  created_at: string;
}

function pretty(action: string) {
  return action.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

function Activity() {
  const { user } = useAuth();
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [type, setType] = useState<string>("");

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase
        .from("audit_logs")
        .select("id,action,entity,entity_id,metadata,created_at")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(200);
      setRows((data as Row[]) ?? []);
      setLoading(false);
    })();
  }, [user?.id]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return rows.filter((r) => {
      if (type && r.entity !== type) return false;
      if (!s) return true;
      return (
        r.action.toLowerCase().includes(s) ||
        (r.metadata?.case_id ?? "").toString().toLowerCase().includes(s)
      );
    });
  }, [rows, q, type]);

  const types = useMemo(
    () => Array.from(new Set(rows.map((r) => r.entity).filter(Boolean))) as string[],
    [rows],
  );

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Activity History</h1>
        <p className="text-sm text-muted-foreground mt-1">Every action recorded for your account, sorted by newest first.</p>
      </header>

      <div className="rounded-2xl border border-border bg-card p-4 space-y-3">
        <div className="grid md:grid-cols-3 gap-2">
          <Input placeholder="Search action or case ID..." value={q} onChange={(e) => setQ(e.target.value)} />
          <select value={type} onChange={(e) => setType(e.target.value)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
            <option value="">All entity types</option>
            {types.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Filter className="h-3 w-3" /> {filtered.length} entries
          </div>
        </div>
      </div>

      {loading ? (
        <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground text-sm">Loading...</div>
      ) : filtered.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground text-sm">
          <Clock className="h-6 w-6 mx-auto mb-2 opacity-50" /> No activity yet.
        </div>
      ) : (
        <div className="rounded-2xl border border-border bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 text-[11px] uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="text-left px-4 py-2 font-medium">Date</th>
                <th className="text-left px-4 py-2 font-medium">Time</th>
                <th className="text-left px-4 py-2 font-medium">Action</th>
                <th className="text-left px-4 py-2 font-medium">Entity</th>
                <th className="text-left px-4 py-2 font-medium">Case ID</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((r) => {
                const d = new Date(r.created_at);
                return (
                  <tr key={r.id} className="border-t border-border hover:bg-muted/30">
                    <td className="px-4 py-2 whitespace-nowrap">{d.toLocaleDateString()}</td>
                    <td className="px-4 py-2 whitespace-nowrap">{d.toLocaleTimeString()}</td>
                    <td className="px-4 py-2">{pretty(r.action)}</td>
                    <td className="px-4 py-2 text-muted-foreground">{r.entity ?? "—"}</td>
                    <td className="px-4 py-2 font-mono text-xs">{r.metadata?.case_id ?? "—"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}