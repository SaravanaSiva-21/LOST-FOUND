import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend, LineChart, Line, CartesianGrid, AreaChart, Area } from "recharts";
import { ITEM_CATEGORIES } from "@/lib/tce";

export const Route = createFileRoute("/dashboard/admin/analytics")({
  component: Analytics,
});

const COLORS = ["#2563eb", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4", "#84cc16", "#e11d48", "#0ea5e9", "#f97316"];

function Analytics() {
  const [items, setItems] = useState<any[]>([]);
  const [claims, setClaims] = useState<any[]>([]);
  const [profiles, setProfiles] = useState<any[]>([]);
  const [roles, setRoles] = useState<Record<string, string>>({});

  // Filters
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [dept, setDept] = useState("all");
  const [cat, setCat] = useState("all");
  const [status, setStatus] = useState("all");
  const [role, setRole] = useState("all");

  useEffect(() => {
    (async () => {
      const [it, cl, pr, rl] = await Promise.all([
        supabase.from("items").select("id,report_type,category,general_location,status,created_at,updated_at,reporter_id").limit(3000),
        supabase.from("claims").select("id,status,created_at,updated_at,claimant_id,contact_shared_at,finder_confirmed,owner_confirmed").limit(3000),
        supabase.from("profiles").select("id,department,created_at").limit(3000),
        supabase.from("user_roles").select("user_id,role").limit(3000),
      ]);
      setItems(it.data ?? []);
      setClaims(cl.data ?? []);
      setProfiles(pr.data ?? []);
      const r: Record<string, string> = {};
      (rl.data ?? []).forEach((row: any) => { r[row.user_id] = row.role; });
      setRoles(r);
    })();
  }, []);

  const deptByUser = useMemo(() => {
    const m: Record<string, string> = {};
    profiles.forEach((p) => { if (p.id) m[p.id] = p.department ?? "—"; });
    return m;
  }, [profiles]);

  const inRange = (d: string) => {
    if (from && new Date(d) < new Date(from)) return false;
    if (to && new Date(d) > new Date(to + "T23:59:59")) return false;
    return true;
  };

  const fItems = useMemo(() => items.filter((i) => inRange(i.created_at)
    && (cat === "all" || i.category === cat)
    && (status === "all" || i.status === status)
    && (dept === "all" || deptByUser[i.reporter_id] === dept)
    && (role === "all" || roles[i.reporter_id] === role)
  ), [items, from, to, cat, status, dept, role, deptByUser, roles]);

  const fClaims = useMemo(() => claims.filter((c) => inRange(c.created_at)
    && (role === "all" || roles[c.claimant_id] === role)
    && (dept === "all" || deptByUser[c.claimant_id] === dept)
  ), [claims, from, to, role, dept, deptByUser, roles]);

  const fProfiles = useMemo(() => profiles.filter((p) => inRange(p.created_at) && (dept === "all" || p.department === dept) && (role === "all" || roles[p.id] === role)), [profiles, from, to, dept, role, roles]);

  const monthly = useMemo(() => buildMonths(12, (b) => {
    fItems.forEach((it) => {
      const k = ymKey(new Date(it.created_at));
      if (!b[k]) return;
      if (it.report_type === "lost") b[k].lost += 1;
      if (it.report_type === "found") b[k].found += 1;
      if (it.status === "resolved") b[k].resolved += 1;
    });
    fClaims.forEach((c) => { const k = ymKey(new Date(c.created_at)); if (b[k]) b[k].claims += 1; });
  }), [fItems, fClaims]);

  const weekly = useMemo(() => {
    const out: { day: string; lost: number; found: number; claims: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      out.push({ day: d.toLocaleDateString(undefined, { weekday: "short" }), lost: 0, found: 0, claims: 0 });
    }
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const idx = (d: Date) => 6 - Math.floor((today.getTime() - new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime()) / 86400000);
    fItems.forEach((it) => { const i = idx(new Date(it.created_at)); if (i >= 0 && i <= 6) { if (it.report_type === "lost") out[i].lost += 1; else out[i].found += 1; } });
    fClaims.forEach((c) => { const i = idx(new Date(c.created_at)); if (i >= 0 && i <= 6) out[i].claims += 1; });
    return out;
  }, [fItems, fClaims]);

  const lostCats = useMemo(() => tally(fItems.filter((i) => i.report_type === "lost"), "category"), [fItems]);
  const foundCats = useMemo(() => tally(fItems.filter((i) => i.report_type === "found"), "category"), [fItems]);
  const lostLocs = useMemo(() => tally(fItems.filter((i) => i.report_type === "lost"), "general_location"), [fItems]);
  const foundLocs = useMemo(() => tally(fItems.filter((i) => i.report_type === "found"), "general_location"), [fItems]);
  const claimStatus = useMemo(() => tally(fClaims, "status"), [fClaims]);

  const byDept = useMemo(() => {
    const m: Record<string, { key: string; lost: number; found: number }> = {};
    fItems.forEach((it) => {
      const d = deptByUser[it.reporter_id] ?? "—";
      if (!m[d]) m[d] = { key: d, lost: 0, found: 0 };
      if (it.report_type === "lost") m[d].lost += 1; else m[d].found += 1;
    });
    return Object.values(m).sort((a, b) => (b.lost + b.found) - (a.lost + a.found)).slice(0, 10);
  }, [fItems, deptByUser]);

  const registrationTrend = useMemo(() => {
    const b = seedMonths(12);
    fProfiles.forEach((p) => { const k = ymKey(new Date(p.created_at)); if (b[k]) b[k].value += 1; });
    return Object.values(b);
  }, [fProfiles]);

  const pendingVsResolved = useMemo(() => {
    const pending = fItems.filter((i) => ["pending_verification", "approved", "matched", "claimed", "handed_over"].includes(i.status)).length;
    const resolved = fItems.filter((i) => i.status === "resolved").length;
    return [{ key: "Pending / Active", value: pending }, { key: "Resolved", value: resolved }];
  }, [fItems]);

  const resolvedItems = fItems.filter((i) => i.status === "resolved");
  const resolutionRate = fItems.length ? Math.round((resolvedItems.length / fItems.length) * 100) : 0;
  const recoveryRate = (() => {
    const eligible = fItems.filter((i) => i.report_type === "lost").length;
    const recovered = fItems.filter((i) => i.report_type === "lost" && i.status === "resolved").length;
    return eligible ? Math.round((recovered / eligible) * 100) : 0;
  })();
  const avgResolutionDays = (() => {
    const done = resolvedItems.filter((i) => i.updated_at && i.created_at);
    if (done.length === 0) return "—";
    const total = done.reduce((s, i) => s + (new Date(i.updated_at).getTime() - new Date(i.created_at).getTime()), 0);
    return (total / done.length / 86400000).toFixed(1) + " days";
  })();
  const activeUsers = fProfiles.filter((p) => !p.is_suspended).length || fProfiles.length;
  const pendingItems = fItems.filter((i) => i.status === "pending_verification").length;
  const pendingClaims = fClaims.filter((c) => c.status === "pending").length;
  const awaitingHandover = fClaims.filter((c) => c.status === "approved" && c.contact_shared_at && !(c.finder_confirmed && c.owner_confirmed)).length;
  const handoversCompleted = fClaims.filter((c) => c.finder_confirmed && c.owner_confirmed).length;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Analytics</h1>
        <p className="text-sm text-muted-foreground mt-1">Comprehensive portal insights with interactive filters.</p>
      </header>

      <div className="rounded-2xl border border-border bg-card p-4 grid md:grid-cols-6 gap-2">
        <label className="text-xs space-y-1"><span className="text-muted-foreground">From</span><Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></label>
        <label className="text-xs space-y-1"><span className="text-muted-foreground">To</span><Input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></label>
        <label className="text-xs space-y-1">
          <span className="text-muted-foreground">Department</span>
          <select value={dept} onChange={(e) => setDept(e.target.value)} className="h-10 w-full px-3 rounded-md border border-input bg-background text-sm">
            <option value="all">All</option>
            {Array.from(new Set(profiles.map((p) => p.department).filter(Boolean))).map((d: any) => <option key={d} value={d}>{d}</option>)}
          </select>
        </label>
        <label className="text-xs space-y-1">
          <span className="text-muted-foreground">Category</span>
          <select value={cat} onChange={(e) => setCat(e.target.value)} className="h-10 w-full px-3 rounded-md border border-input bg-background text-sm">
            <option value="all">All</option>
            {ITEM_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </label>
        <label className="text-xs space-y-1">
          <span className="text-muted-foreground">Status</span>
          <select value={status} onChange={(e) => setStatus(e.target.value)} className="h-10 w-full px-3 rounded-md border border-input bg-background text-sm">
            <option value="all">All</option>
            <option value="pending_verification">Pending</option>
            <option value="approved">Approved</option>
            <option value="matched">Matched</option>
            <option value="claimed">Claimed</option>
            <option value="handed_over">Handed Over</option>
            <option value="resolved">Resolved</option>
            <option value="rejected">Rejected</option>
          </select>
        </label>
        <label className="text-xs space-y-1">
          <span className="text-muted-foreground">Role</span>
          <select value={role} onChange={(e) => setRole(e.target.value)} className="h-10 w-full px-3 rounded-md border border-input bg-background text-sm">
            <option value="all">All</option>
            <option value="student">Student / Faculty</option>
            <option value="admin">Admin</option>
          </select>
        </label>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Stat label="Total Users" v={profiles.length} />
        <Stat label="Active Users" v={activeUsers} />
        <Stat label="Lost Reports" v={fItems.filter((i) => i.report_type === "lost").length} />
        <Stat label="Found Reports" v={fItems.filter((i) => i.report_type === "found").length} />
        <Stat label="Total Claims" v={fClaims.length} />
        <Stat label="Pending Verifications" v={pendingItems} tone="amber" />
        <Stat label="Pending Claims" v={pendingClaims} tone="amber" />
        <Stat label="Awaiting Handover" v={awaitingHandover} />
        <Stat label="Handovers Completed" v={handoversCompleted} />
        <Stat label="Resolved Cases" v={resolvedItems.length} />
        <Stat label="Avg. Resolution Time" v={avgResolutionDays} />
        <Stat label="Recovery Rate" v={`${recoveryRate}%`} tone="emerald" />
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <Panel title="Lost vs Found — last 12 months">
          <Chart><BarChart data={monthly}>
            <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
            <XAxis dataKey="month" fontSize={11} /><YAxis fontSize={11} allowDecimals={false} />
            <Tooltip /><Legend />
            <Bar dataKey="lost" fill="#ef4444" /><Bar dataKey="found" fill="#10b981" />
          </BarChart></Chart>
        </Panel>
        <Panel title="Claims per month">
          <Chart><LineChart data={monthly}>
            <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
            <XAxis dataKey="month" fontSize={11} /><YAxis fontSize={11} allowDecimals={false} />
            <Tooltip />
            <Line type="monotone" dataKey="claims" stroke="#8b5cf6" strokeWidth={2} />
          </LineChart></Chart>
        </Panel>
      </div>

      <Panel title="Weekly Activity (last 7 days)">
        <Chart><BarChart data={weekly}>
          <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
          <XAxis dataKey="day" fontSize={11} /><YAxis fontSize={11} allowDecimals={false} />
          <Tooltip /><Legend />
          <Bar dataKey="lost" fill="#ef4444" /><Bar dataKey="found" fill="#10b981" /><Bar dataKey="claims" fill="#8b5cf6" />
        </BarChart></Chart>
      </Panel>

      <div className="grid md:grid-cols-2 gap-4">
        <Panel title="Most Lost Categories">
          <Chart><BarChart data={lostCats.slice(0, 8)} layout="vertical">
            <XAxis type="number" fontSize={11} allowDecimals={false} />
            <YAxis type="category" dataKey="key" width={120} fontSize={11} />
            <Tooltip /><Bar dataKey="value" fill="#ef4444" />
          </BarChart></Chart>
        </Panel>
        <Panel title="Most Found Categories">
          <Chart><BarChart data={foundCats.slice(0, 8)} layout="vertical">
            <XAxis type="number" fontSize={11} allowDecimals={false} />
            <YAxis type="category" dataKey="key" width={120} fontSize={11} />
            <Tooltip /><Bar dataKey="value" fill="#10b981" />
          </BarChart></Chart>
        </Panel>
        <Panel title="Most Common Lost Locations">
          <Chart><BarChart data={lostLocs.slice(0, 8)} layout="vertical">
            <XAxis type="number" fontSize={11} allowDecimals={false} />
            <YAxis type="category" dataKey="key" width={120} fontSize={11} />
            <Tooltip /><Bar dataKey="value" fill="#f59e0b" />
          </BarChart></Chart>
        </Panel>
        <Panel title="Most Common Found Locations">
          <Chart><BarChart data={foundLocs.slice(0, 8)} layout="vertical">
            <XAxis type="number" fontSize={11} allowDecimals={false} />
            <YAxis type="category" dataKey="key" width={120} fontSize={11} />
            <Tooltip /><Bar dataKey="value" fill="#06b6d4" />
          </BarChart></Chart>
        </Panel>
      </div>

      <Panel title="Department-wise Reports">
        <Chart><BarChart data={byDept}>
          <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
          <XAxis dataKey="key" fontSize={11} />
          <YAxis fontSize={11} allowDecimals={false} />
          <Tooltip /><Legend />
          <Bar dataKey="lost" fill="#ef4444" stackId="a" /><Bar dataKey="found" fill="#10b981" stackId="a" />
        </BarChart></Chart>
      </Panel>

      <div className="grid md:grid-cols-2 gap-4">
        <Panel title="Resolution Rate">
          <Chart>
            <PieChart>
              <Pie data={[{ key: "Resolved", value: resolutionRate }, { key: "Open", value: 100 - resolutionRate }]} dataKey="value" nameKey="key" outerRadius={90} label>
                <Cell fill="#10b981" /><Cell fill="#e5e7eb" />
              </Pie>
              <Tooltip /><Legend />
            </PieChart>
          </Chart>
        </Panel>
        <Panel title="Pending vs Resolved Cases">
          <Chart>
            <PieChart>
              <Pie data={pendingVsResolved} dataKey="value" nameKey="key" outerRadius={90} label>
                <Cell fill="#f59e0b" /><Cell fill="#10b981" />
              </Pie>
              <Tooltip /><Legend />
            </PieChart>
          </Chart>
        </Panel>
      </div>

      <Panel title="Claims by Status">
        <Chart>
          <PieChart>
            <Pie data={claimStatus} dataKey="value" nameKey="key" outerRadius={100} label>
              {claimStatus.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
            </Pie>
            <Tooltip /><Legend />
          </PieChart>
        </Chart>
      </Panel>

      <Panel title="User Registration Trend">
        <Chart><AreaChart data={registrationTrend}>
          <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
          <XAxis dataKey="month" fontSize={11} /><YAxis fontSize={11} allowDecimals={false} />
          <Tooltip />
          <Area type="monotone" dataKey="value" stroke="#2563eb" fill="#2563eb33" />
        </AreaChart></Chart>
      </Panel>
    </div>
  );
}

function tally<T extends Record<string, any>>(rows: T[], key: keyof T) {
  const m: Record<string, number> = {};
  rows.forEach((r) => { const k = String(r[key] ?? "—"); m[k] = (m[k] ?? 0) + 1; });
  return Object.entries(m).map(([key, value]) => ({ key, value })).sort((a, b) => b.value - a.value);
}
function ymKey(d: Date) { return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`; }
function seedMonths(n: number) {
  const b: Record<string, { month: string; value: number }> = {};
  const now = new Date();
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    b[ymKey(d)] = { month: d.toLocaleString(undefined, { month: "short" }), value: 0 };
  }
  return b;
}
function buildMonths(n: number, fill: (buckets: Record<string, { month: string; lost: number; found: number; resolved: number; claims: number }>) => void) {
  const b: Record<string, { month: string; lost: number; found: number; resolved: number; claims: number }> = {};
  const now = new Date();
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    b[ymKey(d)] = { month: d.toLocaleString(undefined, { month: "short" }), lost: 0, found: 0, resolved: 0, claims: 0 };
  }
  fill(b);
  return Object.values(b);
}

function Stat({ label, v, tone }: any) {
  const cls = tone === "amber" ? "border-amber-500/30 bg-amber-500/5"
    : tone === "emerald" ? "border-emerald-500/30 bg-emerald-500/5"
    : "border-border bg-card";
  return <div className={`rounded-2xl border p-4 ${cls}`}><div className="text-2xl font-bold tabular-nums">{v}</div><div className="text-xs text-muted-foreground mt-1">{label}</div></div>;
}
function Panel({ title, children }: any) {
  return <div className="rounded-2xl border border-border bg-card p-4"><div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">{title}</div>{children}</div>;
}
function Chart({ children }: any) {
  return <div className="h-64"><ResponsiveContainer width="100%" height="100%">{children}</ResponsiveContainer></div>;
}