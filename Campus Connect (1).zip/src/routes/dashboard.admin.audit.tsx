import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Download } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toCSV, downloadFile } from "@/lib/tce";

export const Route = createFileRoute("/dashboard/admin/audit")({
  component: Audit,
});

function Audit() {
  const [logs, setLogs] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [action, setAction] = useState("all");
  const [entity, setEntity] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  useEffect(() => {
    (async () => {
      const { data: raw } = await supabase.from("audit_logs").select("*").order("created_at", { ascending: false }).limit(1000);
      const rows = raw ?? [];
      const userIds = Array.from(new Set(rows.map((r: any) => r.user_id).filter(Boolean)));
      if (userIds.length === 0) { setLogs(rows); return; }
      const [{ data: profs }, { data: roles }] = await Promise.all([
        supabase.from("profiles").select("id,full_name,email,department").in("id", userIds),
        supabase.from("user_roles").select("user_id,role").in("user_id", userIds),
      ]);
      const pmap = new Map((profs ?? []).map((p: any) => [p.id, p]));
      const rmap = new Map((roles ?? []).map((r: any) => [r.user_id, r.role]));
      setLogs(rows.map((r: any) => ({ ...r, user: pmap.get(r.user_id) ?? null, role: rmap.get(r.user_id) ?? null })));
    })();
  }, []);

  const actions = useMemo(() => Array.from(new Set(logs.map((l) => l.action))).sort(), [logs]);
  const entities = useMemo(() => Array.from(new Set(logs.map((l) => l.entity).filter(Boolean))).sort(), [logs]);

  const filtered = useMemo(() => logs.filter((l) => {
    if (action !== "all" && l.action !== action) return false;
    if (entity !== "all" && l.entity !== entity) return false;
    if (from && new Date(l.created_at) < new Date(from)) return false;
    if (to && new Date(l.created_at) > new Date(to + "T23:59:59")) return false;
    if (q) {
      const hay = [l.user?.full_name, l.user?.email, l.action, l.entity, l.entity_id, l.metadata?.case_id].join(" ").toLowerCase();
      if (!hay.includes(q.toLowerCase())) return false;
    }
    return true;
  }), [logs, q, action, entity, from, to]);

  const download = () => {
    const rows = filtered.map((l) => ({
      timestamp: new Date(l.created_at).toISOString(),
      name: l.user?.full_name ?? "",
      email: l.user?.email ?? "",
      role: l.role ?? "",
      action: l.action,
      entity: l.entity ?? "",
      entity_id: l.entity_id ?? "",
      case_id: l.metadata?.case_id ?? "",
      ip: l.ip_address ?? "",
      browser: l.metadata?.browser ?? "",
      os: l.metadata?.os ?? "",
      device: l.metadata?.device ?? "",
    }));
    downloadFile(toCSV(rows), `audit-${new Date().toISOString().slice(0, 10)}.csv`);
  };

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Audit Logs</h1>
          <p className="text-sm text-muted-foreground mt-1">Append-only record of portal activity with device details.</p>
        </div>
        <Button variant="outline" size="sm" onClick={download} className="gap-2"><Download className="h-4 w-4" /> Export CSV</Button>
      </header>

      <div className="grid md:grid-cols-5 gap-2">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search action, user, case…" className="md:col-span-2" />
        <select value={action} onChange={(e) => setAction(e.target.value)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
          <option value="all">All actions</option>
          {actions.map((a) => <option key={a} value={a}>{a}</option>)}
        </select>
        <select value={entity} onChange={(e) => setEntity(e.target.value)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
          <option value="all">All entities</option>
          {entities.map((e) => <option key={e} value={e}>{e}</option>)}
        </select>
        <div className="flex gap-1">
          <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-card overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="text-left px-4 py-3">Time</th>
              <th className="text-left px-4 py-3">Administrator</th>
              <th className="text-left px-4 py-3">Action</th>
              <th className="text-left px-4 py-3">Record</th>
              <th className="text-left px-4 py-3">Case</th>
              <th className="text-left px-4 py-3">Device</th>
              <th className="text-left px-4 py-3">IP</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((l) => (
              <tr key={l.id} className="border-t border-border align-top">
                <td className="px-4 py-3 whitespace-nowrap text-xs text-muted-foreground">{new Date(l.created_at).toLocaleString()}</td>
                <td className="px-4 py-3">
                  <div className="font-medium">{l.user?.full_name ?? "—"}</div>
                  <div className="text-[11px] text-muted-foreground">{l.user?.email ?? ""}</div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{l.role ?? "—"}</div>
                </td>
                <td className="px-4 py-3 font-mono text-xs">{l.action}</td>
                <td className="px-4 py-3 text-xs text-muted-foreground">
                  <div>{l.entity ?? "—"}</div>
                  <div className="font-mono text-[10px]">{l.entity_id?.slice(0, 8) ?? ""}</div>
                </td>
                <td className="px-4 py-3 text-xs font-mono text-muted-foreground">{l.metadata?.case_id ?? "—"}</td>
                <td className="px-4 py-3 text-xs text-muted-foreground">
                  {l.metadata?.browser ? `${l.metadata.browser} · ${l.metadata.os} · ${l.metadata.device}` : "—"}
                </td>
                <td className="px-4 py-3 text-xs font-mono text-muted-foreground">{l.ip_address ?? "—"}</td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={7} className="text-center text-muted-foreground text-sm py-10">No matching audit entries.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}