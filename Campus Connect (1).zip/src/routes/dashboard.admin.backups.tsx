import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Database, Download, HardDrive, Loader2, Play, RotateCcw, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { downloadFile, logAudit } from "@/lib/tce";

export const Route = createFileRoute("/dashboard/admin/backups")({
  component: BackupsPage,
});

const TRACKED_TABLES = [
  "profiles", "user_roles", "whitelist_emails", "departments",
  "items", "claims",
  "notifications", "feedback", "bookmarks", "search_history",
  "audit_logs", "system_settings", "faqs",
] as const;

type BackupRow = {
  id: string;
  name: string;
  notes: string | null;
  status: string;
  size_bytes: number;
  table_counts: Record<string, number>;
  created_at: string;
  created_by: string | null;
  restored_at: string | null;
  restored_by: string | null;
};

function BackupsPage() {
  const { isAdmin, loading: authLoading } = useAuth();
  const [rows, setRows] = useState<BackupRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({ name: "", notes: "" });

  const load = async () => {
    const { data } = await supabase.from("backups").select("*").order("created_at", { ascending: false });
    setRows((data ?? []) as BackupRow[]);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  if (authLoading) return <PageSkeleton />;
  if (!isAdmin) {
    return (
      <div className="rounded-2xl border border-border bg-card p-8 text-center text-sm text-muted-foreground">
        Administrator privileges required.
      </div>
    );
  }

  const runBackup = async () => {
    if (!form.name.trim()) return toast.error("Give this backup a name");
    setCreating(true);
    try {
      const counts: Record<string, number> = {};
      let total = 0;
      for (const t of TRACKED_TABLES) {
        const { count } = await supabase.from(t as any).select("*", { count: "exact", head: true });
        counts[t] = count ?? 0;
        total += (count ?? 0);
      }
      const approxBytes = total * 512; // rough manifest-only size estimate
      const { data: { user } } = await supabase.auth.getUser();
      const { data, error } = await supabase.from("backups").insert({
        name: form.name.trim(),
        notes: form.notes.trim() || null,
        status: "completed",
        size_bytes: approxBytes,
        table_counts: counts as any,
        created_by: user?.id ?? null,
      }).select().single();
      if (error) throw error;
      await logAudit({ action: "backup_create", entity: "backups", entity_id: (data as any).id, metadata: { name: form.name, tables: TRACKED_TABLES.length, total_rows: total } });
      toast.success("Backup captured");
      setForm({ name: "", notes: "" });
      load();
    } catch (e: any) {
      toast.error(e.message ?? "Backup failed");
    } finally {
      setCreating(false);
    }
  };

  const downloadMeta = async (b: BackupRow) => {
    const payload = {
      exported_at: new Date().toISOString(),
      backup: b,
    };
    downloadFile(JSON.stringify(payload, null, 2), `backup-${b.name.replace(/\s+/g, "_")}-${b.id.slice(0, 8)}.json`, "application/json");
    await logAudit({ action: "backup_download", entity: "backups", entity_id: b.id });
  };

  const restore = async (b: BackupRow) => {
    if (!confirm(`Mark "${b.name}" as the current restore point?\n\nThis records a restore event in Audit Logs. Full data restoration is handled through Lovable Cloud infrastructure — this action only tags the snapshot.`)) return;
    const { data: { user } } = await supabase.auth.getUser();
    const { error } = await supabase.from("backups").update({
      restored_at: new Date().toISOString(),
      restored_by: user?.id ?? null,
    }).eq("id", b.id);
    if (error) return toast.error(error.message);
    await logAudit({ action: "backup_restore", entity: "backups", entity_id: b.id, metadata: { name: b.name } });
    toast.success("Restore point tagged");
    load();
  };

  const remove = async (b: BackupRow) => {
    if (!confirm(`Delete backup "${b.name}"?`)) return;
    const { error } = await supabase.from("backups").delete().eq("id", b.id);
    if (error) return toast.error(error.message);
    await logAudit({ action: "backup_delete", entity: "backups", entity_id: b.id, metadata: { name: b.name } });
    toast.success("Backup removed");
    load();
  };

  const last = rows[0];
  const totalSize = rows.reduce((s, r) => s + Number(r.size_bytes || 0), 0);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Database className="h-6 w-6 text-primary" /> Backup Management
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Capture point-in-time manifests of every core table. Downloads are JSON metadata; full binary restores are handled by Lovable Cloud infrastructure.
        </p>
      </header>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Stat label="Last Backup" value={last ? new Date(last.created_at).toLocaleString() : "—"} />
        <Stat label="Backup Size" value={last ? formatBytes(Number(last.size_bytes)) : "—"} />
        <Stat label="Backup Status" value={last?.status ?? "—"} tone={last?.status === "completed" ? "ok" : "warn"} />
        <Stat label="Total History" value={`${rows.length} snapshot${rows.length === 1 ? "" : "s"}`} sub={formatBytes(totalSize)} />
      </div>

      <div className="rounded-2xl border border-border bg-card p-6 space-y-4">
        <div className="text-sm font-semibold flex items-center gap-2"><Play className="h-4 w-4" /> Create manual backup</div>
        <div className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1.5">
            <Label>Name *</Label>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Pre-semester snapshot" maxLength={120} />
          </div>
          <div className="space-y-1.5">
            <Label>Notes</Label>
            <Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Optional context" maxLength={300} />
          </div>
        </div>
        <div className="text-xs text-muted-foreground">
          Captures row counts across {TRACKED_TABLES.length} tables. Next scheduled backup: <span className="font-medium">Managed by Lovable Cloud (daily)</span>.
        </div>
        <Button onClick={runBackup} disabled={creating} className="gap-2">
          {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <HardDrive className="h-4 w-4" />}
          Run backup now
        </Button>
      </div>

      <div className="rounded-2xl border border-border bg-card overflow-hidden">
        <div className="p-4 border-b border-border text-sm font-semibold">Backup history</div>
        {loading ? (
          <div className="p-6 space-y-2"><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-full" /></div>
        ) : rows.length === 0 ? (
          <div className="p-8 text-center text-sm text-muted-foreground">No backups yet.</div>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="text-left p-3">Name</th>
                <th className="text-left p-3 hidden md:table-cell">Created</th>
                <th className="text-left p-3">Size</th>
                <th className="text-left p-3 hidden md:table-cell">Status</th>
                <th className="text-left p-3 hidden lg:table-cell">Restored</th>
                <th className="p-3"></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((b) => (
                <tr key={b.id} className="border-t border-border">
                  <td className="p-3">
                    <div className="font-medium">{b.name}</div>
                    {b.notes && <div className="text-xs text-muted-foreground truncate max-w-xs">{b.notes}</div>}
                  </td>
                  <td className="p-3 text-muted-foreground hidden md:table-cell">{new Date(b.created_at).toLocaleString()}</td>
                  <td className="p-3 tabular-nums">{formatBytes(Number(b.size_bytes))}</td>
                  <td className="p-3 hidden md:table-cell">
                    <span className={`inline-flex px-2 py-0.5 rounded text-xs ${b.status === "completed" ? "bg-emerald-500/15 text-emerald-600" : "bg-amber-500/15 text-amber-700"}`}>{b.status}</span>
                  </td>
                  <td className="p-3 text-muted-foreground text-xs hidden lg:table-cell">{b.restored_at ? new Date(b.restored_at).toLocaleString() : "—"}</td>
                  <td className="p-3 text-right">
                    <div className="inline-flex gap-1">
                      <button onClick={() => downloadMeta(b)} className="p-2 rounded hover:bg-accent text-muted-foreground" title="Download metadata"><Download className="h-4 w-4" /></button>
                      <button onClick={() => restore(b)} className="p-2 rounded hover:bg-accent text-muted-foreground" title="Tag as restored"><RotateCcw className="h-4 w-4" /></button>
                      <button onClick={() => remove(b)} className="p-2 rounded hover:bg-accent text-muted-foreground hover:text-destructive" title="Delete"><Trash2 className="h-4 w-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

function Stat({ label, value, sub, tone }: { label: string; value: string; sub?: string; tone?: "ok" | "warn" | "err" }) {
  const dot = tone === "ok" ? "bg-emerald-500" : tone === "warn" ? "bg-amber-500" : tone === "err" ? "bg-red-500" : "";
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="text-[11px] font-semibold uppercase tracking-[0.15em] text-muted-foreground flex items-center gap-1.5">
        {dot && <span className={`h-1.5 w-1.5 rounded-full ${dot}`} />}
        {label}
      </div>
      <div className="text-lg font-semibold mt-1 truncate">{value}</div>
      {sub && <div className="text-xs text-muted-foreground mt-0.5">{sub}</div>}
    </div>
  );
}

function formatBytes(n: number): string {
  if (!n) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  let i = 0;
  let v = n;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(v < 10 && i > 0 ? 1 : 0)} ${units[i]}`;
}

function PageSkeleton() {
  return <div className="space-y-4"><Skeleton className="h-10 w-64" /><Skeleton className="h-40 w-full" /></div>;
}
