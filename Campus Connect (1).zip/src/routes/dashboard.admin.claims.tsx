import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { StatusBadge } from "@/components/StatusBadge";
import { logAudit, createNotification } from "@/lib/tce";
import { Check, X, MessageSquareWarning, ExternalLink } from "lucide-react";

export const Route = createFileRoute("/dashboard/admin/claims")({
  component: ClaimsAdmin,
});

function ClaimsAdmin() {
  const [rows, setRows] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<string>("pending");
  const [noteById, setNoteById] = useState<Record<string, string>>({});

  const load = async () => {
    let query = supabase.from("claims").select("*, items(id,case_id,item_name,report_type,category,brand,colour,description,identification_marks,image_urls,general_location,incident_date)").order("created_at", { ascending: false });
    if (status !== "all") query = query.eq("status", status as any);
    const { data } = await query;
    setRows(data ?? []);
  };
  useEffect(() => { load(); }, [status]);

  const act = async (row: any, next: "approved" | "rejected" | "more_info") => {
    const noteText = noteById[row.id]?.trim();
    if (next === "more_info" && !noteText) return toast.error("Add a note about what info is needed");
    const merged = noteText ? appendNote(row.admin_notes, noteText) : row.admin_notes;
    const patch: any = next === "more_info"
      ? { admin_notes: merged, status: "more_info" }
      : { admin_notes: merged, status: next };
    const { error } = await supabase.from("claims").update(patch).eq("id", row.id);
    if (error) return toast.error(error.message);
    await logAudit({ action: `claim_${next}`, entity: "claims", entity_id: row.id, metadata: { case_id: row.case_id } });
    await createNotification({
      user_id: row.claimant_id,
      type: next === "approved" ? "claim_approved" : next === "rejected" ? "claim_rejected" : "more_info_requested",
      title: `Claim ${next.replace("_", " ")}`,
      message: `Your claim ${row.case_id} is now ${next.replace("_", " ")}.`,
      case_id: row.case_id,
    });
    toast.success("Updated");
    setNoteById((m) => ({ ...m, [row.id]: "" }));
    load();
  };

  const filtered = rows.filter((r) => !q || [r.case_id, r.items?.case_id, r.items?.item_name].some((f) => String(f ?? "").toLowerCase().includes(q.toLowerCase())));

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Claim Verification</h1>
        <p className="text-sm text-muted-foreground mt-1">Compare the claim with the original report and decide.</p>
      </header>
      <div className="flex gap-2 flex-wrap">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search claim, item, case…" className="max-w-sm" />
        <select value={status} onChange={(e) => setStatus(e.target.value)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
          <option value="pending">Pending</option>
          <option value="under_review">Under Review</option>
          <option value="more_info">More Info</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
          <option value="resolved">Resolved</option>
          <option value="all">All</option>
        </select>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-xl border border-dashed p-12 text-center text-sm text-muted-foreground">No claims.</div>
      ) : (
        <div className="space-y-3">
          {filtered.map((c) => (
            <div key={c.id} className="rounded-2xl border border-border bg-card p-4 space-y-3">
              <div className="flex flex-wrap justify-between gap-2">
                <div>
                  <div className="text-[11px] font-mono text-muted-foreground">Claim {c.case_id}</div>
                  <div className="font-medium">{c.items?.item_name}</div>
                  <div className="text-xs text-muted-foreground">Item {c.items?.case_id} · {c.items?.category}</div>
                </div>
                <div className="flex items-center gap-2">
                  <StatusBadge status={c.status} />
                  <Link to="/dashboard/case/$id" params={{ id: c.items?.id }} className="text-xs text-primary inline-flex items-center gap-1"><ExternalLink className="h-3 w-3" /> Case</Link>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-3 text-xs">
                <Panel title="Original Report">
                  <Row k="Item" v={c.items?.item_name} />
                  <Row k="Brand" v={c.items?.brand} />
                  <Row k="Colour" v={c.items?.colour} />
                  <Row k="Marks" v={c.items?.identification_marks} />
                  <Row k="Location" v={c.items?.general_location} />
                  <Row k="Date" v={c.items?.incident_date} />
                  <Row k="Description" v={c.items?.description} />
                </Panel>
                <Panel title="Claim Form">
                  <Row k="Reason" v={c.reason} />
                  <Row k="Brand" v={c.brand} />
                  <Row k="Colour" v={c.colour} />
                  <Row k="Marks" v={c.identification_marks} />
                  <Row k="Location" v={c.approx_location} />
                  <Row k="Date" v={c.approx_date} />
                  <Row k="Description" v={c.additional_desc} />
                </Panel>
              </div>

              {(c.items?.image_urls?.length || c.proof_urls?.length) && (
                <div className="grid md:grid-cols-2 gap-3">
                  <ThumbRow label="Report images" urls={c.items?.image_urls} />
                  <ThumbRow label="Proof" urls={c.proof_urls} />
                </div>
              )}

              {c.admin_notes && (
                <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-3">
                  <div className="text-[11px] font-semibold uppercase text-amber-700 dark:text-amber-400 mb-1">Private Notes</div>
                  <pre className="text-xs whitespace-pre-wrap font-sans">{c.admin_notes}</pre>
                </div>
              )}

              <Textarea rows={2} placeholder="Add private note or reason…" value={noteById[c.id] ?? ""} onChange={(e) => setNoteById((m) => ({ ...m, [c.id]: e.target.value }))} />
              <div className="flex flex-wrap gap-2">
                <Button size="sm" onClick={() => act(c, "approved")} className="gap-1"><Check className="h-4 w-4" /> Approve</Button>
                <Button size="sm" variant="destructive" onClick={() => act(c, "rejected")} className="gap-1"><X className="h-4 w-4" /> Reject</Button>
                <Button size="sm" variant="outline" onClick={() => act(c, "more_info")} className="gap-1"><MessageSquareWarning className="h-4 w-4" /> Request Info</Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function Panel({ title, children }: any) {
  return (
    <div className="rounded-lg border border-border p-3">
      <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-2">{title}</div>
      <dl className="space-y-1.5">{children}</dl>
    </div>
  );
}
function Row({ k, v }: any) {
  if (!v) return null;
  return <div className="grid grid-cols-3 gap-2"><dt className="text-muted-foreground">{k}</dt><dd className="col-span-2">{String(v)}</dd></div>;
}
function ThumbRow({ label, urls }: { label: string; urls?: string[] }) {
  if (!urls?.length) return null;
  return (
    <div>
      <div className="text-[10px] font-semibold uppercase text-muted-foreground mb-1">{label}</div>
      <div className="flex gap-2 flex-wrap">
        {urls.map((u, i) => (
          <a key={i} href={u} target="_blank" rel="noreferrer" className="h-20 w-20 rounded-md bg-muted overflow-hidden block">
            <img src={u} alt="" className="h-full w-full object-cover" />
          </a>
        ))}
      </div>
    </div>
  );
}
function appendNote(existing: string | null, note: string) {
  const stamp = new Date().toISOString();
  const line = `[${stamp}] ${note}`;
  return existing ? `${existing}\n${line}` : line;
}