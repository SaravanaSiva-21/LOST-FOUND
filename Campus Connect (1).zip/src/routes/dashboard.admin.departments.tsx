import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash2, Plus, Pencil, Check, X } from "lucide-react";
import { logAudit } from "@/lib/tce";

export const Route = createFileRoute("/dashboard/admin/departments")({
  component: Departments,
});

function Departments() {
  const [rows, setRows] = useState<any[]>([]);
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [editing, setEditing] = useState<string | null>(null);
  const [draft, setDraft] = useState<{ name: string; code: string }>({ name: "", code: "" });

  const load = async () => {
    const { data } = await supabase.from("departments").select("*").order("name");
    setRows(data ?? []);
  };
  useEffect(() => { load(); }, []);

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !code.trim()) return toast.error("Both name and code are required");
    const { error } = await supabase.from("departments").insert({ name: name.trim(), code: code.trim().toUpperCase() });
    if (error) return toast.error(error.message);
    await logAudit({ action: "department_added", entity: "departments", metadata: { name, code } });
    setName(""); setCode(""); load();
  };

  const save = async (id: string) => {
    const { error } = await supabase.from("departments").update({ name: draft.name.trim(), code: draft.code.trim().toUpperCase() }).eq("id", id);
    if (error) return toast.error(error.message);
    await logAudit({ action: "department_updated", entity: "departments", entity_id: id });
    setEditing(null); load();
  };

  const remove = async (id: string, n: string) => {
    if (!confirm(`Delete department "${n}"?`)) return;
    const { error } = await supabase.from("departments").delete().eq("id", id);
    if (error) return toast.error(error.message);
    await logAudit({ action: "department_deleted", entity: "departments", entity_id: id });
    load();
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Departments</h1>
        <p className="text-sm text-muted-foreground mt-1">Manage academic departments and their codes.</p>
      </header>
      <form onSubmit={add} className="rounded-2xl border border-border bg-card p-4 grid md:grid-cols-3 gap-2">
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Department name" />
        <Input value={code} onChange={(e) => setCode(e.target.value)} placeholder="Code (e.g. CSE)" />
        <Button type="submit" className="gap-1"><Plus className="h-4 w-4" /> Add Department</Button>
      </form>
      <div className="rounded-2xl border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="text-left px-4 py-3">Name</th>
              <th className="text-left px-4 py-3">Code</th>
              <th className="text-right px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t border-border">
                {editing === r.id ? (
                  <>
                    <td className="px-4 py-2"><Input value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} /></td>
                    <td className="px-4 py-2"><Input value={draft.code} onChange={(e) => setDraft({ ...draft, code: e.target.value })} /></td>
                    <td className="px-4 py-2 text-right space-x-1">
                      <Button size="sm" variant="ghost" onClick={() => save(r.id)}><Check className="h-4 w-4" /></Button>
                      <Button size="sm" variant="ghost" onClick={() => setEditing(null)}><X className="h-4 w-4" /></Button>
                    </td>
                  </>
                ) : (
                  <>
                    <td className="px-4 py-3">{r.name}</td>
                    <td className="px-4 py-3 font-mono">{r.code}</td>
                    <td className="px-4 py-3 text-right space-x-1">
                      <Button size="sm" variant="ghost" onClick={() => { setEditing(r.id); setDraft({ name: r.name, code: r.code }); }}><Pencil className="h-4 w-4" /></Button>
                      <Button size="sm" variant="ghost" onClick={() => remove(r.id, r.name)}><Trash2 className="h-4 w-4" /></Button>
                    </td>
                  </>
                )}
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={3} className="text-center text-muted-foreground text-sm py-10">No departments yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}