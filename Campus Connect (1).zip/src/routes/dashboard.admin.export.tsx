import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Download, FileSpreadsheet, FileJson } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { downloadFile, toCSV, logAudit } from "@/lib/tce";

export const Route = createFileRoute("/dashboard/admin/export")({
  component: ExportPage,
});

type Kind = "resolved" | "pending" | "lost" | "found" | "claims";

const OPTIONS: { key: Kind; label: string; desc: string }[] = [
  { key: "resolved", label: "Resolved Cases", desc: "All items with resolved or archived status." },
  { key: "pending", label: "Pending Cases", desc: "Items awaiting verification." },
  { key: "lost", label: "Lost Reports", desc: "Every lost item report ever submitted." },
  { key: "found", label: "Found Reports", desc: "Every found item report ever submitted." },
  { key: "claims", label: "Claims", desc: "All ownership claims and their status." },
];

async function fetchRows(kind: Kind) {
  if (kind === "claims") {
    const { data } = await supabase.from("claims").select("case_id,status,item_id,reason,brand,colour,approx_date,approx_location,created_at,updated_at").order("created_at", { ascending: false });
    return data ?? [];
  }
  let q = supabase.from("items").select("case_id,report_type,item_name,category,general_location,incident_date,status,created_at,updated_at").order("created_at", { ascending: false });
  if (kind === "resolved") q = q.in("status", ["resolved", "archived"]);
  if (kind === "pending") q = q.eq("status", "pending_verification");
  if (kind === "lost") q = q.eq("report_type", "lost");
  if (kind === "found") q = q.eq("report_type", "found");
  const { data } = await q;
  return data ?? [];
}

function ExportPage() {
  const [busy, setBusy] = useState<string | null>(null);

  const exportOne = async (kind: Kind, format: "csv" | "json") => {
    const key = `${kind}-${format}`;
    setBusy(key);
    try {
      const rows = await fetchRows(kind);
      if (rows.length === 0) { toast.info("No rows to export"); return; }
      const stamp = new Date().toISOString().slice(0, 10);
      if (format === "csv") {
        downloadFile(toCSV(rows as any), `tce-${kind}-${stamp}.csv`, "text/csv");
      } else {
        downloadFile(JSON.stringify(rows, null, 2), `tce-${kind}-${stamp}.json`, "application/json");
      }
      await logAudit({ action: "admin_export", entity: kind, metadata: { format, count: rows.length } });
      toast.success(`Exported ${rows.length} rows`);
    } catch (e: any) {
      toast.error(e.message ?? "Export failed");
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold flex items-center gap-2"><Download className="h-6 w-6 text-primary" /> Export Reports</h1>
        <p className="text-sm text-muted-foreground mt-1">Download portal data as CSV (Excel-compatible) or JSON.</p>
      </header>
      <div className="grid gap-3 md:grid-cols-2">
        {OPTIONS.map((o) => (
          <div key={o.key} className="rounded-2xl border border-border bg-card p-5 space-y-3">
            <div>
              <div className="font-semibold">{o.label}</div>
              <div className="text-xs text-muted-foreground mt-1">{o.desc}</div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button size="sm" variant="outline" disabled={busy === `${o.key}-csv`} onClick={() => exportOne(o.key, "csv")} className="gap-1">
                <FileSpreadsheet className="h-4 w-4" /> {busy === `${o.key}-csv` ? "..." : "CSV / Excel"}
              </Button>
              <Button size="sm" variant="outline" disabled={busy === `${o.key}-json`} onClick={() => exportOne(o.key, "json")} className="gap-1">
                <FileJson className="h-4 w-4" /> {busy === `${o.key}-json` ? "..." : "JSON"}
              </Button>
            </div>
          </div>
        ))}
      </div>
      <p className="text-xs text-muted-foreground">CSV files open directly in Microsoft Excel, Google Sheets, and LibreOffice Calc. Every export is recorded in the audit log.</p>
    </div>
  );
}