import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Star } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/dashboard/admin/feedback")({
  component: FeedbackAdmin,
});

function FeedbackAdmin() {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("feedback")
        .select("id,rating,comment,suggestions,recommend,created_at,user:profiles!feedback_user_id_fkey(full_name,department),claim:claims!feedback_claim_id_fkey(case_id)")
        .order("created_at", { ascending: false })
        .limit(100);
      setRows(data ?? []);
      setLoading(false);
    })();
  }, []);

  const avg = rows.length ? (rows.reduce((s, r) => s + r.rating, 0) / rows.length).toFixed(2) : "—";
  const recommendPct = rows.length ? Math.round((rows.filter((r) => r.recommend === true).length / rows.length) * 100) : 0;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold flex items-center gap-2"><Star className="h-6 w-6 text-primary" /> Feedback</h1>
        <p className="text-sm text-muted-foreground mt-1">User feedback on resolved cases.</p>
      </header>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        <Stat label="Total Responses" v={rows.length} />
        <Stat label="Average Rating" v={avg} />
        <Stat label="Would Recommend" v={`${recommendPct}%`} />
      </div>
      {loading ? (
        <div className="rounded-2xl border border-border bg-card h-40 animate-pulse" />
      ) : rows.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border p-12 text-center text-muted-foreground">No feedback yet.</div>
      ) : (
        <div className="space-y-3">
          {rows.map((r) => (
            <div key={r.id} className="rounded-2xl border border-border bg-card p-5">
              <div className="flex justify-between items-start gap-2 flex-wrap">
                <div>
                  <div className="text-sm font-medium">{r.user?.full_name ?? "User"} <span className="text-xs text-muted-foreground">· {r.user?.department}</span></div>
                  <div className="text-[11px] font-mono text-muted-foreground">{r.claim?.case_id}</div>
                </div>
                <div className="flex items-center gap-1">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className={`h-4 w-4 ${i < r.rating ? "fill-amber-400 text-amber-400" : "text-muted"}`} />
                  ))}
                </div>
              </div>
              {r.comment && <p className="text-sm mt-2">{r.comment}</p>}
              {r.suggestions && <p className="text-xs text-muted-foreground mt-1"><b>Suggestions:</b> {r.suggestions}</p>}
              <div className="text-[11px] text-muted-foreground mt-2">
                Recommend: <b>{r.recommend === true ? "Yes" : r.recommend === false ? "No" : "—"}</b> · {new Date(r.created_at).toLocaleString()}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function Stat({ label, v }: { label: string; v: any }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="text-2xl font-bold tabular-nums">{v}</div>
      <div className="text-xs text-muted-foreground mt-1">{label}</div>
    </div>
  );
}