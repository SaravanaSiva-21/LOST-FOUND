import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Bell, CheckCircle2, Handshake, RotateCcw, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { StatusBadge } from "@/components/StatusBadge";
import { createNotification, logAudit } from "@/lib/tce";

export const Route = createFileRoute("/dashboard/admin/handover")({
  component: HandoverAdmin,
});

type Row = any;

function HandoverAdmin() {
  const [rows, setRows] = useState<Row[]>([]);
  const [q, setQ] = useState("");
  const [tab, setTab] = useState<"active" | "ready" | "overdue" | "all">("active");
  const [busy, setBusy] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("claims")
      .select(
        `id, case_id, status, contact_shared_at, contact_shared_by,
         finder_confirmed, finder_confirmed_at, finder_confirm_remarks,
         owner_confirmed, owner_confirmed_at, owner_confirm_remarks,
         reminder_sent, reminder_sent_at, resolved_at,
         claimant:profiles!claims_claimant_id_fkey(id,full_name,email,phone,department),
         items!claims_item_id_fkey(id,case_id,item_name,reporter_id,report_type,reporter:profiles!items_reporter_id_fkey(full_name,email,phone,department))`,
      )
      .not("contact_shared_at", "is", null)
      .order("contact_shared_at", { ascending: false });
    setRows(data ?? []);
    setLoading(false);
  };

  useEffect(() => {
    load();
    const ch = supabase
      .channel("admin-handover")
      .on("postgres_changes", { event: "*", schema: "public", table: "claims" }, () => load())
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, []);

  const filtered = useMemo(() => {
    const now = Date.now();
    return rows.filter((r) => {
      const both = r.finder_confirmed && r.owner_confirmed;
      const shared = r.contact_shared_at ? new Date(r.contact_shared_at).getTime() : 0;
      const overdue = shared > 0 && !both && r.status === "approved" && (now - shared) > 24 * 60 * 60 * 1000;
      if (tab === "active" && (r.status === "resolved" || both)) return false;
      if (tab === "ready" && !(both && r.status === "approved")) return false;
      if (tab === "overdue" && !overdue) return false;
      if (q) {
        const hay = [
          r.case_id, r.items?.case_id, r.items?.item_name,
          r.claimant?.full_name, r.claimant?.email,
          r.items?.reporter?.full_name, r.items?.reporter?.email,
        ].join(" ").toLowerCase();
        if (!hay.includes(q.toLowerCase())) return false;
      }
      return true;
    });
  }, [rows, tab, q]);

  const sendReminder = async (r: Row) => {
    setBusy(r.id);
    const caseRef = r.items?.case_id ?? r.case_id;
    const msg = `Our records show that case ${caseRef} has not yet been completed. Please confirm whether the item has been handed over or received. If the exchange has already occurred, kindly update the status in the portal.`;
    await Promise.all([
      createNotification({ user_id: r.claimant?.id, type: "handover_reminder", title: "Handover reminder", message: msg, case_id: caseRef }),
      r.items?.reporter_id
        ? createNotification({ user_id: r.items.reporter_id, type: "handover_reminder", title: "Handover reminder", message: msg, case_id: caseRef })
        : Promise.resolve(),
    ]);
    await supabase.from("claims").update({ reminder_sent: true, reminder_sent_at: new Date().toISOString() }).eq("id", r.id);
    await logAudit({ action: "handover_reminder_sent", entity: "claim", entity_id: r.id });
    toast.success("Reminder sent to both users");
    setBusy(null);
  };

  const markResolved = async (r: Row) => {
    setBusy(r.id);
    const caseRef = r.items?.case_id ?? r.case_id;
    await supabase.from("claims").update({ status: "resolved", resolved_at: new Date().toISOString() }).eq("id", r.id);
    await supabase.from("items").update({ status: "resolved" }).eq("id", r.items?.id);
    await Promise.all([
      createNotification({ user_id: r.claimant?.id, type: "case_resolved", title: "Case resolved", message: `Case ${caseRef} has been marked resolved. Thank you for using the portal.`, case_id: caseRef }),
      r.items?.reporter_id
        ? createNotification({ user_id: r.items.reporter_id, type: "case_resolved", title: "Case resolved", message: `Case ${caseRef} has been marked resolved. Thank you for using the portal.`, case_id: caseRef })
        : Promise.resolve(),
    ]);
    await logAudit({ action: "case_resolved", entity: "claim", entity_id: r.id });
    toast.success(`Case ${caseRef} resolved`);
    setBusy(null);
  };

  const reopen = async (r: Row) => {
    if (!confirm("Reopen this case? The finder and owner confirmations will be reset.")) return;
    setBusy(r.id);
    await supabase.from("claims").update({
      status: "approved",
      resolved_at: null,
      finder_confirmed: false, finder_confirmed_at: null, finder_confirm_remarks: null,
      owner_confirmed: false, owner_confirmed_at: null, owner_confirm_remarks: null,
      reminder_sent: false, reminder_sent_at: null,
    }).eq("id", r.id);
    await supabase.from("items").update({ status: "claimed" }).eq("id", r.items?.id);
    await logAudit({ action: "case_reopened", entity: "claim", entity_id: r.id });
    toast.success("Case reopened");
    setBusy(null);
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold flex items-center gap-2"><Handshake className="h-6 w-6 text-primary" /> Handover Confirmation</h1>
        <p className="text-sm text-muted-foreground mt-1">Cases where contact details have been shared. Track confirmations, send reminders, and resolve completed handovers.</p>
      </header>

      <div className="flex flex-wrap gap-2 items-center">
        {(["active", "ready", "overdue", "all"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium border ${tab === t ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:text-foreground"}`}
          >
            {t === "active" ? "Active" : t === "ready" ? "Ready to Resolve" : t === "overdue" ? "Overdue (24h+)" : "All"}
          </button>
        ))}
        <div className="ml-auto relative">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search case, owner, finder…" className="pl-9 max-w-sm" />
        </div>
      </div>

      {loading ? (
        <div className="rounded-2xl border border-border bg-card h-40 animate-pulse" />
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border p-12 text-center">
          <Handshake className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">No handovers match this filter.</p>
        </div>
      ) : (
        <div className="rounded-2xl border border-border bg-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[900px]">
              <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
                <tr>
                  <th className="text-left px-4 py-3">Case</th>
                  <th className="text-left px-4 py-3">Owner</th>
                  <th className="text-left px-4 py-3">Finder</th>
                  <th className="text-left px-4 py-3">Shared</th>
                  <th className="text-left px-4 py-3">Finder</th>
                  <th className="text-left px-4 py-3">Owner</th>
                  <th className="text-left px-4 py-3">Status</th>
                  <th className="text-left px-4 py-3">Elapsed</th>
                  <th className="text-right px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((r) => {
                  const both = r.finder_confirmed && r.owner_confirmed;
                  const status = r.status === "resolved" ? "resolved"
                    : both ? "owner_confirmed"
                    : r.finder_confirmed ? "waiting_owner"
                    : r.owner_confirmed ? "waiting_finder"
                    : "waiting_handover";
                  return (
                    <tr key={r.id} className="border-t border-border align-top">
                      <td className="px-4 py-3">
                        <Link to="/dashboard/case/$id" params={{ id: r.items?.id }} className="text-primary hover:underline font-mono text-xs">
                          {r.items?.case_id}
                        </Link>
                        <div className="text-[11px] text-muted-foreground">{r.items?.item_name}</div>
                        <div className="text-[10px] font-mono text-muted-foreground mt-0.5">Claim {r.case_id}</div>
                      </td>
                      <td className="px-4 py-3">
                        <div>{r.claimant?.full_name ?? "—"}</div>
                        <div className="text-[11px] text-muted-foreground">{r.claimant?.email}</div>
                      </td>
                      <td className="px-4 py-3">
                        <div>{r.items?.reporter?.full_name ?? "—"}</div>
                        <div className="text-[11px] text-muted-foreground">{r.items?.reporter?.email}</div>
                      </td>
                      <td className="px-4 py-3 text-xs whitespace-nowrap">{r.contact_shared_at ? new Date(r.contact_shared_at).toLocaleString() : "—"}</td>
                      <td className="px-4 py-3">{r.finder_confirmed ? <span className="text-emerald-600 text-xs">✓</span> : <span className="text-muted-foreground text-xs">—</span>}</td>
                      <td className="px-4 py-3">{r.owner_confirmed ? <span className="text-emerald-600 text-xs">✓</span> : <span className="text-muted-foreground text-xs">—</span>}</td>
                      <td className="px-4 py-3"><StatusBadge status={status} /></td>
                      <td className="px-4 py-3 text-xs whitespace-nowrap">{elapsed(r.contact_shared_at)}</td>
                      <td className="px-4 py-3 text-right space-x-1 whitespace-nowrap">
                        {r.status !== "resolved" && !both && (
                          <Button size="sm" variant="outline" onClick={() => sendReminder(r)} disabled={busy === r.id} className="gap-1">
                            <Bell className="h-3.5 w-3.5" /> Remind
                          </Button>
                        )}
                        {both && r.status !== "resolved" && (
                          <Button size="sm" onClick={() => markResolved(r)} disabled={busy === r.id} className="gap-1">
                            <CheckCircle2 className="h-3.5 w-3.5" /> Resolve
                          </Button>
                        )}
                        {r.status === "resolved" && (
                          <Button size="sm" variant="ghost" onClick={() => reopen(r)} disabled={busy === r.id} className="gap-1">
                            <RotateCcw className="h-3.5 w-3.5" /> Reopen
                          </Button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

function elapsed(iso?: string | null) {
  if (!iso) return "—";
  const ms = Date.now() - new Date(iso).getTime();
  const hours = Math.floor(ms / 3_600_000);
  if (hours < 1) return "<1h";
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  const remHours = hours % 24;
  return `${days}d ${remHours}h`;
}