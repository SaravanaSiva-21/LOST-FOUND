import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Activity, CheckCircle2, Database, HardDrive, KeyRound, Mail, RefreshCw, Wifi, XCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/dashboard/admin/health")({
  component: HealthPage,
});

type Check = {
  key: string;
  label: string;
  icon: any;
  status: "ok" | "warn" | "err" | "unknown";
  latency_ms?: number;
  detail?: string;
};

const STORAGE_BUCKETS = ["avatars", "item-images", "lost-items", "found-items", "claim-documents", "claim-proofs", "site-assets"];

function HealthPage() {
  const { isAdmin, loading: authLoading } = useAuth();
  const [checks, setChecks] = useState<Check[]>([]);
  const [storageUsed, setStorageUsed] = useState<number | null>(null);
  const [running, setRunning] = useState(false);
  const [lastRun, setLastRun] = useState<string | null>(null);

  const run = async () => {
    setRunning(true);
    const next: Check[] = [];

    // 1. Database
    let t = performance.now();
    try {
      const { error } = await supabase.from("profiles").select("id", { head: true, count: "exact" }).limit(1);
      const ms = Math.round(performance.now() - t);
      next.push({ key: "db", label: "Database", icon: Database, status: error ? "err" : "ok", latency_ms: ms, detail: error?.message ?? "Query succeeded" });
    } catch (e: any) {
      next.push({ key: "db", label: "Database", icon: Database, status: "err", detail: e.message });
    }

    // 2. Auth
    t = performance.now();
    try {
      const { data, error } = await supabase.auth.getSession();
      const ms = Math.round(performance.now() - t);
      next.push({ key: "auth", label: "Authentication", icon: KeyRound, status: error ? "err" : "ok", latency_ms: ms, detail: error?.message ?? (data.session ? "Session active" : "Service reachable") });
    } catch (e: any) {
      next.push({ key: "auth", label: "Authentication", icon: KeyRound, status: "err", detail: e.message });
    }

    // 3. Storage — list buckets and sum object sizes
    t = performance.now();
    let totalBytes = 0;
    let storageStatus: Check["status"] = "ok";
    let storageDetail = "";
    try {
      for (const b of STORAGE_BUCKETS) {
        const { data, error } = await supabase.storage.from(b).list("", { limit: 1000, sortBy: { column: "created_at", order: "desc" } });
        if (error) { storageStatus = "warn"; storageDetail = `${b}: ${error.message}`; continue; }
        (data ?? []).forEach((o: any) => { totalBytes += Number(o.metadata?.size ?? 0); });
      }
      setStorageUsed(totalBytes);
      const ms = Math.round(performance.now() - t);
      next.push({ key: "storage", label: "Storage", icon: HardDrive, status: storageStatus, latency_ms: ms, detail: storageDetail || `${STORAGE_BUCKETS.length} buckets reachable` });
    } catch (e: any) {
      next.push({ key: "storage", label: "Storage", icon: HardDrive, status: "err", detail: e.message });
    }

    // 4. Realtime — subscribe briefly and confirm SUBSCRIBED
    t = performance.now();
    const realtimeResult = await new Promise<Check>((resolve) => {
      const ch = supabase.channel(`health-${Date.now()}`);
      const timer = setTimeout(() => {
        supabase.removeChannel(ch);
        resolve({ key: "realtime", label: "Realtime", icon: Wifi, status: "warn", detail: "No response within 3s" });
      }, 3000);
      ch.subscribe((status) => {
        if (status === "SUBSCRIBED") {
          clearTimeout(timer);
          const ms = Math.round(performance.now() - t);
          supabase.removeChannel(ch);
          resolve({ key: "realtime", label: "Realtime", icon: Wifi, status: "ok", latency_ms: ms, detail: "Channel subscribed" });
        } else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT") {
          clearTimeout(timer);
          supabase.removeChannel(ch);
          resolve({ key: "realtime", label: "Realtime", icon: Wifi, status: "err", detail: status });
        }
      });
    });
    next.push(realtimeResult);

    // 5. Email — not configured in this build
    next.push({ key: "email", label: "Email Service", icon: Mail, status: "warn", detail: "Not configured — set up a sender domain to enable branded emails." });

    setChecks(next);
    setLastRun(new Date().toLocaleString());
    setRunning(false);
  };

  useEffect(() => { run(); }, []);

  if (authLoading) return <div className="space-y-4"><Skeleton className="h-10 w-64" /><Skeleton className="h-40 w-full" /></div>;
  if (!isAdmin) {
    return <div className="rounded-2xl border border-border bg-card p-8 text-center text-sm text-muted-foreground">Administrator privileges required.</div>;
  }

  const overall = checks.some((c) => c.status === "err") ? "err" : checks.some((c) => c.status === "warn") ? "warn" : "ok";

  return (
    <div className="space-y-6">
      <header className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Activity className="h-6 w-6 text-primary" /> System Health
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Live status of every backend service the portal depends on.
            {lastRun && <> Last check: <span className="font-medium">{lastRun}</span>.</>}
          </p>
        </div>
        <Button onClick={run} disabled={running} variant="outline" size="sm" className="gap-2">
          <RefreshCw className={`h-4 w-4 ${running ? "animate-spin" : ""}`} /> Re-run checks
        </Button>
      </header>

      <div className={`rounded-2xl border p-4 flex items-center gap-3 ${overall === "ok" ? "border-emerald-500/40 bg-emerald-500/5" : overall === "warn" ? "border-amber-500/40 bg-amber-500/5" : "border-red-500/40 bg-red-500/5"}`}>
        {overall === "ok" ? <CheckCircle2 className="h-6 w-6 text-emerald-600" /> : <XCircle className={`h-6 w-6 ${overall === "warn" ? "text-amber-600" : "text-red-600"}`} />}
        <div>
          <div className="font-semibold">
            {overall === "ok" ? "All systems operational" : overall === "warn" ? "Operational with warnings" : "Service degradation detected"}
          </div>
          <div className="text-xs text-muted-foreground">
            Storage used: <span className="font-medium">{storageUsed !== null ? formatBytes(storageUsed) : "—"}</span> across {STORAGE_BUCKETS.length} buckets.
          </div>
        </div>
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        {running && checks.length === 0
          ? Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-24 w-full rounded-2xl" />)
          : checks.map((c) => <ServiceCard key={c.key} check={c} />)}
      </div>
    </div>
  );
}

function ServiceCard({ check }: { check: Check }) {
  const tone = check.status === "ok" ? "border-emerald-500/30 bg-emerald-500/5" : check.status === "warn" ? "border-amber-500/30 bg-amber-500/5" : check.status === "err" ? "border-red-500/30 bg-red-500/5" : "border-border bg-card";
  const dot = check.status === "ok" ? "bg-emerald-500" : check.status === "warn" ? "bg-amber-500" : check.status === "err" ? "bg-red-500" : "bg-muted-foreground";
  const label = check.status === "ok" ? "Operational" : check.status === "warn" ? "Warning" : check.status === "err" ? "Error" : "Unknown";
  const Icon = check.icon;
  return (
    <div className={`rounded-2xl border p-4 ${tone}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2 min-w-0">
          <div className="h-9 w-9 rounded-lg bg-background border border-border grid place-items-center shrink-0">
            <Icon className="h-4 w-4" />
          </div>
          <div className="min-w-0">
            <div className="font-semibold text-sm truncate">{check.label}</div>
            <div className="text-xs text-muted-foreground truncate">{check.detail ?? "—"}</div>
          </div>
        </div>
        <div className="text-right shrink-0">
          <div className="inline-flex items-center gap-1.5 text-xs font-medium">
            <span className={`h-2 w-2 rounded-full ${dot}`} />{label}
          </div>
          {check.latency_ms !== undefined && <div className="text-[10px] text-muted-foreground mt-0.5 tabular-nums">{check.latency_ms}ms</div>}
        </div>
      </div>
    </div>
  );
}

function formatBytes(n: number): string {
  if (!n) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  let i = 0;
  let v = n;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(v < 10 && i > 0 ? 1 : 0)} ${units[i]}`;
}
