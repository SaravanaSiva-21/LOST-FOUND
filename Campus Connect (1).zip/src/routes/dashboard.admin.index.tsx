import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { BarChart3, Shield, Users, History, Mail, Handshake, Star, Download, FileSearch, ClipboardList, GitCompare, Building2, Bell, LineChart as LineIcon } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

export const Route = createFileRoute("/dashboard/admin/")({
  component: AdminOverview,
});

function AdminOverview() {
  const [s, setS] = useState({
    users: 0, approvedUsers: 0, lost: 0, found: 0,
    pendingItems: 0, pendingClaims: 0, activeCases: 0, awaitingHandover: 0,
    resolved: 0, itemsTotal: 0, pendingFinal: 0, avgRating: "—" as string, feedbackCount: 0,
    avgResolutionDays: "—" as string,
    categories: [] as { category: string; count: number }[],
    locations: [] as { location: string; count: number }[],
    monthly: [] as { month: string; lost: number; found: number }[],
  });

  useEffect(() => {
    (async () => {
      const [users, approvedUsers, lost, found, pi, pc, activeCases, awaitingHandover, resolved, itemsTotal, cats, locs, pendingFinal, feedback, resolvedRows, monthlyRows] = await Promise.all([
        supabase.from("profiles").select("id", { count: "exact", head: true }),
        supabase.from("profiles").select("id", { count: "exact", head: true }).eq("is_suspended", false),
        supabase.from("items").select("id", { count: "exact", head: true }).eq("report_type", "lost"),
        supabase.from("items").select("id", { count: "exact", head: true }).eq("report_type", "found"),
        supabase.from("items").select("id", { count: "exact", head: true }).eq("status", "pending_verification"),
        supabase.from("claims").select("id", { count: "exact", head: true }).eq("status", "pending"),
        supabase.from("items").select("id", { count: "exact", head: true }).in("status", ["approved", "matched", "claimed", "handed_over"] as any),
        supabase.from("claims").select("id", { count: "exact", head: true }).eq("status", "approved").not("contact_shared_at", "is", null),
        supabase.from("items").select("id", { count: "exact", head: true }).eq("status", "resolved"),
        supabase.from("items").select("id", { count: "exact", head: true }),
        supabase.from("items").select("category").eq("report_type", "lost").limit(500),
        supabase.from("items").select("general_location").eq("report_type", "found").limit(500),
        supabase.from("claims").select("id", { count: "exact", head: true }).eq("status", "approved").eq("finder_confirmed", true).eq("owner_confirmed", true),
        supabase.from("feedback").select("rating"),
        supabase.from("items").select("created_at,updated_at").eq("status", "resolved").limit(500),
        supabase.from("items").select("report_type,created_at").gte("created_at", new Date(new Date().getFullYear(), new Date().getMonth() - 11, 1).toISOString()).limit(2000),
      ]);
      const catCounts: Record<string, number> = {};
      (cats.data ?? []).forEach((r: any) => { catCounts[r.category] = (catCounts[r.category] ?? 0) + 1; });
      const locCounts: Record<string, number> = {};
      (locs.data ?? []).forEach((r: any) => { locCounts[r.general_location] = (locCounts[r.general_location] ?? 0) + 1; });
      const fb = feedback.data ?? [];
      const avg = fb.length ? (fb.reduce((s: number, r: any) => s + r.rating, 0) / fb.length).toFixed(2) : "—";
      const done = resolvedRows.data ?? [];
      const avgDays = done.length
        ? (done.reduce((sum: number, r: any) => sum + (new Date(r.updated_at).getTime() - new Date(r.created_at).getTime()), 0) / done.length / (1000 * 60 * 60 * 24)).toFixed(1) + " d"
        : "—";
      const buckets: Record<string, { month: string; lost: number; found: number }> = {};
      const now = new Date();
      for (let i = 11; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
        buckets[key] = { month: d.toLocaleString(undefined, { month: "short" }), lost: 0, found: 0 };
      }
      (monthlyRows.data ?? []).forEach((r: any) => {
        const d = new Date(r.created_at);
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
        if (!buckets[key]) return;
        if (r.report_type === "lost") buckets[key].lost += 1;
        else buckets[key].found += 1;
      });
      setS({
        users: users.count ?? 0,
        approvedUsers: approvedUsers.count ?? 0,
        lost: lost.count ?? 0,
        found: found.count ?? 0,
        pendingItems: pi.count ?? 0,
        pendingClaims: pc.count ?? 0,
        activeCases: activeCases.count ?? 0,
        awaitingHandover: awaitingHandover.count ?? 0,
        resolved: resolved.count ?? 0,
        itemsTotal: itemsTotal.count ?? 0,
        pendingFinal: pendingFinal.count ?? 0,
        avgRating: avg,
        feedbackCount: fb.length,
        avgResolutionDays: avgDays,
        categories: Object.entries(catCounts).map(([category, count]) => ({ category, count })).sort((a, b) => b.count - a.count).slice(0, 5),
        locations: Object.entries(locCounts).map(([location, count]) => ({ location, count })).sort((a, b) => b.count - a.count).slice(0, 5),
        monthly: Object.values(buckets),
      });
    })();
  }, []);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Admin Overview</h1>
        <p className="text-sm text-muted-foreground mt-1">Portal statistics and pending administrative tasks.</p>
      </header>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Stat label="Registered Users" v={s.users} />
        <Stat label="Approved Users" v={s.approvedUsers} />
        <Stat label="Lost Reports" v={s.lost} />
        <Stat label="Found Reports" v={s.found} />
        <Stat label="Pending Verifications" v={s.pendingItems} tone="amber" />
        <Stat label="Pending Claims" v={s.pendingClaims} tone="amber" />
        <Stat label="Active Cases" v={s.activeCases} />
        <Stat label="Awaiting Handover" v={s.awaitingHandover} />
        <Stat label="Resolved Cases" v={s.resolved} />
        <Stat label="Avg. Resolution" v={s.avgResolutionDays} />
        <Stat label="Avg. Feedback" v={s.avgRating} />
        <Stat label="Pending Final Resolution" v={s.pendingFinal} tone="amber" />
      </div>

      <Panel title="Monthly Statistics — Lost vs Found">
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={s.monthly}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="month" fontSize={11} />
              <YAxis fontSize={11} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="lost" fill="#ef4444" />
              <Bar dataKey="found" fill="#10b981" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Panel>

      <div className="grid md:grid-cols-2 gap-4">
        <Panel title="Most Lost Categories">
          {s.categories.length === 0 ? <p className="text-xs text-muted-foreground">No data yet.</p> : (
            <ul className="space-y-2">
              {s.categories.map((c) => (
                <li key={c.category} className="flex justify-between text-sm"><span>{c.category}</span><span className="font-mono text-muted-foreground">{c.count}</span></li>
              ))}
            </ul>
          )}
        </Panel>
        <Panel title="Most Common Found Locations">
          {s.locations.length === 0 ? <p className="text-xs text-muted-foreground">No data yet.</p> : (
            <ul className="space-y-2">
              {s.locations.map((l) => (
                <li key={l.location} className="flex justify-between text-sm"><span>{l.location}</span><span className="font-mono text-muted-foreground">{l.count}</span></li>
              ))}
            </ul>
          )}
        </Panel>
      </div>

      <div className="grid md:grid-cols-2 gap-3">
        <Quick to="/dashboard/admin/lost" title="Lost Reports" desc="Verify pending lost items." Icon={FileSearch} />
        <Quick to="/dashboard/admin/found" title="Found Reports" desc="Verify pending found items." Icon={ClipboardList} />
        <Quick to="/dashboard/admin/claims" title="Claim Verification" desc="Compare claims to reports." Icon={Shield} />
        <Quick to="/dashboard/admin/matches" title="Potential Matches" desc="Auto-scored lost/found pairs." Icon={GitCompare} />
        <Quick to="/dashboard/admin/handover" title="Handover Confirmation" desc="Track contact sharing, finder / owner confirmations, and resolve cases." Icon={Handshake} />
        <Quick to="/dashboard/admin/analytics" title="Analytics" desc="Charts and portal trends." Icon={LineIcon} />
        <Quick to="/dashboard/admin/departments" title="Departments" desc="Manage academic departments." Icon={Building2} />
        <Quick to="/dashboard/admin/notifications" title="Notifications" desc="Admin alerts in real time." Icon={Bell} />
        <Quick to="/dashboard/admin/feedback" title="Feedback" desc="Ratings and suggestions from users." Icon={Star} />
        <Quick to="/dashboard/admin/export" title="Export Reports" desc="Download portal data as CSV or JSON." Icon={Download} />
        <Quick to="/dashboard/admin/users" title="Manage Users" desc="Suspend, delete, and review activity." Icon={Users} />
        <Quick to="/dashboard/admin/whitelist" title="Whitelist Emails" desc="Add or remove approved TCE emails." Icon={Mail} />
        <Quick to="/dashboard/admin/audit" title="Audit Logs" desc="Every recorded action on the portal." Icon={History} />
      </div>
    </div>
  );
}

function Stat({ label, v, tone }: any) {
  return <div className={`rounded-2xl border p-4 ${tone === "amber" ? "border-amber-500/30 bg-amber-500/5" : "border-border bg-card"}`}>
    <div className="text-2xl font-bold tabular-nums">{v}</div><div className="text-xs text-muted-foreground mt-1">{label}</div></div>;
}
function Panel({ title, children }: any) {
  return <div className="rounded-2xl border border-border bg-card p-4"><div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2"><BarChart3 className="h-3.5 w-3.5" /> {title}</div>{children}</div>;
}
function Quick({ to, title, desc, Icon }: any) {
  return <Link to={to} className="rounded-2xl border border-border bg-card p-4 flex gap-3 hover:border-primary/40"><div className="h-10 w-10 rounded-xl bg-primary/10 text-primary grid place-items-center"><Icon className="h-5 w-5" /></div><div><div className="font-medium">{title}</div><div className="text-xs text-muted-foreground">{desc}</div></div></Link>;
}