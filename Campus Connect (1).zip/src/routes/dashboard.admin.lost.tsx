import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { AdminReportCard } from "@/components/AdminReportCard";

export const Route = createFileRoute("/dashboard/admin/lost")({
  component: LostReports,
});

function LostReports() {
  const [rows, setRows] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<string>("pending_verification");

  const load = async () => {
    let query = supabase.from("items").select("*").eq("report_type", "lost").order("created_at", { ascending: false });
    if (status !== "all") query = query.eq("status", status as any);
    const { data } = await query;
    setRows(data ?? []);
  };
  useEffect(() => { load(); }, [status]);

  const filtered = rows.filter((r) => !q || [r.case_id, r.item_name, r.category, r.general_location].some((f) => String(f ?? "").toLowerCase().includes(q.toLowerCase())));

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Lost Reports</h1>
        <p className="text-sm text-muted-foreground mt-1">Verify pending lost-item reports and manage approvals.</p>
      </header>
      <div className="flex gap-2 flex-wrap">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search case, item, category…" className="max-w-sm" />
        <select value={status} onChange={(e) => setStatus(e.target.value)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
          <option value="pending_verification">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
          <option value="matched">Matched</option>
          <option value="resolved">Resolved</option>
          <option value="all">All</option>
        </select>
      </div>
      {filtered.length === 0 ? (
        <div className="rounded-xl border border-dashed p-12 text-center text-sm text-muted-foreground">No lost reports.</div>
      ) : (
        <div className="space-y-3">
          {filtered.map((r) => <AdminReportCard key={r.id} item={r} onChange={load} />)}
        </div>
      )}
    </div>
  );
}