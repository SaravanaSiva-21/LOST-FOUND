import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/dashboard/admin/matches")({
  component: MatchesPage,
});

type Item = any;

function score(a: Item, b: Item) {
  let s = 0;
  const nm = (x: string | null | undefined) => (x ?? "").trim().toLowerCase();
  if (nm(a.item_name) === nm(b.item_name) && nm(a.item_name)) s += 3;
  if (nm(a.brand) && nm(a.brand) === nm(b.brand)) s += 2;
  if (nm(a.colour) && nm(a.colour) === nm(b.colour)) s += 2;
  if (a.category === b.category) s += 2;
  if (a.general_location === b.general_location) s += 1;
  return s;
}

function MatchesPage() {
  const [pairs, setPairs] = useState<{ lost: Item; found: Item; pct: number }[]>([]);
  const [ignored, setIgnored] = useState<Record<string, boolean>>({});

  const load = async () => {
    const [{ data: lost }, { data: found }] = await Promise.all([
      supabase.from("items").select("*").eq("report_type", "lost").in("status", ["approved", "pending_verification", "matched"]).limit(200),
      supabase.from("items").select("*").eq("report_type", "found").in("status", ["approved", "pending_verification", "matched"]).limit(200),
    ]);
    const out: { lost: Item; found: Item; pct: number }[] = [];
    (lost ?? []).forEach((l) => {
      (found ?? []).forEach((f) => {
        const s = score(l, f);
        if (s >= 3) out.push({ lost: l, found: f, pct: Math.min(100, Math.round((s / 10) * 100)) });
      });
    });
    out.sort((a, b) => b.pct - a.pct);
    setPairs(out.slice(0, 100));
  };
  useEffect(() => { load(); }, []);

  const accept = async (l: Item, f: Item) => {
    await Promise.all([
      supabase.from("items").update({ status: "matched" as any }).eq("id", l.id),
      supabase.from("items").update({ status: "matched" as any }).eq("id", f.id),
    ]);
    load();
  };

  const visible = pairs.filter((p) => !ignored[`${p.lost.id}-${p.found.id}`]);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Potential Matches</h1>
        <p className="text-sm text-muted-foreground mt-1">Auto-scored candidate pairs. Accept to mark both cases as matched.</p>
      </header>
      {visible.length === 0 ? (
        <div className="rounded-xl border border-dashed p-12 text-center text-sm text-muted-foreground">No candidate matches right now.</div>
      ) : (
        <div className="space-y-3">
          {visible.map((p) => {
            const k = `${p.lost.id}-${p.found.id}`;
            return (
              <div key={k} className="rounded-2xl border border-border bg-card p-4">
                <div className="flex justify-between flex-wrap gap-2 mb-3">
                  <div className="text-sm font-semibold">Similarity {p.pct}%</div>
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => accept(p.lost, p.found)}>Accept Match</Button>
                    <Button size="sm" variant="outline" onClick={() => setIgnored((m) => ({ ...m, [k]: true }))}>Ignore</Button>
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-3">
                  <MatchCard label="LOST" item={p.lost} tone="text-red-600" />
                  <MatchCard label="FOUND" item={p.found} tone="text-emerald-600" />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function MatchCard({ label, item, tone }: { label: string; item: any; tone: string }) {
  return (
    <Link to="/dashboard/case/$id" params={{ id: item.id }} className="block rounded-xl border border-border p-3 hover:border-primary/40">
      <div className={`text-[10px] font-bold ${tone}`}>{label}</div>
      <div className="text-[11px] font-mono text-muted-foreground">{item.case_id}</div>
      <div className="font-medium truncate">{item.item_name}</div>
      <div className="text-xs text-muted-foreground">{item.category} · {item.general_location} · {item.incident_date}</div>
      {item.colour && <div className="text-xs text-muted-foreground">Colour: {item.colour}</div>}
    </Link>
  );
}