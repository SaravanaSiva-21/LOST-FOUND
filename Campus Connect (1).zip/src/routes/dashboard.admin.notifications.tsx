import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { NOTIFICATION_LABELS } from "@/lib/tce";
import { Button } from "@/components/ui/button";
import { Bell, Check } from "lucide-react";

export const Route = createFileRoute("/dashboard/admin/notifications")({
  component: AdminNotifications,
});

function AdminNotifications() {
  const { user } = useAuth();
  const [rows, setRows] = useState<any[]>([]);
  const [filter, setFilter] = useState<string>("all");

  const load = async () => {
    if (!user) return;
    const { data } = await supabase.from("notifications").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(200);
    setRows(data ?? []);
  };
  useEffect(() => { load(); }, [user?.id]);

  useEffect(() => {
    if (!user) return;
    const ch = supabase.channel(`admin-notif-${user.id}`).on("postgres_changes", { event: "*", schema: "public", table: "notifications", filter: `user_id=eq.${user.id}` }, load).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [user?.id]);

  const markAll = async () => {
    if (!user) return;
    await supabase.from("notifications").update({ read: true }).eq("user_id", user.id).eq("read", false);
    load();
  };

  const filtered = rows.filter((n) => filter === "all" || n.type === filter);
  const types = Array.from(new Set(rows.map((r) => r.type)));

  return (
    <div className="space-y-6">
      <header className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold">Admin Notifications</h1>
          <p className="text-sm text-muted-foreground mt-1">Real-time updates for reports, claims, handovers, and feedback.</p>
        </div>
        <Button variant="outline" size="sm" onClick={markAll} className="gap-1"><Check className="h-4 w-4" /> Mark all read</Button>
      </header>

      <div className="flex gap-2 flex-wrap">
        <button onClick={() => setFilter("all")} className={`text-xs px-3 py-1.5 rounded-full border ${filter === "all" ? "border-primary text-primary" : "border-border text-muted-foreground"}`}>All ({rows.length})</button>
        {types.map((t) => (
          <button key={t} onClick={() => setFilter(t)} className={`text-xs px-3 py-1.5 rounded-full border ${filter === t ? "border-primary text-primary" : "border-border text-muted-foreground"}`}>
            {NOTIFICATION_LABELS[t] ?? t}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-xl border border-dashed p-12 text-center text-sm text-muted-foreground"><Bell className="h-6 w-6 mx-auto mb-2 opacity-50" />No notifications.</div>
      ) : (
        <div className="space-y-2">
          {filtered.map((n) => (
            <div key={n.id} className={`rounded-xl border p-4 ${n.read ? "border-border bg-card" : "border-primary/40 bg-primary/5"}`}>
              <div className="flex justify-between gap-2 flex-wrap">
                <div className="min-w-0">
                  <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{NOTIFICATION_LABELS[n.type] ?? n.type}</div>
                  <div className="font-medium">{n.title}</div>
                  <div className="text-sm text-muted-foreground">{n.message}</div>
                  {n.case_id && <Link to="/dashboard/search" className="text-xs text-primary">Case {n.case_id}</Link>}
                </div>
                <span className="text-[11px] text-muted-foreground whitespace-nowrap">{new Date(n.created_at).toLocaleString()}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}