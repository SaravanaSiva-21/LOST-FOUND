import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FileSpreadsheet, FileText, Download, FileJson } from "lucide-react";
import { downloadFile, toCSV, logAudit, ITEM_CATEGORIES } from "@/lib/tce";

export const Route = createFileRoute("/dashboard/admin/reports")({
  component: ReportsPage,
});

type Kind = "lost" | "found" | "claims" | "users" | "handovers" | "feedback" | "resolved";

const KINDS: { key: Kind; label: string; desc: string }[] = [
  { key: "lost", label: "Lost Reports", desc: "All lost-item reports." },
  { key: "found", label: "Found Reports", desc: "All found-item reports." },
  { key: "claims", label: "Claims", desc: "Ownership claims and their status." },
  { key: "users", label: "Users", desc: "Registered accounts and roles." },
  { key: "handovers", label: "Handovers", desc: "Contact sharing and handover confirmations." },
  { key: "feedback", label: "Feedback", desc: "Ratings and suggestions." },
  { key: "resolved", label: "Resolved Cases", desc: "Successfully returned items." },
];

function ReportsPage() {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [dept, setDept] = useState("");
  const [category, setCategory] = useState("all");
  const [status, setStatus] = useState("all");
  const [busy, setBusy] = useState<string | null>(null);

  const buildRows = async (kind: Kind): Promise<{ rows: any[]; columns: string[]; title: string }> => {
    const dateFrom = from ? new Date(from).toISOString() : null;
    const dateTo = to ? new Date(to + "T23:59:59").toISOString() : null;

    if (kind === "users") {
      let q = supabase.from("profiles").select("full_name,email,register_no,department,phone,is_suspended,created_at");
      if (dept) q = q.eq("department", dept);
      if (dateFrom) q = q.gte("created_at", dateFrom);
      if (dateTo) q = q.lte("created_at", dateTo);
      const { data } = await q;
      return { rows: data ?? [], columns: ["full_name", "email", "register_no", "department", "phone", "is_suspended", "created_at"], title: "Users" };
    }

    if (kind === "handovers") {
      let q = supabase.from("claims").select("case_id,status,contact_shared_at,finder_confirmed,finder_confirmed_at,owner_confirmed,owner_confirmed_at,resolved_at,created_at,items(case_id,item_name)")
        .not("contact_shared_at", "is", null);
      if (dateFrom) q = q.gte("contact_shared_at", dateFrom);
      if (dateTo) q = q.lte("contact_shared_at", dateTo);
      const { data } = await q;
      const rows = (data ?? []).map((r: any) => ({
        claim_case: r.case_id, item_case: r.items?.case_id, item: r.items?.item_name,
        status: r.status, contact_shared_at: r.contact_shared_at,
        finder_confirmed: r.finder_confirmed, finder_confirmed_at: r.finder_confirmed_at,
        owner_confirmed: r.owner_confirmed, owner_confirmed_at: r.owner_confirmed_at,
        resolved_at: r.resolved_at, created_at: r.created_at,
      }));
      return { rows, columns: ["claim_case", "item_case", "item", "status", "contact_shared_at", "finder_confirmed", "finder_confirmed_at", "owner_confirmed", "owner_confirmed_at", "resolved_at", "created_at"], title: "Handovers" };
    }

    if (kind === "feedback") {
      let q = supabase.from("feedback").select("*");
      if (dateFrom) q = q.gte("created_at", dateFrom);
      if (dateTo) q = q.lte("created_at", dateTo);
      const { data } = await q;
      const rows = (data ?? []).map((r: any) => ({ id: r.id, rating: r.rating, comment: r.comment, created_at: r.created_at }));
      return { rows, columns: ["id", "rating", "comment", "created_at"], title: "Feedback" };
    }

    if (kind === "claims") {
      let q = supabase.from("claims").select("case_id,status,reason,brand,colour,approx_date,approx_location,created_at,items(case_id,item_name,category)");
      if (dateFrom) q = q.gte("created_at", dateFrom);
      if (dateTo) q = q.lte("created_at", dateTo);
      if (status !== "all") q = q.eq("status", status as any);
      const { data } = await q;
      const rows = (data ?? []).filter((r: any) => category === "all" || r.items?.category === category).map((r: any) => ({
        claim_case: r.case_id, item_case: r.items?.case_id, item: r.items?.item_name, category: r.items?.category,
        status: r.status, brand: r.brand, colour: r.colour, location: r.approx_location, when: r.approx_date, created_at: r.created_at,
      }));
      return { rows, columns: ["claim_case", "item_case", "item", "category", "status", "brand", "colour", "location", "when", "created_at"], title: "Claims" };
    }

    // items / lost / found / resolved
    let q = supabase.from("items").select("case_id,report_type,item_name,category,general_location,location,incident_date,status,contact_number,current_holder,created_at,updated_at,reporter_id");
    if (kind === "lost") q = q.eq("report_type", "lost");
    if (kind === "found") q = q.eq("report_type", "found");
    if (kind === "resolved") q = q.eq("status", "resolved");
    if (category !== "all") q = q.eq("category", category);
    if (status !== "all" && kind !== "resolved") q = q.eq("status", status as any);
    if (dateFrom) q = q.gte("created_at", dateFrom);
    if (dateTo) q = q.lte("created_at", dateTo);
    const { data } = await q;
    let rows = data ?? [];
    if (dept) {
      const uids = Array.from(new Set(rows.map((r: any) => r.reporter_id).filter(Boolean)));
      const { data: profs } = await supabase.from("profiles").select("id,department").in("id", uids);
      const dmap: Record<string, string> = {};
      (profs ?? []).forEach((p: any) => { dmap[p.id] = p.department ?? ""; });
      rows = rows.filter((r: any) => dmap[r.reporter_id] === dept);
    }
    const title = kind === "lost" ? "Lost Reports" : kind === "found" ? "Found Reports" : "Resolved Cases";
    return {
      rows: rows.map((r: any) => ({
        case_id: r.case_id, type: r.report_type, item: r.item_name, category: r.category,
        location: r.general_location, place: r.location, date: r.incident_date, status: r.status,
        contact: r.contact_number, current_holder: r.current_holder, created_at: r.created_at, updated_at: r.updated_at,
      })),
      columns: ["case_id", "type", "item", "category", "location", "place", "date", "status", "contact", "current_holder", "created_at", "updated_at"],
      title,
    };
  };

  const exportKind = async (kind: Kind, format: "csv" | "xlsx" | "pdf" | "json") => {
    const key = `${kind}-${format}`;
    setBusy(key);
    try {
      const { rows, columns, title } = await buildRows(kind);
      if (rows.length === 0) { toast.info("No rows match those filters"); return; }
      const stamp = new Date().toISOString().slice(0, 10);
      const filename = `tce-${kind}-${stamp}`;

      if (format === "csv") {
        downloadFile(toCSV(rows), `${filename}.csv`, "text/csv");
      } else if (format === "json") {
        downloadFile(JSON.stringify(rows, null, 2), `${filename}.json`, "application/json");
      } else if (format === "xlsx") {
        const ws = XLSX.utils.json_to_sheet(rows, { header: columns });
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, title.slice(0, 31));
        XLSX.writeFile(wb, `${filename}.xlsx`);
      } else {
        const doc = new jsPDF({ orientation: "landscape", unit: "pt", format: "a4" });
        doc.setFontSize(14);
        doc.text(`TCE Lost & Found — ${title}`, 40, 40);
        doc.setFontSize(9);
        const meta = [
          from || to ? `Date: ${from || "…"} → ${to || "…"}` : null,
          dept ? `Department: ${dept}` : null,
          category !== "all" ? `Category: ${category}` : null,
          status !== "all" ? `Status: ${status}` : null,
          `Rows: ${rows.length}`,
        ].filter(Boolean).join("   ·   ");
        if (meta) doc.text(meta, 40, 58);
        autoTable(doc, {
          startY: 72,
          head: [columns],
          body: rows.map((r: any) => columns.map((c) => {
            const v = r[c];
            if (v === null || v === undefined) return "";
            if (typeof v === "boolean") return v ? "Yes" : "No";
            if (typeof v === "string" && v.length > 60) return v.slice(0, 57) + "…";
            return String(v);
          })),
          styles: { fontSize: 7, cellPadding: 3, overflow: "linebreak" },
          headStyles: { fillColor: [37, 99, 235] },
          margin: { left: 40, right: 40 },
        });
        doc.save(`${filename}.pdf`);
      }

      await logAudit({ action: "admin_report_generated", entity: kind, metadata: { format, count: rows.length, filters: { from, to, dept, category, status } } });
      toast.success(`Exported ${rows.length} rows`);
    } catch (e: any) {
      toast.error(e.message ?? "Export failed");
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold flex items-center gap-2"><Download className="h-6 w-6 text-primary" /> Reports</h1>
        <p className="text-sm text-muted-foreground mt-1">Generate downloadable reports as PDF, Excel, CSV, or JSON.</p>
      </header>

      <div className="rounded-2xl border border-border bg-card p-4 grid md:grid-cols-5 gap-2">
        <label className="text-xs space-y-1"><span className="text-muted-foreground">From</span><Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></label>
        <label className="text-xs space-y-1"><span className="text-muted-foreground">To</span><Input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></label>
        <label className="text-xs space-y-1"><span className="text-muted-foreground">Department</span><Input placeholder="e.g. CSE" value={dept} onChange={(e) => setDept(e.target.value)} /></label>
        <label className="text-xs space-y-1">
          <span className="text-muted-foreground">Category</span>
          <select value={category} onChange={(e) => setCategory(e.target.value)} className="h-10 w-full px-3 rounded-md border border-input bg-background text-sm">
            <option value="all">All</option>
            {ITEM_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </label>
        <label className="text-xs space-y-1">
          <span className="text-muted-foreground">Status</span>
          <select value={status} onChange={(e) => setStatus(e.target.value)} className="h-10 w-full px-3 rounded-md border border-input bg-background text-sm">
            <option value="all">All</option>
            <option value="pending_verification">Pending</option>
            <option value="approved">Approved</option>
            <option value="matched">Matched</option>
            <option value="claimed">Claimed</option>
            <option value="handed_over">Handed Over</option>
            <option value="resolved">Resolved</option>
            <option value="rejected">Rejected</option>
          </select>
        </label>
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        {KINDS.map((k) => (
          <div key={k.key} className="rounded-2xl border border-border bg-card p-5 space-y-3">
            <div>
              <div className="font-semibold">{k.label}</div>
              <div className="text-xs text-muted-foreground mt-1">{k.desc}</div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button size="sm" variant="outline" disabled={busy === `${k.key}-pdf`} onClick={() => exportKind(k.key, "pdf")} className="gap-1"><FileText className="h-4 w-4" /> {busy === `${k.key}-pdf` ? "…" : "PDF"}</Button>
              <Button size="sm" variant="outline" disabled={busy === `${k.key}-xlsx`} onClick={() => exportKind(k.key, "xlsx")} className="gap-1"><FileSpreadsheet className="h-4 w-4" /> {busy === `${k.key}-xlsx` ? "…" : "Excel"}</Button>
              <Button size="sm" variant="outline" disabled={busy === `${k.key}-csv`} onClick={() => exportKind(k.key, "csv")} className="gap-1"><Download className="h-4 w-4" /> {busy === `${k.key}-csv` ? "…" : "CSV"}</Button>
              <Button size="sm" variant="ghost" disabled={busy === `${k.key}-json`} onClick={() => exportKind(k.key, "json")} className="gap-1"><FileJson className="h-4 w-4" /> JSON</Button>
            </div>
          </div>
        ))}
      </div>

      <p className="text-xs text-muted-foreground">Every report generated here is recorded in the audit log with format, row count, and applied filters.</p>
    </div>
  );
}