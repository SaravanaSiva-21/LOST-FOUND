import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Loader2, Save, Settings as SettingsIcon, Upload, Plus, Trash2, GripVertical, ImageIcon } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DEFAULT_GENERAL,
  DEFAULT_HOMEPAGE,
  GeneralSettings,
  HomepageSettings,
  loadSetting,
  saveSetting,
  uploadSiteAsset,
} from "@/lib/settings";
import { logAudit } from "@/lib/tce";

export const Route = createFileRoute("/dashboard/admin/settings")({
  component: SystemSettingsPage,
});

type Faq = { id: string; question: string; answer: string; sort_order: number; active: boolean };

function SystemSettingsPage() {
  const { isAdmin, loading: authLoading } = useAuth();
  const [loading, setLoading] = useState(true);
  const [general, setGeneral] = useState<GeneralSettings>(DEFAULT_GENERAL);
  const [homepage, setHomepage] = useState<HomepageSettings>(DEFAULT_HOMEPAGE);
  const [faqs, setFaqs] = useState<Faq[]>([]);
  const [newFaq, setNewFaq] = useState({ question: "", answer: "" });
  const [savingGeneral, setSavingGeneral] = useState(false);
  const [savingHome, setSavingHome] = useState(false);

  useEffect(() => {
    (async () => {
      const [g, h, { data: faqData }] = await Promise.all([
        loadSetting("general", DEFAULT_GENERAL),
        loadSetting("homepage", DEFAULT_HOMEPAGE),
        supabase.from("faqs").select("*").order("sort_order").order("created_at"),
      ]);
      setGeneral(g);
      setHomepage(h);
      setFaqs((faqData ?? []) as Faq[]);
      setLoading(false);
    })();
  }, []);

  if (authLoading) return <PageSkeleton />;
  if (!isAdmin) {
    return (
      <div className="rounded-2xl border border-border bg-card p-8 text-center text-sm text-muted-foreground">
        You need administrator privileges to view this page.
      </div>
    );
  }

  const onSaveGeneral = async () => {
    setSavingGeneral(true);
    try {
      await saveSetting("general", general);
      await logAudit({ action: "update", entity: "system_settings", entity_id: "general", metadata: { keys: Object.keys(general) } });
      toast.success("General settings saved");
    } catch (e: any) {
      toast.error(e.message ?? "Failed to save");
    } finally {
      setSavingGeneral(false);
    }
  };

  const onSaveHome = async () => {
    setSavingHome(true);
    try {
      await saveSetting("homepage", homepage);
      await logAudit({ action: "update", entity: "system_settings", entity_id: "homepage", metadata: { keys: Object.keys(homepage) } });
      toast.success("Homepage settings saved");
    } catch (e: any) {
      toast.error(e.message ?? "Failed to save");
    } finally {
      setSavingHome(false);
    }
  };

  const addFaq = async () => {
    if (!newFaq.question.trim() || !newFaq.answer.trim()) {
      return toast.error("Question and answer are required");
    }
    const nextOrder = (faqs[faqs.length - 1]?.sort_order ?? 0) + 10;
    const { data, error } = await supabase.from("faqs").insert({
      question: newFaq.question.trim(),
      answer: newFaq.answer.trim(),
      sort_order: nextOrder,
    }).select().single();
    if (error) return toast.error(error.message);
    setFaqs([...faqs, data as Faq]);
    setNewFaq({ question: "", answer: "" });
    await logAudit({ action: "create", entity: "faqs", entity_id: (data as any).id });
    toast.success("FAQ added");
  };

  const updateFaq = async (id: string, patch: Partial<Faq>) => {
    setFaqs(faqs.map((f) => (f.id === id ? { ...f, ...patch } : f)));
    const { error } = await supabase.from("faqs").update(patch).eq("id", id);
    if (error) toast.error(error.message);
    else await logAudit({ action: "update", entity: "faqs", entity_id: id });
  };

  const removeFaq = async (id: string) => {
    if (!confirm("Delete this FAQ?")) return;
    const { error } = await supabase.from("faqs").delete().eq("id", id);
    if (error) return toast.error(error.message);
    setFaqs(faqs.filter((f) => f.id !== id));
    await logAudit({ action: "delete", entity: "faqs", entity_id: id });
    toast.success("FAQ removed");
  };

  const moveFaq = async (id: string, dir: -1 | 1) => {
    const idx = faqs.findIndex((f) => f.id === id);
    const swap = idx + dir;
    if (idx < 0 || swap < 0 || swap >= faqs.length) return;
    const a = faqs[idx];
    const b = faqs[swap];
    await Promise.all([
      supabase.from("faqs").update({ sort_order: b.sort_order }).eq("id", a.id),
      supabase.from("faqs").update({ sort_order: a.sort_order }).eq("id", b.id),
    ]);
    const next = [...faqs];
    next[idx] = { ...b, sort_order: a.sort_order };
    next[swap] = { ...a, sort_order: b.sort_order };
    setFaqs(next);
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <SettingsIcon className="h-6 w-6 text-primary" /> System Settings
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Configure identity, branding, and homepage content for the portal.
        </p>
      </header>

      {loading ? (
        <PageSkeleton />
      ) : (
        <Tabs defaultValue="general" className="space-y-6">
          <TabsList>
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="homepage">Homepage</TabsTrigger>
            <TabsTrigger value="faqs">FAQs</TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="space-y-6">
            <Section title="Identity">
              <Field label="Website Name">
                <Input value={general.website_name} onChange={(e) => setGeneral({ ...general, website_name: e.target.value })} maxLength={80} />
              </Field>
              <Field label="College Name">
                <Input value={general.college_name} onChange={(e) => setGeneral({ ...general, college_name: e.target.value })} maxLength={120} />
              </Field>
              <Field label="Website Logo">
                <ImagePicker value={general.website_logo_url} prefix="logos/website" onChange={(url) => setGeneral({ ...general, website_logo_url: url })} />
              </Field>
              <Field label="College Logo">
                <ImagePicker value={general.college_logo_url} prefix="logos/college" onChange={(url) => setGeneral({ ...general, college_logo_url: url })} />
              </Field>
            </Section>

            <Section title="Contact">
              <Field label="Contact Email">
                <Input type="email" value={general.contact_email} onChange={(e) => setGeneral({ ...general, contact_email: e.target.value })} placeholder="lostandfound@tce.edu" maxLength={120} />
              </Field>
              <Field label="Contact Phone">
                <Input value={general.contact_phone} onChange={(e) => setGeneral({ ...general, contact_phone: e.target.value })} placeholder="+91 98765 43210" maxLength={40} />
              </Field>
            </Section>

            <Section title="Footer">
              <Field label="Footer Text">
                <Textarea rows={3} value={general.footer_text} onChange={(e) => setGeneral({ ...general, footer_text: e.target.value })} maxLength={400} />
              </Field>
              <Field label="Copyright Text">
                <Input value={general.copyright_text} onChange={(e) => setGeneral({ ...general, copyright_text: e.target.value })} maxLength={200} />
              </Field>
            </Section>

            <div className="flex justify-end">
              <Button onClick={onSaveGeneral} disabled={savingGeneral} className="gap-2">
                {savingGeneral ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Save general settings
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="homepage" className="space-y-6">
            <Section title="Hero">
              <Field label="Hero Banner Image">
                <ImagePicker value={homepage.hero_banner_url} prefix="banners/hero" onChange={(url) => setHomepage({ ...homepage, hero_banner_url: url })} aspect="banner" />
              </Field>
              <Field label="Welcome Message">
                <Textarea rows={3} value={homepage.welcome_message} onChange={(e) => setHomepage({ ...homepage, welcome_message: e.target.value })} maxLength={400} />
              </Field>
            </Section>

            <Section title="Announcement Banner">
              <div className="flex items-center justify-between rounded-lg border border-border bg-muted/30 p-3">
                <div>
                  <div className="text-sm font-medium">Show announcement on homepage</div>
                  <div className="text-xs text-muted-foreground">Displays a highlighted banner above the hero.</div>
                </div>
                <Switch checked={homepage.announcement_active} onCheckedChange={(v) => setHomepage({ ...homepage, announcement_active: v })} />
              </div>
              <Field label="Announcement Text">
                <Textarea rows={2} value={homepage.announcement} onChange={(e) => setHomepage({ ...homepage, announcement: e.target.value })} maxLength={300} placeholder="e.g. Semester break — collections resume 5 July." />
              </Field>
            </Section>

            <Section title="Contact Information (Homepage)">
              <Field label="Address / Office Location">
                <Textarea rows={2} value={homepage.contact_address} onChange={(e) => setHomepage({ ...homepage, contact_address: e.target.value })} maxLength={300} />
              </Field>
              <Field label="Office Hours">
                <Input value={homepage.contact_hours} onChange={(e) => setHomepage({ ...homepage, contact_hours: e.target.value })} maxLength={120} />
              </Field>
            </Section>

            <div className="flex justify-end">
              <Button onClick={onSaveHome} disabled={savingHome} className="gap-2">
                {savingHome ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Save homepage settings
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="faqs" className="space-y-6">
            <div className="rounded-2xl border border-border bg-card p-6 space-y-3">
              <div className="text-sm font-semibold">Add new FAQ</div>
              <div className="grid gap-3">
                <Input placeholder="Question" value={newFaq.question} onChange={(e) => setNewFaq({ ...newFaq, question: e.target.value })} maxLength={200} />
                <Textarea rows={3} placeholder="Answer" value={newFaq.answer} onChange={(e) => setNewFaq({ ...newFaq, answer: e.target.value })} maxLength={1000} />
              </div>
              <Button onClick={addFaq} className="gap-2"><Plus className="h-4 w-4" /> Add FAQ</Button>
            </div>

            <div className="space-y-3">
              {faqs.length === 0 && (
                <div className="rounded-2xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
                  No FAQs yet. Add your first question above.
                </div>
              )}
              {faqs.map((f, i) => (
                <div key={f.id} className="rounded-2xl border border-border bg-card p-4 space-y-3">
                  <div className="flex items-start gap-2">
                    <div className="flex flex-col items-center pt-1 text-muted-foreground">
                      <button onClick={() => moveFaq(f.id, -1)} disabled={i === 0} className="disabled:opacity-30 text-xs">▲</button>
                      <GripVertical className="h-3 w-3 opacity-40" />
                      <button onClick={() => moveFaq(f.id, 1)} disabled={i === faqs.length - 1} className="disabled:opacity-30 text-xs">▼</button>
                    </div>
                    <div className="flex-1 space-y-2">
                      <Input value={f.question} onChange={(e) => setFaqs(faqs.map((x) => x.id === f.id ? { ...x, question: e.target.value } : x))} onBlur={(e) => updateFaq(f.id, { question: e.target.value })} maxLength={200} />
                      <Textarea rows={3} value={f.answer} onChange={(e) => setFaqs(faqs.map((x) => x.id === f.id ? { ...x, answer: e.target.value } : x))} onBlur={(e) => updateFaq(f.id, { answer: e.target.value })} maxLength={1000} />
                      <div className="flex items-center justify-between">
                        <label className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Switch checked={f.active} onCheckedChange={(v) => updateFaq(f.id, { active: v })} />
                          {f.active ? "Visible on homepage" : "Hidden"}
                        </label>
                        <button onClick={() => removeFaq(f.id)} className="text-muted-foreground hover:text-destructive" aria-label="Delete FAQ">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-6 space-y-4">
      <div className="text-sm font-semibold">{title}</div>
      <div className="grid gap-4">{children}</div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
    </div>
  );
}

function ImagePicker({ value, onChange, prefix, aspect = "square" }: { value: string; onChange: (url: string) => void; prefix: string; aspect?: "square" | "banner" }) {
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const onFile = async (file: File) => {
    if (file.size > 5 * 1024 * 1024) return toast.error("File must be under 5 MB");
    setUploading(true);
    try {
      const url = await uploadSiteAsset(file, prefix);
      onChange(url);
      toast.success("Uploaded");
    } catch (e: any) {
      toast.error(e.message ?? "Upload failed");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="flex items-start gap-4">
      <div className={`shrink-0 rounded-lg border border-border bg-muted/40 overflow-hidden flex items-center justify-center ${aspect === "banner" ? "w-56 h-24" : "w-24 h-24"}`}>
        {value ? (
          <img src={value} alt="preview" className="w-full h-full object-cover" />
        ) : (
          <ImageIcon className="h-6 w-6 text-muted-foreground" />
        )}
      </div>
      <div className="flex-1 space-y-2">
        <input ref={inputRef} type="file" accept="image/*" hidden onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} />
        <div className="flex flex-wrap gap-2">
          <Button type="button" variant="secondary" size="sm" onClick={() => inputRef.current?.click()} disabled={uploading} className="gap-2">
            {uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Upload className="h-3.5 w-3.5" />}
            {value ? "Replace" : "Upload"}
          </Button>
          {value && (
            <Button type="button" variant="ghost" size="sm" onClick={() => onChange("")}>
              Remove
            </Button>
          )}
        </div>
        <Input value={value} onChange={(e) => onChange(e.target.value)} placeholder="Or paste an image URL" />
      </div>
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-4">
      <Skeleton className="h-10 w-64" />
      <Skeleton className="h-40 w-full" />
      <Skeleton className="h-40 w-full" />
    </div>
  );
}
