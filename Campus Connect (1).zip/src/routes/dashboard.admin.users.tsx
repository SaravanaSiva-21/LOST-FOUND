import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { logAudit, toCSV, downloadFile } from "@/lib/tce";
import { Download } from "lucide-react";

export const Route = createFileRoute("/dashboard/admin/users")({
  component: UsersPage,
});

function UsersPage() {
  const [users, setUsers] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [dept, setDept] = useState("all");
  const [role, setRole] = useState("all");
  const [status, setStatus] = useState("all");
  const [selected, setSelected] = useState<any | null>(null);

  const load = async () => {
    const { data } = await supabase.from("profiles").select("*, user_roles(role)").order("created_at", { ascending: false });
    setUsers(data ?? []);
  };
  useEffect(() => { load(); }, []);

  const toggleSuspend = async (u: any) => {
    await supabase.from("profiles").update({ is_suspended: !u.is_suspended }).eq("id", u.id);
    await logAudit({ action: u.is_suspended ? "user_unsuspended" : "user_suspended", entity: "profile", entity_id: u.id });
    toast.success("Updated"); load();
  };

  const depts = useMemo(() => Array.from(new Set(users.map((u) => u.department).filter(Boolean))), [users]);

  const filtered = users.filter((u) => {
    const matchesQ = !q || [u.full_name, u.email, u.register_no].some((f) => String(f ?? "").toLowerCase().includes(q.toLowerCase()));
    const matchesDept = dept === "all" || u.department === dept;
    const matchesRole = role === "all" || u.user_roles?.[0]?.role === role;
    const matchesStatus = status === "all" || (status === "suspended" ? u.is_suspended : !u.is_suspended);
    return matchesQ && matchesDept && matchesRole && matchesStatus;
  });

  const exportCsv = () => {
    const rows = filtered.map((u) => ({
      name: u.full_name, email: u.email, register_no: u.register_no, department: u.department,
      role: u.user_roles?.[0]?.role ?? "", status: u.is_suspended ? "suspended" : "active", created_at: u.created_at,
    }));
    downloadFile(toCSV(rows), `users-${new Date().toISOString().slice(0, 10)}.csv`);
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">User Management</h1>
        <p className="text-sm text-muted-foreground mt-1">Registered users. Suspend accounts that violate policy.</p>
      </header>
      <div className="grid md:grid-cols-5 gap-2">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name, email, register no..." className="md:col-span-2" />
        <select value={dept} onChange={(e) => setDept(e.target.value)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
          <option value="all">All departments</option>
          {depts.map((d) => <option key={d} value={d}>{d}</option>)}
        </select>
        <select value={role} onChange={(e) => setRole(e.target.value)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
          <option value="all">All roles</option>
          <option value="student">Student / Faculty</option>
          <option value="admin">Admin</option>
        </select>
        <select value={status} onChange={(e) => setStatus(e.target.value)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
          <option value="all">All statuses</option>
          <option value="active">Active</option>
          <option value="suspended">Suspended</option>
        </select>
      </div>
      <div className="flex justify-end">
        <Button variant="outline" size="sm" onClick={exportCsv} className="gap-1"><Download className="h-4 w-4" /> Export CSV</Button>
      </div>
      <div className="rounded-2xl border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="text-left px-4 py-3">Name</th>
              <th className="text-left px-4 py-3">Email</th>
              <th className="text-left px-4 py-3">Dept</th>
              <th className="text-left px-4 py-3">Role</th>
              <th className="text-left px-4 py-3">Status</th>
              <th className="text-right px-4 py-3">Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((u) => (
              <tr key={u.id} className="border-t border-border">
                <td className="px-4 py-3">
                  <div className="font-medium">{u.full_name || "—"}</div>
                  <div className="text-[11px] text-muted-foreground">{u.register_no ?? "—"}</div>
                </td>
                <td className="px-4 py-3">{u.email}</td>
                <td className="px-4 py-3">{u.department ?? "—"}</td>
                <td className="px-4 py-3">{u.user_roles?.[0]?.role ?? "—"}</td>
                <td className="px-4 py-3">
                  {u.is_suspended ? <span className="text-xs text-red-600">Suspended</span> : <span className="text-xs text-emerald-600">Active</span>}
                </td>
                <td className="px-4 py-3 text-right space-x-1">
                  <Button size="sm" variant="ghost" onClick={() => setSelected(u)}>View</Button>
                  <Button size="sm" variant={u.is_suspended ? "outline" : "destructive"} onClick={() => toggleSuspend(u)}>
                    {u.is_suspended ? "Reactivate" : "Suspend"}
                  </Button>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={6} className="text-center text-muted-foreground text-sm py-10">No users match those filters.</td></tr>}
          </tbody>
        </table>
      </div>

      {selected && <UserSheet user={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}

function UserSheet({ user, onClose }: { user: any; onClose: () => void }) {
  const [tab, setTab] = useState<"reports" | "claims" | "activity">("reports");
  const [reports, setReports] = useState<any[]>([]);
  const [claims, setClaims] = useState<any[]>([]);
  const [activity, setActivity] = useState<any[]>([]);

  useEffect(() => {
    supabase.from("items").select("case_id,item_name,report_type,status,created_at").eq("reporter_id", user.id).order("created_at", { ascending: false }).limit(50).then(({ data }) => setReports(data ?? []));
    supabase.from("claims").select("case_id,status,created_at,items(case_id,item_name)").eq("claimant_id", user.id).order("created_at", { ascending: false }).limit(50).then(({ data }) => setClaims(data ?? []));
    supabase.from("audit_logs").select("action,entity,created_at").eq("user_id", user.id).order("created_at", { ascending: false }).limit(50).then(({ data }) => setActivity(data ?? []));
  }, [user.id]);

  const resolvedCount = reports.filter((r) => r.status === "resolved").length;

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-end md:items-center md:justify-end" onClick={onClose}>
      <div className="bg-background w-full md:max-w-lg md:h-full overflow-y-auto rounded-t-2xl md:rounded-none p-6 space-y-4" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start gap-3">
          {user.photo_url ? <img src={user.photo_url} alt="" className="h-14 w-14 rounded-full object-cover" /> : <div className="h-14 w-14 rounded-full bg-primary/10 text-primary grid place-items-center font-semibold">{user.full_name?.[0] ?? "U"}</div>}
          <div className="min-w-0">
            <div className="font-semibold truncate">{user.full_name}</div>
            <div className="text-xs text-muted-foreground truncate">{user.email}</div>
            <div className="text-xs text-muted-foreground">{user.department ?? "—"} · {user.register_no ?? "—"}</div>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <MiniStat label="Reports" v={reports.length} />
          <MiniStat label="Claims" v={claims.length} />
          <MiniStat label="Resolved" v={resolvedCount} />
        </div>
        <div className="grid grid-cols-3 gap-1 rounded-lg bg-secondary p-1">
          {(["reports", "claims", "activity"] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)} className={`text-xs font-medium py-2 rounded-md ${tab === t ? "bg-background shadow-sm" : "text-muted-foreground"}`}>{t}</button>
          ))}
        </div>
        <div className="space-y-2 text-sm">
          {tab === "reports" && (reports.length === 0 ? <Empty /> : reports.map((r) => (
            <div key={r.case_id} className="rounded-lg border border-border p-2">
              <div className="text-[11px] font-mono text-muted-foreground">{r.case_id}</div>
              <div className="font-medium">{r.item_name}</div>
              <div className="text-xs text-muted-foreground">{r.report_type} · {r.status} · {new Date(r.created_at).toLocaleDateString()}</div>
            </div>
          )))}
          {tab === "claims" && (claims.length === 0 ? <Empty /> : claims.map((c) => (
            <div key={c.case_id} className="rounded-lg border border-border p-2">
              <div className="text-[11px] font-mono text-muted-foreground">{c.case_id}</div>
              <div className="font-medium">{c.items?.item_name}</div>
              <div className="text-xs text-muted-foreground">{c.status} · {new Date(c.created_at).toLocaleDateString()}</div>
            </div>
          )))}
          {tab === "activity" && (activity.length === 0 ? <Empty /> : activity.map((a, i) => (
            <div key={i} className="rounded-lg border border-border p-2 text-xs">
              <div className="font-mono">{a.action}</div>
              <div className="text-muted-foreground">{a.entity} · {new Date(a.created_at).toLocaleString()}</div>
            </div>
          )))}
        </div>
        <Button variant="outline" className="w-full" onClick={onClose}>Close</Button>
      </div>
    </div>
  );
}

function MiniStat({ label, v }: any) {
  return <div className="rounded-lg border border-border bg-card p-3 text-center"><div className="text-lg font-bold tabular-nums">{v}</div><div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div></div>;
}
function Empty() {
  return <div className="text-center text-muted-foreground text-xs py-6">Nothing here.</div>;
}