import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { StatusBadge } from "@/components/StatusBadge";

export const Route = createFileRoute("/dashboard/admin/verifications")({
  component: Verifications,
});

function Verifications() {
  const [tab, setTab] = useState<"items" | "claims">("items");
  const [items, setItems] = useState<any[]>([]);
  const [claims, setClaims] = useState<any[]>([]);

  useEffect(() => {
    supabase.from("items").select("*").eq("status", "pending_verification").order("created_at").then(({ data }) => setItems(data ?? []));
    supabase.from("claims").select("*, items(id,case_id,item_name)").eq("status", "pending").order("created_at").then(({ data }) => setClaims(data ?? []));
  }, []);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Pending Verifications</h1>
        <p className="text-sm text-muted-foreground mt-1">Review pending reports and claims. Open a case to take action.</p>
      </header>
      <div className="grid grid-cols-2 gap-1 rounded-lg bg-secondary p-1 max-w-xs">
        {(["items", "claims"] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`text-xs font-medium py-2 rounded-md ${tab === t ? "bg-background shadow-sm" : "text-muted-foreground"}`}>
            {t === "items" ? `Reports (${items.length})` : `Claims (${claims.length})`}
          </button>
        ))}
      </div>
      {tab === "items" ? (
        <div className="space-y-3">
          {items.length === 0 && <div className="rounded-xl border border-dashed p-12 text-center text-sm text-muted-foreground">No pending reports.</div>}
          {items.map((it) => (
            <Link key={it.id} to="/dashboard/case/$id" params={{ id: it.id }} className="block rounded-xl border border-border bg-card p-4 hover:border-primary/40">
              <div className="flex justify-between flex-wrap gap-2">
                <div>
                  <div className="text-[11px] font-mono text-muted-foreground">{it.case_id}</div>
                  <div className="font-medium">{it.item_name}</div>
                  <div className="text-xs text-muted-foreground">{it.category} · {it.general_location} · {it.incident_date}</div>
                </div>
                <span className={`text-[10px] font-bold uppercase ${it.report_type === "lost" ? "text-red-600" : "text-emerald-600"}`}>{it.report_type}</span>
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          {claims.length === 0 && <div className="rounded-xl border border-dashed p-12 text-center text-sm text-muted-foreground">No pending claims.</div>}
          {claims.map((c) => (
            <Link key={c.id} to="/dashboard/case/$id" params={{ id: c.items.id }} className="block rounded-xl border border-border bg-card p-4 hover:border-primary/40">
              <div className="flex justify-between flex-wrap gap-2">
                <div>
                  <div className="text-[11px] font-mono text-muted-foreground">Claim {c.case_id}</div>
                  <div className="font-medium">{c.items.item_name}</div>
                  <div className="text-xs text-muted-foreground">Item {c.items.case_id}</div>
                </div>
                <StatusBadge status={c.status} />
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}