import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Trash2, Plus, Upload, Download } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { logAudit, toCSV, downloadFile } from "@/lib/tce";

export const Route = createFileRoute("/dashboard/admin/whitelist")({
  component: Whitelist,
});

function Whitelist() {
  const [rows, setRows] = useState<any[]>([]);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<"student" | "admin">("student");
  const [notes, setNotes] = useState("");
  const [q, setQ] = useState("");
  const [filterRole, setFilterRole] = useState("all");
  const fileRef = useRef<HTMLInputElement | null>(null);

  const load = async () => {
    const { data } = await supabase.from("whitelist_emails").select("*").order("created_at", { ascending: false });
    setRows(data ?? []);
  };
  useEffect(() => { load(); }, []);

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    const em = email.trim().toLowerCase();
    if (role === "student" && !(em.endsWith("@tce.edu") || em.endsWith("@student.tce.edu"))) return toast.error("Student emails must end with @tce.edu or @student.tce.edu");
    if (role === "admin" && !em.endsWith("@gmail.com")) return toast.error("Admin emails must end with @gmail.com");
    const { error } = await supabase.from("whitelist_emails").insert({ email: em, role, notes: notes || null });
    if (error) return toast.error(error.message);
    await logAudit({ action: "whitelist_added", entity: "whitelist_emails", metadata: { email: em, role } });
    toast.success("Added"); setEmail(""); setNotes(""); load();
  };

  const remove = async (id: string, em: string) => {
    if (!confirm(`Remove ${em} from whitelist?`)) return;
    await supabase.from("whitelist_emails").delete().eq("id", id);
    await logAudit({ action: "whitelist_removed", entity: "whitelist_emails", metadata: { email: em } });
    load();
  };

  const exportCsv = () => {
    const out = rows.map((r) => ({ email: r.email, role: r.role, notes: r.notes ?? "" }));
    downloadFile(toCSV(out), `whitelist-${new Date().toISOString().slice(0, 10)}.csv`);
  };

  const importCsv = async (file: File) => {
    const text = await file.text();
    const lines = text.split(/\r?\n/).filter((l) => l.trim());
    if (lines.length === 0) return;
    const header = lines[0].toLowerCase().split(",").map((h) => h.trim());
    const emailIdx = header.indexOf("email");
    const roleIdx = header.indexOf("role");
    const notesIdx = header.indexOf("notes");
    const start = emailIdx === -1 ? 0 : 1;
    const items: any[] = [];
    for (let i = start; i < lines.length; i++) {
      const cols = parseCsvLine(lines[i]);
      const em = (emailIdx === -1 ? cols[0] : cols[emailIdx])?.trim().toLowerCase();
      const rl = (roleIdx === -1 ? cols[1] : cols[roleIdx])?.trim().toLowerCase() || "student";
      const nt = notesIdx === -1 ? cols[2] : cols[notesIdx];
      if (!em || !/^\S+@\S+\.\S+$/.test(em)) continue;
      const finalRole = rl === "admin" ? "admin" : "student";
      if (finalRole === "student" && !(em.endsWith("@tce.edu") || em.endsWith("@student.tce.edu"))) continue;
      if (finalRole === "admin" && !em.endsWith("@gmail.com")) continue;
      items.push({ email: em, role: finalRole, notes: nt || null });
    }
    if (items.length === 0) return toast.error("No valid rows found");
    const { error } = await supabase.from("whitelist_emails").upsert(items, { onConflict: "email" });
    if (error) return toast.error(error.message);
    await logAudit({ action: "whitelist_imported", entity: "whitelist_emails", metadata: { count: items.length } });
    toast.success(`Imported ${items.length} emails`);
    load();
  };

  const filtered = rows.filter((r) => (!q || r.email.toLowerCase().includes(q.toLowerCase())) && (filterRole === "all" || r.role === filterRole));

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Email Whitelist</h1>
        <p className="text-sm text-muted-foreground mt-1">Only whitelisted emails can register.</p>
      </header>

      <form onSubmit={add} className="rounded-2xl border border-border bg-card p-4 space-y-3">
        <div className="grid md:grid-cols-4 gap-2">
          <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="user@tce.edu" required />
          <select value={role} onChange={(e) => setRole(e.target.value as any)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
            <option value="student">Student / Faculty</option>
            <option value="admin">Administrator</option>
          </select>
          <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Notes (optional)" />
          <Button type="submit" className="gap-1"><Plus className="h-4 w-4" /> Add</Button>
        </div>
      </form>

      <div className="flex flex-wrap gap-2 items-center">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search email…" className="max-w-xs" />
        <select value={filterRole} onChange={(e) => setFilterRole(e.target.value)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
          <option value="all">All roles</option>
          <option value="student">Student / Faculty</option>
          <option value="admin">Administrator</option>
        </select>
        <div className="ml-auto flex gap-2">
          <input ref={fileRef} type="file" accept=".csv,text/csv" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) importCsv(f); e.currentTarget.value = ""; }} />
          <Button size="sm" variant="outline" onClick={() => fileRef.current?.click()} className="gap-1"><Upload className="h-4 w-4" /> Import CSV</Button>
          <Button size="sm" variant="outline" onClick={exportCsv} className="gap-1"><Download className="h-4 w-4" /> Export CSV</Button>
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="text-left px-4 py-3">Email</th>
              <th className="text-left px-4 py-3">Role</th>
              <th className="text-left px-4 py-3">Notes</th>
              <th className="text-right px-4 py-3">Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((r) => (
              <tr key={r.id} className="border-t border-border">
                <td className="px-4 py-3 font-mono text-xs">{r.email}</td>
                <td className="px-4 py-3">{r.role}</td>
                <td className="px-4 py-3 text-muted-foreground">{r.notes ?? "—"}</td>
                <td className="px-4 py-3 text-right">
                  <Button size="sm" variant="ghost" onClick={() => remove(r.id, r.email)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={4} className="text-center text-muted-foreground text-sm py-10">No emails match.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function parseCsvLine(line: string): string[] {
  const out: string[] = [];
  let cur = ""; let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') { cur += '"'; i++; }
      else inQuotes = !inQuotes;
    } else if (ch === "," && !inQuotes) { out.push(cur); cur = ""; }
    else cur += ch;
  }
  out.push(cur);
  return out;
}