import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Archive, Search as SearchIcon } from "lucide-react";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { StatusBadge } from "@/components/StatusBadge";

export const Route = createFileRoute("/dashboard/archive")({
  component: ArchivePage,
});

function ArchivePage() {
  const [rows, setRows] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("items")
        .select("id,case_id,item_name,report_type,general_location,updated_at,created_at,status,reporter:profiles!items_reporter_id_fkey(full_name,department)")
        .in("status", ["resolved", "archived"])
        .order("updated_at", { ascending: false })
        .limit(500);
      setRows(data ?? []);
      setLoading(false);
    })();
  }, []);

  const filtered = rows.filter((r) => {
    if (!q) return true;
    const s = q.toLowerCase();
    return (
      r.case_id.toLowerCase().includes(s) ||
      r.item_name.toLowerCase().includes(s) ||
      (r.reporter?.full_name ?? "").toLowerCase().includes(s)
    );
  });

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold flex items-center gap-2"><Archive className="h-6 w-6 text-primary" /> Case Archive</h1>
        <p className="text-sm text-muted-foreground mt-1">All resolved and archived cases in one place.</p>
      </header>
      <div className="relative">
        <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by case ID, item name, or reporter" className="pl-10" />
      </div>
      {loading ? (
        <div className="rounded-2xl border border-border bg-card h-72 animate-pulse" />
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border p-12 text-center">
          <Archive className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">No archived cases match.</p>
        </div>
      ) : (
        <div className="rounded-2xl border border-border bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="text-left p-3">Case ID</th>
                <th className="text-left p-3">Item</th>
                <th className="text-left p-3 hidden md:table-cell">Reporter</th>
                <th className="text-left p-3 hidden md:table-cell">Location</th>
                <th className="text-left p-3">Resolved</th>
                <th className="text-left p-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((r) => (
                <tr key={r.id} className="border-t border-border hover:bg-accent/40">
                  <td className="p-3 font-mono text-xs">
                    <Link to="/dashboard/case/$id" params={{ id: r.id }} className="text-primary hover:underline">
                      {r.case_id}
                    </Link>
                  </td>
                  <td className="p-3">{r.item_name}</td>
                  <td className="p-3 hidden md:table-cell text-muted-foreground">{r.reporter?.full_name ?? "—"}</td>
                  <td className="p-3 hidden md:table-cell text-muted-foreground">{r.general_location}</td>
                  <td className="p-3 text-xs text-muted-foreground">{new Date(r.updated_at).toLocaleDateString()}</td>
                  <td className="p-3"><StatusBadge status={r.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}