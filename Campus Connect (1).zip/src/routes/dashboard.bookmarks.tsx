import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Bookmark, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { StatusBadge } from "@/components/StatusBadge";
import { toast } from "sonner";

export const Route = createFileRoute("/dashboard/bookmarks")({
  component: Bookmarks,
});

function Bookmarks() {
  const { user } = useAuth();
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    if (!user) return;
    const { data } = await supabase
      .from("bookmarks")
      .select("id, created_at, item:items(id,case_id,item_name,category,general_location,incident_date,report_type,status)")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });
    setRows(data ?? []);
    setLoading(false);
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [user?.id]);

  const remove = async (id: string) => {
    await supabase.from("bookmarks").delete().eq("id", id);
    toast.success("Bookmark removed");
    load();
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Bookmarks</h1>
        <p className="text-sm text-muted-foreground mt-1">Items you have saved for quick access.</p>
      </header>
      {loading ? (
        <div className="grid gap-3 md:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="rounded-xl border border-border bg-card p-4 h-24 animate-pulse" />
          ))}
        </div>
      ) : rows.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border p-12 text-center">
          <Bookmark className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">No bookmarks yet. Save items from search or case pages.</p>
        </div>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {rows.map((b) => b.item && (
            <div key={b.id} className="rounded-xl border border-border bg-card p-4 flex justify-between gap-3">
              <Link to="/dashboard/case/$id" params={{ id: b.item.id }} className="min-w-0 flex-1">
                <div className="text-[11px] font-mono text-muted-foreground">{b.item.case_id}</div>
                <div className="font-medium truncate">{b.item.item_name}</div>
                <div className="text-xs text-muted-foreground mt-1">{b.item.category} · {b.item.general_location} · {b.item.incident_date}</div>
                <div className="mt-2 flex gap-2">
                  <span className={`text-[10px] font-bold uppercase ${b.item.report_type === "lost" ? "text-red-600 dark:text-red-400" : "text-emerald-600 dark:text-emerald-400"}`}>{b.item.report_type}</span>
                  <StatusBadge status={b.item.status} />
                </div>
              </Link>
              <button onClick={() => remove(b.id)} className="text-muted-foreground hover:text-destructive p-1" aria-label="Remove bookmark">
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}