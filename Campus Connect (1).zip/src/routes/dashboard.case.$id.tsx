import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  AlertTriangle, ArrowLeft, Calendar, Check, CheckCircle2, Clock, FileText, Handshake,
  Mail, MapPin, MessageSquare, Package, Phone, Send, Shield, Star, User, X,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { DisclaimerBox } from "@/components/DisclaimerBox";
import { GENERAL_LOCATIONS, createNotification, logAudit, recordHistory } from "@/lib/tce";
import { compressImage } from "@/lib/image";

export const Route = createFileRoute("/dashboard/case/$id")({
  component: CaseDetail,
});

function CaseDetail() {
  const { id } = Route.useParams();
  const { user, isAdmin } = useAuth();
  const [item, setItem] = useState<any>(null);
  const [claims, setClaims] = useState<any[]>([]);
  const [imageSignedUrls, setImageSignedUrls] = useState<string[]>([]);
  const [refreshKey, setRefreshKey] = useState(0);
  const [showClaim, setShowClaim] = useState(false);

  const reload = () => setRefreshKey((k) => k + 1);

  useEffect(() => {
    (async () => {
      const { data: it } = await supabase.from("items").select("*, reporter:profiles!items_reporter_id_fkey(full_name,email,phone,register_no,department)").eq("id", id).maybeSingle();
      setItem(it);
      if (it && user) {
        recordHistory({ user_id: user.id, viewed_item_id: it.id, kind: "view" });
      }
      const { data: cl } = await supabase.from("claims").select("*, claimant:profiles!claims_claimant_id_fkey(full_name,email,phone,register_no,department)").eq("item_id", id).order("created_at", { ascending: false });
      setClaims(cl ?? []);

      if (it?.image_urls?.length && (it.reporter_id === user?.id || isAdmin)) {
        const urls: string[] = [];
        const bucket = it.report_type === "lost" ? "lost-items" : "found-items";
        for (const path of it.image_urls) {
          // Newer uploads live in lost-items/found-items; older uploads live in item-images.
          let signedUrl: string | null = null;
          const { data: primary } = await supabase.storage.from(bucket).createSignedUrl(path, 3600);
          if (primary?.signedUrl) signedUrl = primary.signedUrl;
          if (!signedUrl) {
            const { data: legacy } = await supabase.storage.from("item-images").createSignedUrl(path, 3600);
            if (legacy?.signedUrl) signedUrl = legacy.signedUrl;
          }
          if (signedUrl) urls.push(signedUrl);
        }
        setImageSignedUrls(urls);
      } else {
        setImageSignedUrls([]);
      }
    })();
  }, [id, user, isAdmin, refreshKey]);

  // Realtime: reload the case whenever items/claims/meetings/notifications change for this case.
  useEffect(() => {
    const channel = supabase
      .channel(`case-${id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "items", filter: `id=eq.${id}` }, () => reload())
      .on("postgres_changes", { event: "*", schema: "public", table: "claims", filter: `item_id=eq.${id}` }, () => reload())
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (!item) return <div className="text-center py-16 text-muted-foreground">Loading...</div>;

  const isReporter = item.reporter_id === user?.id;
  const canSeePrivate = isReporter || isAdmin;
  const myClaim = claims.find((c) => c.claimant_id === user?.id);

  return (
    <div className="space-y-6">
      <Link to="/dashboard/my-reports" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Back
      </Link>

      <div className="rounded-2xl border border-border bg-card p-6 space-y-5">
        <div className="flex justify-between items-start gap-4 flex-wrap">
          <div>
            <div className="text-xs font-mono text-muted-foreground">{item.case_id}</div>
            <h1 className="text-2xl font-bold mt-1">{item.item_name}</h1>
            <div className="mt-2 flex gap-2 flex-wrap">
              <span className={`text-xs font-bold uppercase px-2 py-0.5 rounded ${item.report_type === "lost" ? "bg-red-500/10 text-red-600 dark:text-red-400" : "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"}`}>{item.report_type}</span>
              <StatusBadge status={item.status} />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
          <Info label="Category" value={item.category} />
          <Info label="Date" value={item.incident_date} icon={<Calendar className="h-3.5 w-3.5" />} />
          <Info label="Time" value={item.incident_time ?? "—"} icon={<Clock className="h-3.5 w-3.5" />} />
          <Info label="General Location" value={item.general_location} icon={<MapPin className="h-3.5 w-3.5" />} />
          {canSeePrivate && <Info label="Exact Location" value={item.location} />}
          {canSeePrivate && <Info label="Brand" value={item.brand ?? "—"} />}
          {canSeePrivate && <Info label="Colour" value={item.colour ?? "—"} />}
          {canSeePrivate && <Info label="Reward" value={item.reward ?? "—"} />}
          {canSeePrivate && <Info label="Contact" value={item.contact_number} />}
        </div>

        {canSeePrivate && (
          <>
            <div>
              <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Description</div>
              <p className="mt-1 text-sm">{item.description}</p>
            </div>
            {item.identification_marks && (
              <div>
                <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Identification Marks</div>
                <p className="mt-1 text-sm">{item.identification_marks}</p>
              </div>
            )}
            {imageSignedUrls.length > 0 && (
              <div className="flex gap-2 flex-wrap">
                {imageSignedUrls.map((u, i) => (
                  <img key={i} src={u} alt="" className="h-24 w-24 object-cover rounded-lg border border-border" />
                ))}
              </div>
            )}
          </>
        )}

        {!canSeePrivate && (
          <div className="rounded-lg border border-dashed border-border p-3 text-xs text-muted-foreground">
            Full details, photos, and contact info are visible only to the item reporter and the administrator.
          </div>
        )}
      </div>

      {/* Timeline */}
      <Timeline item={item} claims={claims} />

      {/* Admin controls */}
      {isAdmin && <AdminControls item={item} claims={claims} onDone={reload} />}

      {/* Claim CTA */}
      {item.report_type === "found" && !isReporter && !myClaim && item.status === "approved" && (
        <div className="rounded-2xl border border-border bg-card p-6">
          {!showClaim ? (
            <Button onClick={() => setShowClaim(true)} className="w-full gap-2">
              <Package className="h-4 w-4" /> This might be mine — Submit a claim
            </Button>
          ) : (
            <ClaimForm item={item} onCancel={() => setShowClaim(false)} onDone={() => { setShowClaim(false); reload(); }} />
          )}
        </div>
      )}

      {/* Claims list */}
      {(isReporter || isAdmin) && claims.length > 0 && (
        <div className="rounded-2xl border border-border bg-card p-6 space-y-3">
          <h2 className="font-semibold">Claims on this item ({claims.length})</h2>
          {claims.map((c) => (
            <ClaimCard key={c.id} claim={c} isReporter={isReporter} isAdmin={isAdmin} onDone={reload} />
          ))}
        </div>
      )}

      {/* My claim status */}
      {myClaim && (
        <div className="rounded-2xl border border-border bg-card p-6 space-y-3">
          <div className="flex justify-between items-center">
            <h2 className="font-semibold">Your claim</h2>
            <StatusBadge status={myClaim.status} />
          </div>
          <ClaimCard claim={myClaim} isReporter={false} isAdmin={false} isMine onDone={reload} />
        </div>
      )}

      {/* Feedback (resolved case) */}
      {item.status === "resolved" && claims.find((c) => c.status === "approved") && (
        <FeedbackBlock claim={claims.find((c) => c.status === "approved")} />
      )}
    </div>
  );
}

function Info({ label, value, icon }: { label: string; value: string; icon?: React.ReactNode }) {
  return (
    <div>
      <div className="text-[11px] uppercase tracking-wider text-muted-foreground flex items-center gap-1">{icon} {label}</div>
      <div className="mt-1 font-medium text-sm">{value}</div>
    </div>
  );
}

function Timeline({ item, claims }: any) {
  const approvedClaim = claims.find((c: any) => c.status === "approved" || c.status === "resolved");
  const rejectedClaim = claims.find((c: any) => c.status === "rejected");
  const activeClaim = approvedClaim ?? claims[0];

  const events: Array<{ label: string; at?: string; done: boolean; current?: boolean }> = [
    { label: "Report Submitted", at: item.created_at, done: true },
    { label: "Verified by Admin", at: item.updated_at, done: ["approved", "matched", "claimed", "handed_over", "resolved"].includes(item.status) },
    { label: "Claim Submitted", at: claims[0]?.created_at, done: claims.length > 0 },
    { label: "Under Review", at: claims[0]?.updated_at, done: claims.length > 0 },
    {
      label: rejectedClaim && !approvedClaim ? "Claim Rejected" : "Claim Approved",
      at: (approvedClaim ?? rejectedClaim)?.updated_at,
      done: !!(approvedClaim || rejectedClaim),
    },
    { label: "Contact Details Shared", at: activeClaim?.contact_shared_at, done: !!activeClaim?.contact_shared_at },
    { label: "Finder Confirmed Handover", at: activeClaim?.finder_confirmed_at, done: !!activeClaim?.finder_confirmed },
    { label: "Owner Confirmed Receipt", at: activeClaim?.owner_confirmed_at, done: !!activeClaim?.owner_confirmed },
    { label: "Resolved", at: activeClaim?.resolved_at ?? item.updated_at, done: item.status === "resolved" },
  ];
  const currentIndex = events.findIndex((e) => !e.done);
  if (currentIndex >= 0) events[currentIndex].current = true;

  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <h2 className="font-semibold mb-4">Case Timeline</h2>
      <ol className="relative pl-6 space-y-3 before:absolute before:left-2 before:top-1 before:bottom-1 before:w-px before:bg-border">
        {events.map((e, i) => (
          <li key={i} className="relative">
            <span
              className={`absolute -left-[19px] top-1.5 h-3 w-3 rounded-full ring-2 ring-background ${
                e.done ? "bg-primary" : e.current ? "bg-primary/40 animate-pulse" : "bg-muted"
              }`}
            />
            <div className={`text-sm ${e.done ? "text-foreground font-medium" : e.current ? "text-foreground" : "text-muted-foreground"}`}>
              {e.label}
              {e.current && <span className="ml-2 text-[10px] text-primary font-semibold uppercase">In progress</span>}
            </div>
            {e.at && <div className="text-[11px] text-muted-foreground">{new Date(e.at).toLocaleString()}</div>}
          </li>
        ))}
      </ol>
    </div>
  );
}

function ClaimForm({ item, onDone, onCancel }: any) {
  const { user } = useAuth();
  const [f, setF] = useState({
    reason: "",
    brand: "",
    colour: "",
    identification_marks: "",
    approx_date: "",
    approx_time: "",
    approx_location: "",
    additional_desc: "",
  });
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [warningAccepted, setWarningAccepted] = useState(false);
  const [step, setStep] = useState<"warning" | "form">("warning");
  const [saving, setSaving] = useState(false);

  const ALLOWED_PROOF = ["application/pdf", "image/jpeg", "image/jpg", "image/png"];
  const MAX_PROOF_MB = 5;

  const onProof = (file: File | null) => {
    if (!file) return setProofFile(null);
    if (!ALLOWED_PROOF.includes(file.type.toLowerCase())) {
      toast.error("Only PDF, JPG, JPEG, or PNG files are accepted.");
      return;
    }
    if (file.size > MAX_PROOF_MB * 1024 * 1024) {
      toast.error(`File exceeds the ${MAX_PROOF_MB} MB limit.`);
      return;
    }
    setProofFile(file);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!warningAccepted) return toast.error("Please accept the ownership warning.");
    if (!f.reason.trim()) return toast.error("Please explain why the item belongs to you.");
    if (f.reason.trim().length < 20) return toast.error("Reason must be at least 20 characters.");

    setSaving(true);
    try {
      // Duplicate guard
      const { data: existing } = await supabase
        .from("claims")
        .select("id,case_id")
        .eq("item_id", item.id)
        .eq("claimant_id", user.id)
        .maybeSingle();
      if (existing) {
        toast.error(`You already submitted claim ${existing.case_id} for this item.`);
        setSaving(false);
        return;
      }

      const { data: cid } = await supabase.rpc("generate_case_id", { _type: "lost" });
      const proofUrls: string[] = [];
      if (proofFile) {
        let toUpload: File = proofFile;
        if (proofFile.type.startsWith("image/")) {
          toUpload = await compressImage(proofFile);
        }
        const safe = toUpload.name.replace(/[^a-zA-Z0-9._-]/g, "_");
        const path = `${user.id}/${cid}/${Date.now()}-${safe}`;
        const { error } = await supabase.storage.from("claim-documents").upload(path, toUpload, {
          upsert: false,
          contentType: toUpload.type,
        });
        if (error) throw error;
        proofUrls.push(path);
      }
      const { data: inserted, error } = await supabase.from("claims").insert({
        case_id: cid as unknown as string,
        item_id: item.id,
        claimant_id: user.id,
        reason: f.reason.trim(),
        brand: f.brand.trim() || null,
        colour: f.colour.trim() || null,
        identification_marks: f.identification_marks.trim() || null,
        approx_date: f.approx_date || null,
        approx_time: f.approx_time || null,
        approx_location: f.approx_location.trim() || null,
        additional_desc: f.additional_desc.trim() || null,
        proof_urls: proofUrls,
      }).select("id,case_id").single();
      if (error) throw error;

      await createNotification({
        user_id: item.reporter_id,
        type: "claim_submitted",
        title: "A claim was submitted on your found item",
        message: `A user has claimed ${item.case_id}. Awaiting admin review.`,
        case_id: item.case_id,
      });
      await createNotification({
        user_id: user.id,
        type: "claim_submitted",
        title: "Claim submitted",
        message: `Your claim ${inserted.case_id} is pending admin review.`,
        case_id: inserted.case_id,
      });
      await logAudit({ action: "claim_submitted", entity: "claim", entity_id: inserted.id, metadata: { item_id: item.id, case_id: inserted.case_id } });
      toast.success(`Claim ${inserted.case_id} submitted`);
      onDone();
    } catch (err: any) {
      toast.error(err.message ?? "Failed to submit claim");
    } finally {
      setSaving(false);
    }
  };

  if (step === "warning") {
    return (
      <div className="space-y-4">
        <div className="rounded-xl border-2 border-amber-500/40 bg-amber-500/5 p-5">
          <div className="flex gap-3">
            <AlertTriangle className="h-6 w-6 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-amber-900 dark:text-amber-200">Ownership Claim Warning</h3>
              <p className="text-sm text-amber-800 dark:text-amber-300 mt-2 leading-relaxed">
                Only submit a claim if you are the genuine owner. False claims are recorded and may result in disciplinary action.
              </p>
            </div>
          </div>
        </div>
        <label className="flex items-start gap-2 text-sm cursor-pointer">
          <input
            type="checkbox"
            checked={warningAccepted}
            onChange={(e) => setWarningAccepted(e.target.checked)}
            className="mt-1"
          />
          <span>I understand and confirm that I am the rightful owner of this item.</span>
        </label>
        <div className="flex gap-2">
          <Button disabled={!warningAccepted} onClick={() => setStep("form")}>Continue to claim form</Button>
          {onCancel && <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>}
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="font-semibold">Ownership Claim Form</h3>
        {onCancel && (
          <Button type="button" variant="ghost" size="sm" onClick={onCancel}>
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>
      <div className="space-y-1.5">
        <Label>Why do you believe this item belongs to you? *</Label>
        <Textarea rows={3} value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} placeholder="At least 20 characters. Include details only the owner would know." />
      </div>
      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-1.5"><Label>Item Brand</Label><Input value={f.brand} onChange={(e) => setF({ ...f, brand: e.target.value })} /></div>
        <div className="space-y-1.5"><Label>Item Colour</Label><Input value={f.colour} onChange={(e) => setF({ ...f, colour: e.target.value })} /></div>
        <div className="space-y-1.5 md:col-span-2">
          <Label>Unique Identification Marks</Label>
          <Textarea rows={2} value={f.identification_marks} onChange={(e) => setF({ ...f, identification_marks: e.target.value })} placeholder="Scratches, engravings, stickers, contents inside, etc." />
        </div>
        <div className="space-y-1.5"><Label>Approx. Date Lost</Label><Input type="date" value={f.approx_date} onChange={(e) => setF({ ...f, approx_date: e.target.value })} /></div>
        <div className="space-y-1.5"><Label>Approx. Time Lost</Label><Input type="time" value={f.approx_time} onChange={(e) => setF({ ...f, approx_time: e.target.value })} /></div>
        <div className="space-y-1.5 md:col-span-2">
          <Label>Approx. Location Lost</Label>
          <select value={f.approx_location} onChange={(e) => setF({ ...f, approx_location: e.target.value })} className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm">
            <option value="">Select location</option>
            {GENERAL_LOCATIONS.map((l) => <option key={l} value={l}>{l}</option>)}
          </select>
        </div>
        <div className="space-y-1.5 md:col-span-2">
          <Label>Additional Description</Label>
          <Textarea rows={2} value={f.additional_desc} onChange={(e) => setF({ ...f, additional_desc: e.target.value })} />
        </div>
        <div className="space-y-1.5 md:col-span-2">
          <Label>Supporting Proof (optional — PDF, JPG, PNG, max 5 MB)</Label>
          <p className="text-[11px] text-muted-foreground">Purchase receipt, previous photograph, identity proof, or warranty card.</p>
          <div className="flex items-center gap-2">
            <Input
              type="file"
              accept="application/pdf,image/jpeg,image/jpg,image/png"
              onChange={(e) => onProof(e.target.files?.[0] ?? null)}
            />
          </div>
          {proofFile && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
              <FileText className="h-3.5 w-3.5" />
              {proofFile.name} · {(proofFile.size / 1024).toFixed(0)} KB
              <button type="button" onClick={() => setProofFile(null)} className="text-destructive hover:underline">Remove</button>
            </div>
          )}
        </div>
      </div>
      <div className="flex gap-2">
        <Button type="submit" disabled={saving}>
          {saving ? "Submitting..." : "Submit Claim"}
        </Button>
        <Button type="button" variant="ghost" onClick={() => setStep("warning")}>Back</Button>
      </div>
    </form>
  );
}

function AdminControls({ item, claims, onDone }: any) {
  const [note, setNote] = useState(item.admin_notes ?? "");
  const [busy, setBusy] = useState(false);

  const update = async (patch: any, action: string) => {
    setBusy(true);
    const { error } = await supabase.from("items").update({ ...patch, admin_notes: note }).eq("id", item.id);
    if (error) { toast.error(error.message); setBusy(false); return; }
    await createNotification({ user_id: item.reporter_id, type: patch.status === "approved" ? "report_approved" : "report_rejected", title: `Report ${patch.status}`, message: `Your report ${item.case_id} was ${patch.status}.`, case_id: item.case_id });
    await logAudit({ action, entity: "item", entity_id: item.id });
    toast.success(`Report ${patch.status}`);
    setBusy(false);
    onDone();
  };

  return (
    <div className="rounded-2xl border border-primary/30 bg-primary/5 p-6 space-y-4">
      <div className="flex items-center gap-2">
        <Shield className="h-4 w-4 text-primary" />
        <h2 className="font-semibold">Administrator Controls</h2>
      </div>
      <div className="space-y-1.5">
        <Label>Admin notes (private)</Label>
        <Textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} />
      </div>
      <div className="flex flex-wrap gap-2">
        {item.status === "pending_verification" && (
          <>
            <Button size="sm" onClick={() => update({ status: "approved" }, "item_approved")} disabled={busy}>
              <Check className="h-4 w-4 mr-1" /> Approve
            </Button>
            <Button size="sm" variant="destructive" onClick={() => update({ status: "rejected" }, "item_rejected")} disabled={busy}>Reject</Button>
          </>
        )}
        {item.status !== "resolved" && item.status !== "archived" && (
          <Button size="sm" variant="outline" onClick={() => update({ status: "resolved" }, "item_resolved")} disabled={busy}>Mark Resolved</Button>
        )}
        {item.status === "resolved" && (
          <Button size="sm" variant="ghost" onClick={() => update({ status: "archived" }, "item_archived")} disabled={busy}>Archive</Button>
        )}
      </div>

      {/* Reporter info */}
      {item.reporter && (
        <div className="text-xs text-muted-foreground border-t border-border pt-3">
          Reporter: {item.reporter.full_name} · {item.reporter.email} · {item.reporter.phone ?? "no phone"} · {item.reporter.department}
        </div>
      )}

      {claims.length > 0 && <SmartMatch item={item} />}
    </div>
  );
}

function SmartMatch({ item }: any) {
  const [matches, setMatches] = useState<any[]>([]);
  useEffect(() => {
    const oppType = item.report_type === "lost" ? "found" : "lost";
    supabase.from("items").select("id,case_id,item_name,category,colour,brand,general_location,incident_date")
      .eq("report_type", oppType)
      .eq("category", item.category)
      .in("status", ["approved", "matched"])
      .limit(10)
      .then(({ data }) => {
        const q = (item.item_name + " " + (item.colour ?? "") + " " + (item.brand ?? "")).toLowerCase();
        const scored = (data ?? []).map((m: any) => {
          const t = (m.item_name + " " + (m.colour ?? "") + " " + (m.brand ?? "")).toLowerCase();
          let score = 0;
          q.split(/\s+/).forEach((w) => { if (w && t.includes(w)) score++; });
          if (m.general_location === item.general_location) score += 2;
          return { ...m, score };
        }).filter((m: any) => m.score > 0).sort((a: any, b: any) => b.score - a.score);
        setMatches(scored);
      });
  }, [item.id]);

  if (matches.length === 0) return null;
  return (
    <div className="border-t border-border pt-3">
      <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Possible matches (admin only)</div>
      <div className="space-y-1">
        {matches.map((m) => (
          <Link key={m.id} to="/dashboard/case/$id" params={{ id: m.id }} className="block rounded-lg border border-border bg-background p-2 text-sm hover:border-primary/40">
            <span className="font-mono text-xs text-muted-foreground">{m.case_id}</span> · {m.item_name} · {m.general_location} · match score {m.score}
          </Link>
        ))}
      </div>
    </div>
  );
}

function ClaimCard({ claim, isReporter, isAdmin, isMine, onDone }: any) {
  const { user } = useAuth();
  const [note, setNote] = useState(claim.admin_notes ?? "");
  const [busy, setBusy] = useState(false);

  const decide = async (status: "approved" | "rejected" | "more_info") => {
    setBusy(true);
    await supabase.from("claims").update({ status, admin_notes: note }).eq("id", claim.id);
    await supabase.from("items").update({ status: status === "approved" ? "claimed" : "approved" }).eq("id", claim.item_id);
    await createNotification({
      user_id: claim.claimant_id,
      type: status === "approved" ? "claim_approved" : status === "rejected" ? "claim_rejected" : "more_info_requested",
      title: `Claim ${status.replace("_", " ")}`,
      message: `Your claim ${claim.case_id} was ${status.replace("_", " ")}.`,
      case_id: claim.case_id,
    });
    await logAudit({ action: `claim_${status}`, entity: "claim", entity_id: claim.id });
    setBusy(false);
    toast.success("Updated");
    onDone();
  };

  const shareContacts = async () => {
    setBusy(true);
    try {
      const { data: auth } = await supabase.auth.getUser();
      await supabase.from("claims").update({
        reporter_reveal_ok: true,
        claimant_reveal_ok: true,
        contact_revealed: true,
        contact_shared_at: new Date().toISOString(),
        contact_shared_by: auth.user?.id ?? null,
      }).eq("id", claim.id);

      const [{ data: itemRow }, { data: claimantRow }] = await Promise.all([
        supabase.from("items").select("case_id, reporter_id, reporter:profiles!items_reporter_id_fkey(full_name,email,phone,department)").eq("id", claim.item_id).maybeSingle(),
        supabase.from("profiles").select("full_name,email,phone,department").eq("id", claim.claimant_id).maybeSingle(),
      ]);
      const rep: any = (itemRow as any)?.reporter ?? {};
      const clm: any = claimantRow ?? {};
      const caseRef = (itemRow as any)?.case_id ?? claim.case_id;

      await createNotification({
        user_id: claim.claimant_id,
        type: "contact_revealed",
        title: "Contact details shared",
        message: `Your claim ${caseRef} has been verified. Finder contact — ${rep.full_name ?? "N/A"} · ${rep.email ?? "no email"} · ${rep.phone ?? "no phone"}. Please coordinate and complete the handover within 24 hours.`,
        case_id: caseRef,
      });
      if ((itemRow as any)?.reporter_id) {
        await createNotification({
          user_id: (itemRow as any).reporter_id,
          type: "contact_revealed",
          title: "Contact details shared",
          message: `The claim on case ${caseRef} has been verified. Owner contact — ${clm.full_name ?? "N/A"} · ${clm.email ?? "no email"} · ${clm.phone ?? "no phone"}. Please coordinate and complete the handover within 24 hours.`,
          case_id: caseRef,
        });
      }
      await logAudit({ action: "admin_shared_contacts", entity: "claim", entity_id: claim.id });
      toast.success("Contact details shared with both users");
      onDone();
    } catch (e: any) {
      toast.error(e.message ?? "Failed to share contacts");
    } finally {
      setBusy(false);
    }
  };

  const confirmSide = async (side: "finder" | "owner", remarks: string) => {
    setBusy(true);
    const nowIso = new Date().toISOString();
    const patch = side === "finder"
      ? { finder_confirmed: true, finder_confirmed_at: nowIso, finder_confirm_remarks: remarks || null }
      : { owner_confirmed: true, owner_confirmed_at: nowIso, owner_confirm_remarks: remarks || null };
    await supabase.from("claims").update(patch).eq("id", claim.id);
    // Notify the other party
    const { data: itemRow } = await supabase.from("items").select("case_id, reporter_id").eq("id", claim.item_id).maybeSingle();
    const caseRef = (itemRow as any)?.case_id ?? claim.case_id;
    if (side === "finder") {
      await createNotification({
        user_id: claim.claimant_id, type: "item_handed_over",
        title: "Finder confirmed handover",
        message: `The finder confirmed handover for case ${caseRef}. Please confirm you have received the item.`,
        case_id: caseRef,
      });
    } else if ((itemRow as any)?.reporter_id) {
      await createNotification({
        user_id: (itemRow as any).reporter_id, type: "item_received",
        title: "Owner confirmed receipt",
        message: `The owner confirmed receipt for case ${caseRef}.`,
        case_id: caseRef,
      });
    }
    await logAudit({ action: side === "finder" ? "finder_confirmed" : "owner_confirmed", entity: "claim", entity_id: claim.id });
    setBusy(false);
    toast.success(side === "finder" ? "Handover confirmed" : "Receipt confirmed");
    onDone();
  };

  const markResolved = async () => {
    setBusy(true);
    const nowIso = new Date().toISOString();
    await supabase.from("claims").update({ status: "resolved", resolved_at: nowIso }).eq("id", claim.id);
    await supabase.from("items").update({ status: "resolved" }).eq("id", claim.item_id);
    const { data: itemRow } = await supabase.from("items").select("case_id, reporter_id").eq("id", claim.item_id).maybeSingle();
    const caseRef = (itemRow as any)?.case_id ?? claim.case_id;
    await createNotification({ user_id: claim.claimant_id, type: "case_resolved", title: "Case resolved", message: `Case ${caseRef} has been marked resolved. Thank you for using the portal.`, case_id: caseRef });
    if ((itemRow as any)?.reporter_id) {
      await createNotification({ user_id: (itemRow as any).reporter_id, type: "case_resolved", title: "Case resolved", message: `Case ${caseRef} has been marked resolved. Thank you for using the portal.`, case_id: caseRef });
    }
    await logAudit({ action: "case_resolved", entity: "claim", entity_id: claim.id });
    setBusy(false);
    toast.success("Marked resolved");
    onDone();
  };

  const isFinderSide = isReporter; // reporter of a found item hands over
  const isOwnerSide = isMine; // claimant is the owner receiving the item
  const bothConfirmed = claim.finder_confirmed && claim.owner_confirmed;

  return (
    <div className="rounded-xl border border-border bg-background p-4 space-y-2">
      <div className="flex justify-between items-start gap-2 flex-wrap">
        <div>
          <div className="text-[11px] font-mono text-muted-foreground">{claim.case_id}</div>
          {claim.claimant && (isReporter || isAdmin) && (
            <div className="text-sm font-medium">{claim.claimant.full_name} · {claim.claimant.department}</div>
          )}
          <p className="text-sm mt-1">{claim.reason}</p>
          {claim.identification_marks && <p className="text-xs text-muted-foreground mt-1">Marks: {claim.identification_marks}</p>}
        </div>
        <StatusBadge status={claim.status} />
      </div>

      {claim.status === "approved" && (
        <ContactAndHandoverBlock
          claim={claim}
          isAdmin={isAdmin}
          isFinderSide={isFinderSide}
          isOwnerSide={isOwnerSide}
          bothConfirmed={bothConfirmed}
          onShare={shareContacts}
          onConfirm={confirmSide}
          onResolve={markResolved}
          busy={busy}
        />
      )}
      {claim.status === "resolved" && (
        <div className="rounded-lg border border-emerald-600/40 bg-emerald-500/5 p-3 text-xs text-emerald-700 dark:text-emerald-400 flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4" /> Case resolved{claim.resolved_at ? ` on ${new Date(claim.resolved_at).toLocaleString()}` : ""}.
        </div>
      )}

      {isAdmin && claim.status === "pending" && (
        <div className="border-t border-border pt-3 space-y-2">
          <Textarea rows={2} placeholder="Private admin note" value={note} onChange={(e) => setNote(e.target.value)} />
          <div className="flex flex-wrap gap-2">
            <Button size="sm" onClick={() => decide("approved")} disabled={busy}><Check className="h-4 w-4 mr-1" /> Approve</Button>
            <Button size="sm" variant="destructive" onClick={() => decide("rejected")} disabled={busy}>Reject</Button>
            <Button size="sm" variant="outline" onClick={() => decide("more_info")} disabled={busy}>Request more info</Button>
          </div>
        </div>
      )}
    </div>
  );
}

function ContactAndHandoverBlock({ claim, isAdmin, isFinderSide, isOwnerSide, bothConfirmed, onShare, onConfirm, onResolve, busy }: any) {
  const [remarks, setRemarks] = useState("");
  const [ask, setAsk] = useState<null | "finder" | "owner">(null);

  const finderStatus = claim.finder_confirmed
    ? { text: "Finder confirmed handover", tone: "text-emerald-700 dark:text-emerald-400" }
    : claim.contact_shared_at ? { text: "Waiting for finder confirmation", tone: "text-amber-600 dark:text-amber-400" } : { text: "Pending", tone: "text-muted-foreground" };
  const ownerStatus = claim.owner_confirmed
    ? { text: "Owner confirmed receipt", tone: "text-emerald-700 dark:text-emerald-400" }
    : claim.contact_shared_at ? { text: "Waiting for owner confirmation", tone: "text-amber-600 dark:text-amber-400" } : { text: "Pending", tone: "text-muted-foreground" };

  return (
    <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/5 p-4 space-y-4">
      <div className="flex items-center gap-2">
        <Shield className="h-4 w-4 text-emerald-600" />
        <span className="font-semibold text-sm">Contact Sharing &amp; Handover</span>
      </div>

      {!claim.contact_shared_at && (
        <>
          <p className="text-xs text-muted-foreground">
            The administrator will share both parties' contact details after verifying this claim.
          </p>
          {isAdmin && (
            <div>
              <Button size="sm" onClick={onShare} disabled={busy} className="gap-1">
                <Send className="h-4 w-4" /> Share Contact Details
              </Button>
              <p className="text-[11px] text-muted-foreground mt-2">
                Reveals each party's name, email and phone to the other and starts the 24-hour handover window.
              </p>
            </div>
          )}
        </>
      )}

      {claim.contact_shared_at && (
        <>
          <div className="rounded-md border border-emerald-500/40 bg-background p-3 text-xs">
            <p>Your claim has been verified successfully. The administrator has shared the contact details of both parties. Please communicate with each other and complete the item handover within 24 hours.</p>
            <p className="mt-1 text-muted-foreground">Shared on {new Date(claim.contact_shared_at).toLocaleString()}.</p>
          </div>

          {(isFinderSide || isAdmin) && (
            <ContactPanel title="Owner (claimant)" name={claim.claimant?.full_name} email={claim.claimant?.email} phone={claim.claimant?.phone} dept={claim.claimant?.department} />
          )}
          {(isOwnerSide || isAdmin) && (
            <FinderContactFetcher itemId={claim.item_id} />
          )}

          <div className="grid sm:grid-cols-2 gap-2 text-xs">
            <div className="rounded-md border border-border p-2">
              <div className="font-medium">Finder</div>
              <div className={finderStatus.tone}>{finderStatus.text}</div>
              {claim.finder_confirmed_at && <div className="text-[11px] text-muted-foreground mt-1">{new Date(claim.finder_confirmed_at).toLocaleString()}</div>}
              {claim.finder_confirm_remarks && <div className="text-[11px] mt-1">"{claim.finder_confirm_remarks}"</div>}
            </div>
            <div className="rounded-md border border-border p-2">
              <div className="font-medium">Owner</div>
              <div className={ownerStatus.tone}>{ownerStatus.text}</div>
              {claim.owner_confirmed_at && <div className="text-[11px] text-muted-foreground mt-1">{new Date(claim.owner_confirmed_at).toLocaleString()}</div>}
              {claim.owner_confirm_remarks && <div className="text-[11px] mt-1">"{claim.owner_confirm_remarks}"</div>}
            </div>
          </div>

          {isFinderSide && !claim.finder_confirmed && (
            ask === "finder" ? (
              <div className="rounded-md border border-border bg-background p-3 space-y-2">
                <Label className="text-xs">Remarks (optional)</Label>
                <Textarea rows={2} value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="Any handover notes." />
                <div className="text-xs text-muted-foreground">Please confirm only after you have physically handed the item over.</div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={() => { onConfirm("finder", remarks); setAsk(null); setRemarks(""); }} disabled={busy}>Yes, confirm handover</Button>
                  <Button size="sm" variant="ghost" onClick={() => setAsk(null)}>Cancel</Button>
                </div>
              </div>
            ) : (
              <Button size="sm" onClick={() => setAsk("finder")} className="gap-1"><Handshake className="h-4 w-4" /> I have handed over the item</Button>
            )
          )}
          {isOwnerSide && !claim.owner_confirmed && (
            ask === "owner" ? (
              <div className="rounded-md border border-border bg-background p-3 space-y-2">
                <Label className="text-xs">Remarks (optional)</Label>
                <Textarea rows={2} value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="Condition of the item, any comments." />
                <div className="text-xs text-muted-foreground">Please confirm only after you have physically received the item.</div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={() => { onConfirm("owner", remarks); setAsk(null); setRemarks(""); }} disabled={busy}>Yes, confirm receipt</Button>
                  <Button size="sm" variant="ghost" onClick={() => setAsk(null)}>Cancel</Button>
                </div>
              </div>
            ) : (
              <Button size="sm" onClick={() => setAsk("owner")} className="gap-1"><CheckCircle2 className="h-4 w-4" /> I have received the item</Button>
            )
          )}

          {isAdmin && bothConfirmed && (
            <div className="border-t border-emerald-500/30 pt-3">
              <Button size="sm" onClick={onResolve} disabled={busy} className="gap-1">
                <CheckCircle2 className="h-4 w-4" /> Mark case as resolved
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function ContactPanel({ title, name, email, phone, dept }: { title: string; name?: string; email?: string; phone?: string | null; dept?: string | null }) {
  return (
    <div className="rounded-md border border-border bg-background p-3 text-xs space-y-1">
      <div className="font-semibold text-foreground">{title}</div>
      <div className="flex items-center gap-2"><User className="h-3.5 w-3.5 text-muted-foreground" /> {name ?? "N/A"}{dept ? <span className="text-muted-foreground">· {dept}</span> : null}</div>
      <div className="flex items-center gap-2"><Mail className="h-3.5 w-3.5 text-muted-foreground" /> {email ?? "no email"}</div>
      <div className="flex items-center gap-2"><Phone className="h-3.5 w-3.5 text-muted-foreground" /> {phone ?? "no phone"}</div>
    </div>
  );
}

function FinderContactFetcher({ itemId }: { itemId: string }) {
  const [row, setRow] = useState<any>(null);
  useEffect(() => {
    supabase.from("items").select("reporter:profiles!items_reporter_id_fkey(full_name,email,phone,department)").eq("id", itemId).maybeSingle().then(({ data }) => setRow(data));
  }, [itemId]);
  const r: any = (row as any)?.reporter;
  return <ContactPanel title="Finder (reporter)" name={r?.full_name} email={r?.email} phone={r?.phone} dept={r?.department} />;
}

function FeedbackBlock({ claim }: any) {
  const { user } = useAuth();
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [suggestions, setSuggestions] = useState("");
  const [recommend, setRecommend] = useState<boolean | null>(null);
  const [existing, setExisting] = useState<any>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase.from("feedback").select("*").eq("claim_id", claim.id).eq("user_id", user.id).maybeSingle().then(({ data }) => setExisting(data));
  }, [user, claim.id]);

  const submit = async () => {
    if (!user || rating === 0) return;
    setBusy(true);
    await supabase.from("feedback").insert({
      claim_id: claim.id, user_id: user.id, rating,
      comment: comment || null, suggestions: suggestions || null, recommend,
    });
    setBusy(false); setExisting({ rating, comment, suggestions, recommend });
    toast.success("Thanks for your feedback");
  };

  if (existing) return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <h2 className="font-semibold mb-2 flex items-center gap-2"><MessageSquare className="h-4 w-4" /> Your feedback</h2>
      <div className="flex gap-1">{[1,2,3,4,5].map(n => <Star key={n} className={`h-5 w-5 ${n <= existing.rating ? "fill-amber-400 text-amber-400" : "text-muted-foreground"}`} />)}</div>
      {existing.comment && <p className="text-sm text-muted-foreground mt-2">{existing.comment}</p>}
      {existing.suggestions && <p className="text-xs text-muted-foreground mt-1"><b>Suggestions:</b> {existing.suggestions}</p>}
      {existing.recommend !== undefined && existing.recommend !== null && (
        <p className="text-xs text-muted-foreground mt-1">Would recommend: <b>{existing.recommend ? "Yes" : "No"}</b></p>
      )}
    </div>
  );

  return (
    <div className="rounded-2xl border border-border bg-card p-6 space-y-3">
      <h2 className="font-semibold flex items-center gap-2"><MessageSquare className="h-4 w-4" /> Rate this resolution</h2>
      <div className="flex gap-1">
        {[1,2,3,4,5].map((n) => (
          <button key={n} onClick={() => setRating(n)}><Star className={`h-6 w-6 ${n <= rating ? "fill-amber-400 text-amber-400" : "text-muted-foreground"}`} /></button>
        ))}
      </div>
      <Textarea rows={2} value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Optional comment" />
      <Textarea rows={2} value={suggestions} onChange={(e) => setSuggestions(e.target.value)} placeholder="Suggestions to improve the portal" />
      <div className="flex gap-2 items-center text-sm">
        <span className="text-muted-foreground">Would you recommend this service?</span>
        <Button type="button" size="sm" variant={recommend === true ? "default" : "outline"} onClick={() => setRecommend(true)}>Yes</Button>
        <Button type="button" size="sm" variant={recommend === false ? "default" : "outline"} onClick={() => setRecommend(false)}>No</Button>
      </div>
      <Button size="sm" onClick={submit} disabled={busy || rating === 0}>Submit feedback</Button>
    </div>
  );
}