import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { GENERAL_LOCATIONS, ITEM_CATEGORIES, logAudit } from "@/lib/tce";

export const Route = createFileRoute("/dashboard/edit/$id")({
  component: EditReport,
});

function EditReport() {
  const { id } = Route.useParams();
  const { user } = useAuth();
  const nav = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [item, setItem] = useState<any | null>(null);
  const [f, setF] = useState<any>({});

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data, error } = await supabase.from("items").select("*").eq("id", id).maybeSingle();
      if (error || !data) {
        toast.error("Report not found");
        nav({ to: "/dashboard/my-reports" });
        return;
      }
      if (data.reporter_id !== user.id) {
        toast.error("You can only edit your own reports");
        nav({ to: "/dashboard/my-reports" });
        return;
      }
      if (data.status !== "pending_verification") {
        toast.error("This report has already been verified and can no longer be edited");
        nav({ to: "/dashboard/case/$id", params: { id } });
        return;
      }
      setItem(data);
      setF({
        item_name: data.item_name,
        category: data.category,
        brand: data.brand ?? "",
        colour: data.colour ?? "",
        description: data.description,
        identification_marks: data.identification_marks ?? "",
        incident_date: data.incident_date,
        incident_time: data.incident_time ?? "",
        location: data.location,
        general_location: data.general_location,
        reward: data.reward ?? "",
        contact_number: data.contact_number,
        current_holder: data.current_holder ?? "",
      });
      setLoading(false);
    })();
  }, [id, user?.id]);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!item) return;
    setSaving(true);
    const { error } = await supabase.from("items").update({
      item_name: f.item_name.trim(),
      category: f.category,
      brand: f.brand.trim() || null,
      colour: f.colour.trim() || null,
      description: f.description.trim(),
      identification_marks: f.identification_marks.trim() || null,
      incident_date: f.incident_date,
      incident_time: f.incident_time || null,
      location: f.location.trim(),
      general_location: f.general_location,
      reward: item.report_type === "lost" ? (f.reward.trim() || null) : null,
      contact_number: f.contact_number.trim(),
      current_holder: item.report_type === "found" ? (f.current_holder.trim() || null) : null,
    }).eq("id", item.id);
    setSaving(false);
    if (error) return toast.error(error.message);
    await logAudit({ action: "report_edited", entity: "item", entity_id: item.id, metadata: { case_id: item.case_id } });
    toast.success("Report updated");
    nav({ to: "/dashboard/my-reports" });
  };

  if (loading) {
    return (
      <div className="grid place-items-center py-24 text-muted-foreground">
        <Loader2 className="h-5 w-5 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Edit Report</h1>
        <p className="text-sm text-muted-foreground mt-1">
          <span className="font-mono">{item?.case_id}</span> · You can edit this report until it is verified.
        </p>
      </header>
      <form onSubmit={save} className="rounded-2xl border border-border bg-card p-6 space-y-4">
        <div className="grid md:grid-cols-2 gap-4">
          <F label="Item Name *" v={f.item_name} on={(v) => setF({ ...f, item_name: v })} />
          <div className="space-y-1.5">
            <Label>Category *</Label>
            <select value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm">
              {ITEM_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <F label="Brand" v={f.brand} on={(v) => setF({ ...f, brand: v })} />
          <F label="Colour" v={f.colour} on={(v) => setF({ ...f, colour: v })} />
          <div className="md:col-span-2 space-y-1.5"><Label>Description *</Label><Textarea rows={3} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
          <div className="md:col-span-2 space-y-1.5"><Label>Identification Marks</Label><Textarea rows={2} value={f.identification_marks} onChange={(e) => setF({ ...f, identification_marks: e.target.value })} /></div>
          <F label="Date *" type="date" v={f.incident_date} on={(v) => setF({ ...f, incident_date: v })} />
          <F label="Time" type="time" v={f.incident_time} on={(v) => setF({ ...f, incident_time: v })} />
          <div className="space-y-1.5">
            <Label>General Location *</Label>
            <select value={f.general_location} onChange={(e) => setF({ ...f, general_location: e.target.value })} className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm">
              {GENERAL_LOCATIONS.map((l) => <option key={l} value={l}>{l}</option>)}
            </select>
          </div>
          <F label="Approximate / Exact Location *" v={f.location} on={(v) => setF({ ...f, location: v })} />
          {item?.report_type === "lost" && <F label="Reward" v={f.reward} on={(v) => setF({ ...f, reward: v })} />}
          {item?.report_type === "found" && <F label="Current Holder" v={f.current_holder} on={(v) => setF({ ...f, current_holder: v })} />}
          <F label="Contact Number *" v={f.contact_number} on={(v) => setF({ ...f, contact_number: v })} />
        </div>
        <div className="flex gap-2">
          <Button type="submit" disabled={saving}>
            {saving ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Saving...</> : "Save changes"}
          </Button>
          <Button type="button" variant="outline" onClick={() => nav({ to: "/dashboard/my-reports" })}>Cancel</Button>
        </div>
      </form>
    </div>
  );
}

function F({ label, v, on, type = "text" }: { label: string; v: string; on: (v: string) => void; type?: string }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      <Input type={type} value={v ?? ""} onChange={(e) => on(e.target.value)} />
    </div>
  );
}