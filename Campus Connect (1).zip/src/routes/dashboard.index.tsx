import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Bell,
  CheckCircle2,
  ClipboardList,
  FileSearch,
  ListChecks,
  Loader2,
  Search,
  Shield,
  UserCircle,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { StatusBadge } from "@/components/StatusBadge";

export const Route = createFileRoute("/dashboard/")({
  component: DashboardHome,
});

interface Counts {
  lost: number;
  found: number;
  claims: number;
  notifications: number;
  active: number;
  resolved: number;
  pendingItems: number;
  pendingClaims: number;
}

const ACTIVE_STATUSES: Array<
  "pending_verification" | "approved" | "matched" | "claimed" | "handed_over"
> = [
  "pending_verification",
  "approved",
  "matched",
  "claimed",
  "handed_over",
];

function DashboardHome() {
  const { user, profile, isAdmin } = useAuth();
  const [counts, setCounts] = useState<Counts>({
    lost: 0,
    found: 0,
    claims: 0,
    notifications: 0,
    active: 0,
    resolved: 0,
    pendingItems: 0,
    pendingClaims: 0,
  });
  const [recentItems, setRecentItems] = useState<any[]>([]);
  const [recentNotes, setRecentNotes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = async (uid: string) => {
    const [lost, found, claims, notifs, active, resolved, items, notes] = await Promise.all([
      supabase.from("items").select("id", { count: "exact", head: true }).eq("reporter_id", uid).eq("report_type", "lost"),
      supabase.from("items").select("id", { count: "exact", head: true }).eq("reporter_id", uid).eq("report_type", "found"),
      supabase.from("claims").select("id", { count: "exact", head: true }).eq("claimant_id", uid),
      supabase.from("notifications").select("id", { count: "exact", head: true }).eq("user_id", uid).eq("read", false),
      supabase.from("items").select("id", { count: "exact", head: true }).eq("reporter_id", uid).in("status", ACTIVE_STATUSES),
      supabase.from("items").select("id", { count: "exact", head: true }).eq("reporter_id", uid).eq("status", "resolved"),
      supabase.from("items").select("id,case_id,item_name,category,general_location,report_type,status,created_at").eq("reporter_id", uid).order("created_at", { ascending: false }).limit(5),
      supabase.from("notifications").select("id,title,message,created_at,read").eq("user_id", uid).order("created_at", { ascending: false }).limit(5),
    ]);

    let pendingItems = 0;
    let pendingClaims = 0;
    if (isAdmin) {
      const [pi, pc] = await Promise.all([
        supabase.from("items").select("id", { count: "exact", head: true }).eq("status", "pending_verification"),
        supabase.from("claims").select("id", { count: "exact", head: true }).eq("status", "pending"),
      ]);
      pendingItems = pi.count ?? 0;
      pendingClaims = pc.count ?? 0;
    }

    setCounts({
      lost: lost.count ?? 0,
      found: found.count ?? 0,
      claims: claims.count ?? 0,
      notifications: notifs.count ?? 0,
      active: active.count ?? 0,
      resolved: resolved.count ?? 0,
      pendingItems,
      pendingClaims,
    });
    setRecentItems(items.data ?? []);
    setRecentNotes(notes.data ?? []);
    setLoading(false);
  };

  useEffect(() => {
    if (!user) return;
    refresh(user.id);
    // Realtime: refresh stats when own items/claims/notifications change
    const channel = supabase
      .channel(`dashboard-${user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "items", filter: `reporter_id=eq.${user.id}` }, () => refresh(user.id))
      .on("postgres_changes", { event: "*", schema: "public", table: "claims", filter: `claimant_id=eq.${user.id}` }, () => refresh(user.id))
      .on("postgres_changes", { event: "*", schema: "public", table: "notifications", filter: `user_id=eq.${user.id}` }, () => refresh(user.id))
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, isAdmin]);

  const firstName = profile?.full_name?.split(" ")[0] ?? "";

  return (
    <div className="space-y-6">
      {/* Welcome banner + profile card */}
      <section className="rounded-2xl border border-border bg-gradient-to-br from-primary/10 via-card to-card p-6 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="h-14 w-14 rounded-full bg-primary/15 text-primary grid place-items-center">
              <UserCircle className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Welcome{firstName ? `, ${firstName}` : ""}</h1>
              <p className="text-sm text-muted-foreground mt-1">
                {isAdmin
                  ? "Administrator dashboard — verify reports and manage the portal."
                  : "Your personal TCE Lost & Found workspace."}
              </p>
              {profile && (
                <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground mt-2">
                  {profile.department && <span>{profile.department}</span>}
                  {profile.register_no && <span>· {profile.register_no}</span>}
                  <span>· {profile.email}</span>
                </div>
              )}
            </div>
          </div>
          <Link
            to="/dashboard/profile"
            className="text-xs font-medium text-primary hover:underline"
          >
            Manage profile →
          </Link>
        </div>
      </section>

      {/* Statistic cards */}
      <section className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <StatCard label="Lost Reported" value={counts.lost} tone="red" Icon={FileSearch} />
        <StatCard label="Found Reported" value={counts.found} tone="emerald" Icon={ClipboardList} />
        <StatCard label="Claims Submitted" value={counts.claims} tone="purple" Icon={ListChecks} />
        <StatCard label="Active Cases" value={counts.active} tone="blue" Icon={Loader2} />
        <StatCard label="Resolved" value={counts.resolved} tone="emerald" Icon={CheckCircle2} />
        <StatCard label="Notifications" value={counts.notifications} tone="amber" Icon={Bell} />
      </section>

      {isAdmin && (
        <section className="grid grid-cols-2 gap-3">
          <StatCard label="Pending Verifications" value={counts.pendingItems} tone="amber" Icon={Shield} />
          <StatCard label="Pending Claims" value={counts.pendingClaims} tone="amber" Icon={ListChecks} />
        </section>
      )}

      {/* Quick actions */}
      <section>
        <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-3">Quick Actions</h2>
        <div className="grid md:grid-cols-2 gap-3">
          <QuickAction to="/dashboard/report-lost" title="Report a Lost Item" desc="File a lost item report for admin verification." Icon={FileSearch} />
          <QuickAction to="/dashboard/report-found" title="Report a Found Item" desc="Turn in a found item through the portal." Icon={ClipboardList} />
          <QuickAction to="/dashboard/search" title="Search Items" desc="Browse verified lost and found reports." Icon={Search} />
          <QuickAction to="/dashboard/notifications" title="Notifications" desc="View updates on your reports and claims." Icon={Bell} />
          {isAdmin && (
            <QuickAction to="/dashboard/admin/verifications" title="Verify Reports & Claims" desc="Review pending submissions." Icon={Shield} />
          )}
        </div>
      </section>

      {/* Recent activity + notifications */}
      <section className="grid lg:grid-cols-2 gap-4">
        <div className="rounded-2xl border border-border bg-card p-5">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Recent Activity</h2>
            <Link to="/dashboard/my-reports" className="text-xs text-primary hover:underline">View all</Link>
          </div>
          {loading ? (
            <SkeletonList />
          ) : recentItems.length === 0 ? (
            <EmptyRow text="No reports yet — file your first one from the quick actions above." />
          ) : (
            <ul className="divide-y divide-border">
              {recentItems.map((it) => (
                <li key={it.id} className="py-2.5">
                  <Link to="/dashboard/case/$id" params={{ id: it.id }} className="flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="text-[10px] font-mono text-muted-foreground">{it.case_id}</div>
                      <div className="text-sm font-medium truncate">{it.item_name}</div>
                      <div className="text-[11px] text-muted-foreground">
                        {it.category} · {it.general_location}
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <span className={`text-[10px] font-bold uppercase ${it.report_type === "lost" ? "text-red-600 dark:text-red-400" : "text-emerald-600 dark:text-emerald-400"}`}>
                        {it.report_type}
                      </span>
                      <StatusBadge status={it.status} />
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="rounded-2xl border border-border bg-card p-5">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Notifications</h2>
            <Link to="/dashboard/notifications" className="text-xs text-primary hover:underline">View all</Link>
          </div>
          {loading ? (
            <SkeletonList />
          ) : recentNotes.length === 0 ? (
            <EmptyRow text="You're all caught up." />
          ) : (
            <ul className="divide-y divide-border">
              {recentNotes.map((n) => (
                <li key={n.id} className="py-2.5 flex gap-3">
                  <div className={`mt-1 h-2 w-2 rounded-full flex-shrink-0 ${n.read ? "bg-muted" : "bg-primary"}`} />
                  <div className="min-w-0">
                    <div className="text-sm font-medium truncate">{n.title}</div>
                    <div className="text-xs text-muted-foreground line-clamp-2">{n.message}</div>
                    <div className="text-[10px] text-muted-foreground mt-1">
                      {new Date(n.created_at).toLocaleString()}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </div>
  );
}

function StatCard({
  label,
  value,
  tone = "blue",
  Icon,
}: {
  label: string;
  value: number;
  tone?: "red" | "emerald" | "purple" | "blue" | "amber";
  Icon: any;
}) {
  const tones: Record<string, string> = {
    red: "text-red-600 dark:text-red-400 bg-red-500/10",
    emerald: "text-emerald-600 dark:text-emerald-400 bg-emerald-500/10",
    purple: "text-purple-600 dark:text-purple-400 bg-purple-500/10",
    blue: "text-blue-600 dark:text-blue-400 bg-blue-500/10",
    amber: "text-amber-600 dark:text-amber-400 bg-amber-500/10",
  };
  return (
    <div className="rounded-2xl border border-border bg-card p-4 shadow-sm hover:shadow-md transition-shadow">
      <div className={`h-8 w-8 rounded-lg grid place-items-center ${tones[tone]}`}>
        <Icon className="h-4 w-4" />
      </div>
      <div className="text-2xl font-bold tabular-nums mt-2">{value}</div>
      <div className="text-[11px] text-muted-foreground mt-0.5 leading-tight">{label}</div>
    </div>
  );
}

function QuickAction({ to, title, desc, Icon }: { to: string; title: string; desc: string; Icon: any }) {
  return (
    <Link to={to} className="rounded-2xl border border-border bg-card p-4 flex gap-4 hover:border-primary/40 hover:shadow-md transition-all">
      <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary grid place-items-center flex-shrink-0">
        <Icon className="h-5 w-5" />
      </div>
      <div className="min-w-0">
        <div className="font-medium">{title}</div>
        <div className="text-xs text-muted-foreground mt-0.5">{desc}</div>
      </div>
    </Link>
  );
}

function SkeletonList() {
  return (
    <div className="space-y-2">
      {[0, 1, 2].map((i) => (
        <div key={i} className="h-10 rounded-md bg-muted animate-pulse" />
      ))}
    </div>
  );
}

function EmptyRow({ text }: { text: string }) {
  return <div className="text-xs text-muted-foreground py-6 text-center">{text}</div>;
}