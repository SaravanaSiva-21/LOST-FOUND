import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Calendar, Clock, Package } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { StatusBadge } from "@/components/StatusBadge";

export const Route = createFileRoute("/dashboard/my-claims")({
  component: MyClaims,
});

function MyClaims() {
  const { user } = useAuth();
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | "active" | "resolved">("all");

  const load = async (uid: string) => {
    const { data } = await supabase
      .from("claims")
      .select("*, items(id,case_id,item_name,category,general_location,incident_date,report_type,status)")
      .eq("claimant_id", uid)
      .order("created_at", { ascending: false });
    setRows(data ?? []);
    setLoading(false);
  };

  useEffect(() => {
    if (!user) return;
    load(user.id);
    const ch = supabase
      .channel(`myclaims-${user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "claims", filter: `claimant_id=eq.${user.id}` }, () => load(user.id))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [user?.id]);

  const filtered = rows.filter((c) => {
    if (filter === "resolved") return ["approved", "resolved", "completed"].includes(c.status);
    if (filter === "active") return !["approved", "resolved", "completed", "rejected", "withdrawn"].includes(c.status);
    return true;
  });

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">My Claims</h1>
        <p className="text-sm text-muted-foreground mt-1">Ownership claims you have submitted. Open a claim to view its progress.</p>
      </header>

      <div className="flex gap-2 flex-wrap">
        {[
          { k: "all", label: `All (${rows.length})` },
          { k: "active", label: "Active" },
          { k: "resolved", label: "Resolved" },
        ].map((t) => (
          <button
            key={t.k}
            onClick={() => setFilter(t.k as any)}
            className={`px-3 h-8 rounded-full text-xs font-medium border transition-colors ${
              filter === t.k ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:text-foreground"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground text-sm">Loading...</div>
      ) : filtered.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground text-sm">
          <Package className="h-6 w-6 mx-auto mb-2 opacity-50" />
          You haven't submitted any claims yet.
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((c) => (
            <Link
              key={c.id}
              to="/dashboard/case/$id"
              params={{ id: c.items.id }}
              className="block rounded-xl border border-border bg-card p-4 hover:border-primary/40 transition-colors"
            >
              <div className="flex justify-between gap-3 flex-wrap">
                <div className="min-w-0 flex-1">
                  <div className="text-[11px] font-mono text-muted-foreground">
                    Claim <span className="font-semibold text-foreground">{c.case_id}</span> · Item {c.items.case_id}
                  </div>
                  <div className="font-medium mt-1">{c.items.item_name}</div>
                  <div className="text-xs text-muted-foreground mt-1 flex flex-wrap gap-x-3 gap-y-1">
                    <span>{c.items.category}</span>
                    <span>· {c.items.general_location}</span>
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" /> Submitted {new Date(c.created_at).toLocaleDateString()}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" /> Updated {new Date(c.updated_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>
                <StatusBadge status={c.status} />
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}