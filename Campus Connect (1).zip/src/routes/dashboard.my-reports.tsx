import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Pencil, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { logAudit } from "@/lib/tce";

export const Route = createFileRoute("/dashboard/my-reports")({
  component: MyReports,
});

function MyReports() {
  const { user } = useAuth();
  const nav = useNavigate();
  const [items, setItems] = useState<any[]>([]);
  const [filter, setFilter] = useState<"all" | "lost" | "found">("all");
  const [pendingDelete, setPendingDelete] = useState<any | null>(null);

  const load = async (uid: string) => {
    const { data } = await supabase
      .from("items")
      .select("*")
      .eq("reporter_id", uid)
      .order("created_at", { ascending: false });
    setItems(data ?? []);
  };

  useEffect(() => {
    if (!user) return;
    load(user.id);
  }, [user?.id]);

  const del = async () => {
    if (!pendingDelete) return;
    const it = pendingDelete;
    setPendingDelete(null);
    const { error } = await supabase.from("items").delete().eq("id", it.id);
    if (error) return toast.error(error.message);
    await logAudit({ action: "report_deleted", entity: "item", entity_id: it.id, metadata: { case_id: it.case_id } });
    toast.success(`Report ${it.case_id} deleted`);
    if (user) load(user.id);
  };

  const filtered = filter === "all" ? items : items.filter((i) => i.report_type === filter);
  const lostCount = items.filter((i) => i.report_type === "lost").length;
  const foundCount = items.filter((i) => i.report_type === "found").length;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">My Reports</h1>
        <p className="text-sm text-muted-foreground mt-1">
          All the lost and found items you have reported. You can edit or delete a report while it is pending verification.
        </p>
      </header>

      <div className="flex gap-2">
        <Chip active={filter === "all"} onClick={() => setFilter("all")}>All ({items.length})</Chip>
        <Chip active={filter === "lost"} onClick={() => setFilter("lost")}>Lost ({lostCount})</Chip>
        <Chip active={filter === "found"} onClick={() => setFilter("found")}>Found ({foundCount})</Chip>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground text-sm">
          No reports yet.
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((it) => {
            const canEdit = it.status === "pending_verification";
            return (
              <div key={it.id} className="rounded-xl border border-border bg-card p-4 hover:border-primary/40 transition-colors">
                <div className="flex flex-wrap justify-between gap-3">
                  <Link to="/dashboard/case/$id" params={{ id: it.id }} className="min-w-0 flex-1">
                    <div className="text-[11px] font-mono text-muted-foreground">{it.case_id}</div>
                    <div className="font-medium">{it.item_name}</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {it.category} · {it.general_location} · {it.incident_date}
                    </div>
                    <div className="text-[10px] text-muted-foreground mt-1">
                      Submitted {new Date(it.created_at).toLocaleDateString()}
                    </div>
                  </Link>
                  <div className="flex flex-col items-end gap-2">
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-bold uppercase ${it.report_type === "lost" ? "text-red-600 dark:text-red-400" : "text-emerald-600 dark:text-emerald-400"}`}>
                        {it.report_type}
                      </span>
                      <StatusBadge status={it.status} />
                    </div>
                    {canEdit && (
                      <div className="flex gap-1">
                        <Button size="sm" variant="outline" onClick={() => nav({ to: "/dashboard/edit/$id", params: { id: it.id } })}>
                          <Pencil className="h-3.5 w-3.5 mr-1" /> Edit
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => setPendingDelete(it)}>
                          <Trash2 className="h-3.5 w-3.5 mr-1 text-destructive" /> Delete
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <AlertDialog open={!!pendingDelete} onOpenChange={(o) => !o && setPendingDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this report?</AlertDialogTitle>
            <AlertDialogDescription>
              Case <span className="font-mono">{pendingDelete?.case_id}</span> will be permanently removed. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={del} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`px-3 h-8 rounded-full text-xs font-medium border transition-colors ${
        active
          ? "border-primary bg-primary/10 text-primary"
          : "border-border text-muted-foreground hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );
}