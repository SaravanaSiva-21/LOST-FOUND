import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Bell, CheckCheck, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { NOTIFICATION_LABELS } from "@/lib/tce";

export const Route = createFileRoute("/dashboard/notifications")({
  component: Notifs,
});

function Notifs() {
  const { user } = useAuth();
  const [list, setList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | "unread">("all");

  const load = async (uid: string) => {
    const { data } = await supabase
      .from("notifications")
      .select("*")
      .eq("user_id", uid)
      .order("created_at", { ascending: false })
      .limit(200);
    setList(data ?? []);
    setLoading(false);
  };

  useEffect(() => {
    if (!user) return;
    load(user.id);
    const ch = supabase
      .channel(`notifs-${user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "notifications", filter: `user_id=eq.${user.id}` }, () => load(user.id))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [user?.id]);

  const markAll = async () => {
    if (!user) return;
    await supabase.from("notifications").update({ read: true }).eq("user_id", user.id).eq("read", false);
    toast.success("All notifications marked as read");
  };

  const markOne = async (id: string) => {
    await supabase.from("notifications").update({ read: true }).eq("id", id);
  };

  const del = async (id: string) => {
    await supabase.from("notifications").delete().eq("id", id);
    toast.success("Notification removed");
  };

  const filtered = useMemo(
    () => (filter === "unread" ? list.filter((n) => !n.read) : list),
    [list, filter],
  );
  const unread = list.filter((n) => !n.read).length;

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-start gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold">
            Notifications {unread > 0 && <span className="ml-2 inline-flex items-center justify-center rounded-full bg-primary text-primary-foreground text-xs px-2 py-0.5 align-middle">{unread}</span>}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Recent activity on your reports, claims and handovers.</p>
        </div>
        <Button variant="outline" size="sm" onClick={markAll} disabled={unread === 0} className="gap-2">
          <CheckCheck className="h-4 w-4" /> Mark all read
        </Button>
      </header>

      <div className="flex gap-2">
        {[
          { k: "all", label: `All (${list.length})` },
          { k: "unread", label: `Unread (${unread})` },
        ].map((t) => (
          <button
            key={t.k}
            onClick={() => setFilter(t.k as any)}
            className={`px-3 h-8 rounded-full text-xs font-medium border transition-colors ${
              filter === t.k ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:text-foreground"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground text-sm">Loading...</div>
      ) : filtered.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground text-sm">
          <Bell className="h-6 w-6 mx-auto mb-2 opacity-50" />
          {filter === "unread" ? "You're all caught up." : "No notifications yet."}
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((n) => (
            <div key={n.id} className={`rounded-xl border p-4 group ${n.read ? "border-border bg-card" : "border-primary/40 bg-primary/5"}`}>
              <div className="flex justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                      {NOTIFICATION_LABELS[n.type] ?? n.type}
                    </span>
                    {!n.read && <span className="h-2 w-2 rounded-full bg-primary" />}
                  </div>
                  <div className="font-medium mt-0.5">{n.title}</div>
                  <div className="text-sm text-muted-foreground mt-0.5">{n.message}</div>
                  {n.case_id && <div className="text-[11px] font-mono text-muted-foreground mt-1">{n.case_id}</div>}
                </div>
                <div className="flex flex-col items-end gap-2">
                  <div className="text-[11px] text-muted-foreground whitespace-nowrap">{new Date(n.created_at).toLocaleString()}</div>
                  <div className="flex gap-1 opacity-70 group-hover:opacity-100 transition-opacity">
                    {!n.read && (
                      <button
                        type="button"
                        onClick={() => markOne(n.id)}
                        className="text-[11px] text-muted-foreground hover:text-primary"
                      >
                        Mark read
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => del(n.id)}
                      aria-label="Delete notification"
                      className="text-muted-foreground hover:text-destructive"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}