import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Camera, Loader2, UserCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { compressImage, validateImageFile } from "@/lib/image";

export const Route = createFileRoute("/dashboard/profile")({
  component: Profile,
});

function Profile() {
  const { user, profile } = useAuth();
  const [f, setF] = useState({ full_name: "", register_no: "", department: "", phone: "" });
  const [stats, setStats] = useState({
    lost: 0, found: 0, claims: 0, resolved: 0,
    returned: 0, recovered: 0, successful: 0, bookmarks: 0,
  });
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [pw, setPw] = useState({ next: "", confirm: "" });
  const [pwSaving, setPwSaving] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (profile) {
      setF({
        full_name: profile.full_name ?? "",
        register_no: profile.register_no ?? "",
        department: profile.department ?? "",
        phone: profile.phone ?? "",
      });
    }
  }, [profile]);

  // Signed avatar URL (bucket is private)
  useEffect(() => {
    if (!profile?.photo_url) {
      setAvatarUrl(null);
      return;
    }
    supabase.storage.from("avatars").createSignedUrl(profile.photo_url, 60 * 60).then(({ data }) => {
      setAvatarUrl(data?.signedUrl ?? null);
    });
  }, [profile?.photo_url]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const [lost, found, claims, resolved, returned, successful, bookmarks] = await Promise.all([
        supabase.from("items").select("id", { count: "exact", head: true }).eq("reporter_id", user.id).eq("report_type", "lost"),
        supabase.from("items").select("id", { count: "exact", head: true }).eq("reporter_id", user.id).eq("report_type", "found"),
        supabase.from("claims").select("id", { count: "exact", head: true }).eq("claimant_id", user.id),
        supabase.from("items").select("id", { count: "exact", head: true }).eq("reporter_id", user.id).eq("status", "resolved"),
        // Items I found and returned to owners (resolved found reports of mine)
        supabase.from("items").select("id", { count: "exact", head: true }).eq("reporter_id", user.id).eq("report_type", "found").eq("status", "resolved"),
        supabase.from("claims").select("id", { count: "exact", head: true }).eq("claimant_id", user.id).in("status", ["approved", "resolved", "completed"]),
        supabase.from("bookmarks").select("id", { count: "exact", head: true }).eq("user_id", user.id),
      ]);
      // Items I recovered (my lost reports that were resolved)
      const { count: recovered } = await supabase.from("items").select("id", { count: "exact", head: true })
        .eq("reporter_id", user.id).eq("report_type", "lost").eq("status", "resolved");
      setStats({
        lost: lost.count ?? 0,
        found: found.count ?? 0,
        claims: claims.count ?? 0,
        resolved: resolved.count ?? 0,
        returned: returned.count ?? 0,
        recovered: recovered ?? 0,
        successful: successful.count ?? 0,
        bookmarks: bookmarks.count ?? 0,
      });
    })();
  }, [user?.id]);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSaving(true);
    const { error } = await supabase.from("profiles").update(f).eq("id", user.id);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Profile updated");
  };

  const uploadAvatar = async (file: File) => {
    if (!user) return;
    const err = validateImageFile(file);
    if (err) return toast.error(err);
    setUploading(true);
    try {
      const compressed = await compressImage(file, 512);
      const path = `${user.id}/avatar-${Date.now()}.jpg`;
      const { error: upErr } = await supabase.storage.from("avatars").upload(path, compressed, {
        upsert: true,
        contentType: "image/jpeg",
      });
      if (upErr) throw upErr;
      const { error: dbErr } = await supabase.from("profiles").update({ photo_url: path }).eq("id", user.id);
      if (dbErr) throw dbErr;
      const { data } = await supabase.storage.from("avatars").createSignedUrl(path, 60 * 60);
      setAvatarUrl(data?.signedUrl ?? null);
      toast.success("Profile picture updated");
    } catch (e: any) {
      toast.error(e.message ?? "Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const changePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pw.next.length < 8) return toast.error("Password must be at least 8 characters");
    if (pw.next !== pw.confirm) return toast.error("Passwords do not match");
    setPwSaving(true);
    const { error } = await supabase.auth.updateUser({ password: pw.next });
    setPwSaving(false);
    if (error) return toast.error(error.message);
    setPw({ next: "", confirm: "" });
    toast.success("Password updated");
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Profile</h1>
        <p className="text-sm text-muted-foreground mt-1">Manage your personal information, profile photo, and password.</p>
      </header>

      {/* Photo + basics */}
      <div className="rounded-2xl border border-border bg-card p-6 flex flex-wrap items-center gap-6">
        <div className="relative">
          <div className="h-24 w-24 rounded-full overflow-hidden bg-primary/10 text-primary grid place-items-center">
            {avatarUrl ? (
              <img src={avatarUrl} alt="Profile" className="h-full w-full object-cover" />
            ) : (
              <UserCircle className="h-14 w-14" />
            )}
          </div>
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            disabled={uploading}
            className="absolute -bottom-1 -right-1 h-8 w-8 rounded-full bg-primary text-primary-foreground grid place-items-center shadow-md hover:bg-primary/90 disabled:opacity-60"
            aria-label="Upload profile picture"
          >
            {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Camera className="h-4 w-4" />}
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="image/jpeg,image/jpg,image/png"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              e.currentTarget.value = "";
              if (file) uploadAvatar(file);
            }}
          />
        </div>
        <div className="min-w-0">
          <div className="text-lg font-semibold">{profile?.full_name || "—"}</div>
          <div className="text-sm text-muted-foreground">{profile?.email}</div>
          <div className="text-xs text-muted-foreground mt-1">
            {profile?.department || "Department not set"} · {profile?.register_no || "No register no."}
          </div>
        </div>
      </div>

      {/* Reputation & statistics */}
      <div>
        <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-3">Reputation & Activity</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: "Lost Reports", v: stats.lost },
            { label: "Found Reports", v: stats.found },
            { label: "Claims Submitted", v: stats.claims },
            { label: "Successful Claims", v: stats.successful },
            { label: "Items Returned", v: stats.returned },
            { label: "Items Recovered", v: stats.recovered },
            { label: "Resolved Cases", v: stats.resolved },
            { label: "Bookmarks", v: stats.bookmarks },
          ].map((s) => (
            <div key={s.label} className="rounded-2xl border border-border bg-card p-4">
              <div className="text-2xl font-bold tabular-nums">{s.v}</div>
              <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Edit profile */}
      <form onSubmit={save} className="rounded-2xl border border-border bg-card p-6 space-y-4">
        <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Edit Profile</h2>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-1.5"><Label>Full Name</Label><Input value={f.full_name} onChange={(e) => setF({ ...f, full_name: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>Register No.</Label><Input value={f.register_no} onChange={(e) => setF({ ...f, register_no: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>Department</Label><Input value={f.department} onChange={(e) => setF({ ...f, department: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>Phone</Label><Input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></div>
          <div className="space-y-1.5 md:col-span-2"><Label>Email</Label><Input value={profile?.email ?? ""} disabled /></div>
        </div>
        <Button type="submit" disabled={saving}>{saving ? "Saving..." : "Save changes"}</Button>
      </form>

      {/* Change password */}
      <form onSubmit={changePassword} className="rounded-2xl border border-border bg-card p-6 space-y-4">
        <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Change Password</h2>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label>New Password</Label>
            <Input type="password" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} minLength={8} />
          </div>
          <div className="space-y-1.5">
            <Label>Confirm Password</Label>
            <Input type="password" value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} minLength={8} />
          </div>
        </div>
        <Button type="submit" disabled={pwSaving || !pw.next}>
          {pwSaving ? "Updating..." : "Update password"}
        </Button>
      </form>
    </div>
  );
}