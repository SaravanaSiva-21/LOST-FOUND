import { createFileRoute } from "@tanstack/react-router";
import { ReportForm } from "@/components/ReportForm";

export const Route = createFileRoute("/dashboard/report-found")({
  component: () => (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Report a Found Item</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Provide details of what you found. The admin will match it with lost reports and coordinate handover.
        </p>
      </header>
      <div className="rounded-2xl border border-border bg-card p-6">
        <ReportForm type="found" />
      </div>
    </div>
  ),
});