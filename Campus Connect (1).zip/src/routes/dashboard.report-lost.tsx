import { createFileRoute } from "@tanstack/react-router";
import { ReportForm } from "@/components/ReportForm";

export const Route = createFileRoute("/dashboard/report-lost")({
  component: () => (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Report a Lost Item</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Submit accurate details. Your report goes to admin verification before it becomes visible.
        </p>
      </header>
      <div className="rounded-2xl border border-border bg-card p-6">
        <ReportForm type="lost" />
      </div>
    </div>
  ),
});