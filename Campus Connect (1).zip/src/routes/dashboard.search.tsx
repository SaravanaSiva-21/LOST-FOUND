import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Search as SearchIcon, Clock, Eye } from "lucide-react";
import { Input } from "@/components/ui/input";
import { StatusBadge } from "@/components/StatusBadge";
import { supabase } from "@/integrations/supabase/client";
import { GENERAL_LOCATIONS, ITEM_CATEGORIES, recordHistory } from "@/lib/tce";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/dashboard/search")({
  component: DashboardSearch,
});

function DashboardSearch() {
  const { user } = useAuth();
  const [q, setQ] = useState("");
  const [type, setType] = useState<"" | "lost" | "found">("");
  const [category, setCategory] = useState("");
  const [location, setLocation] = useState("");
  const [items, setItems] = useState<any[]>([]);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [recentViews, setRecentViews] = useState<any[]>([]);
  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    (async () => {
      let query = supabase.from("items").select("id,case_id,item_name,category,general_location,incident_date,status,report_type")
        .in("status", ["approved", "matched", "claimed", "handed_over", "resolved"]);
      if (type) query = query.eq("report_type", type);
      if (category) query = query.eq("category", category);
      if (location) query = query.eq("general_location", location);
      const { data } = await query.order("created_at", { ascending: false }).limit(200);
      setItems(data ?? []);
    })();
  }, [type, category, location]);

  // Record search keyword (debounced) and load history.
  useEffect(() => {
    if (!user || !q.trim()) return;
    if (searchTimer.current) clearTimeout(searchTimer.current);
    searchTimer.current = setTimeout(() => {
      recordHistory({ user_id: user.id, keyword: q.trim(), kind: "search" }).then(loadHistory);
    }, 800);
    return () => { if (searchTimer.current) clearTimeout(searchTimer.current); };
    // eslint-disable-next-line
  }, [q, user?.id]);

  const loadHistory = async () => {
    if (!user) return;
    const [searches, views] = await Promise.all([
      supabase.from("search_history").select("keyword").eq("user_id", user.id).eq("kind", "search").not("keyword", "is", null).order("created_at", { ascending: false }).limit(50),
      supabase.from("search_history").select("created_at,viewed_item_id,item:items(id,case_id,item_name,report_type)").eq("user_id", user.id).eq("kind", "view").order("created_at", { ascending: false }).limit(20),
    ]);
    const seen = new Set<string>();
    const unique = (searches.data ?? []).map((r: any) => r.keyword).filter((k: string) => k && !seen.has(k) && (seen.add(k) as any)).slice(0, 6);
    setRecentSearches(unique);
    const viewSet = new Set<string>();
    const uniqueViews = (views.data ?? []).filter((v: any) => v.item && !viewSet.has(v.item.id) && (viewSet.add(v.item.id) as any)).slice(0, 6);
    setRecentViews(uniqueViews);
  };

  useEffect(() => { loadHistory(); /* eslint-disable-next-line */ }, [user?.id]);

  const filtered = items.filter((i) => {
    if (!q) return true;
    const s = q.toLowerCase();
    return i.item_name.toLowerCase().includes(s) || i.category.toLowerCase().includes(s) || i.case_id.toLowerCase().includes(s);
  });

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Search Items</h1>
        <p className="text-sm text-muted-foreground mt-1">Browse verified reports. Submit a claim on found items you own.</p>
      </header>
      <div className="rounded-2xl border border-border bg-card p-4 space-y-3">
        <div className="relative">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search..." className="pl-10" />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          <select value={type} onChange={(e) => setType(e.target.value as any)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
            <option value="">All Types</option><option value="lost">Lost</option><option value="found">Found</option>
          </select>
          <select value={category} onChange={(e) => setCategory(e.target.value)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
            <option value="">All Categories</option>
            {ITEM_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
          <select value={location} onChange={(e) => setLocation(e.target.value)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
            <option value="">All Locations</option>
            {GENERAL_LOCATIONS.map((l) => <option key={l} value={l}>{l}</option>)}
          </select>
        </div>
      </div>

      {(recentSearches.length > 0 || recentViews.length > 0) && !q && (
        <div className="grid md:grid-cols-2 gap-3">
          {recentSearches.length > 0 && (
            <div className="rounded-2xl border border-border bg-card p-4">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1"><Clock className="h-3.5 w-3.5" /> Recent searches</div>
              <div className="flex flex-wrap gap-1.5">
                {recentSearches.map((k) => (
                  <button key={k} onClick={() => setQ(k)} className="text-xs px-2 py-1 rounded-full border border-border hover:border-primary/40">{k}</button>
                ))}
              </div>
            </div>
          )}
          {recentViews.length > 0 && (
            <div className="rounded-2xl border border-border bg-card p-4">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1"><Eye className="h-3.5 w-3.5" /> Recently viewed</div>
              <div className="space-y-1">
                {recentViews.map((v: any) => (
                  <Link key={v.viewed_item_id} to="/dashboard/case/$id" params={{ id: v.item.id }} className="block text-xs hover:text-primary">
                    <span className="font-mono text-muted-foreground">{v.item.case_id}</span> · {v.item.item_name}
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      <div className="grid gap-3 md:grid-cols-2">
        {filtered.map((it) => (
          <Link key={it.id} to="/dashboard/case/$id" params={{ id: it.id }} className="rounded-xl border border-border bg-card p-4 hover:border-primary/40 transition-colors">
            <div className="flex justify-between items-start">
              <div className="min-w-0">
                <div className="text-[11px] font-mono text-muted-foreground">{it.case_id}</div>
                <div className="font-medium">{it.item_name}</div>
                <div className="text-xs text-muted-foreground mt-1">{it.category} · {it.general_location} · {it.incident_date}</div>
              </div>
              <div className="flex flex-col items-end gap-1">
                <span className={`text-[10px] font-bold uppercase ${it.report_type === "lost" ? "text-red-600 dark:text-red-400" : "text-emerald-600 dark:text-emerald-400"}`}>{it.report_type}</span>
                <StatusBadge status={it.status} />
              </div>
            </div>
          </Link>
        ))}
        {filtered.length === 0 && <div className="col-span-full text-center py-8 text-muted-foreground text-sm">No matches</div>}
      </div>
    </div>
  );
}