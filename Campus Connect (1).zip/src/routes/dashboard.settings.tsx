import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { LogOut, Moon, Sun } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useTheme } from "@/hooks/useTheme";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";

export const Route = createFileRoute("/dashboard/settings")({
  component: Settings,
});

interface NotificationPrefs {
  email_updates: boolean;
  claim_alerts: boolean;
  match_alerts: boolean;
  handover_reminders: boolean;
}

const DEFAULT_PREFS: NotificationPrefs = {
  email_updates: true,
  claim_alerts: true,
  match_alerts: true,
  handover_reminders: true,
};

const PREFS_KEY = "tce-notification-prefs";

function Settings() {
  const { user } = useAuth();
  const { theme, toggle } = useTheme();
  const nav = useNavigate();
  const [prefs, setPrefs] = useState<NotificationPrefs>(DEFAULT_PREFS);
  const [pw, setPw] = useState({ next: "", confirm: "" });
  const [pwSaving, setPwSaving] = useState(false);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(PREFS_KEY);
      if (stored) setPrefs({ ...DEFAULT_PREFS, ...JSON.parse(stored) });
    } catch {}
  }, []);

  const updatePref = (key: keyof NotificationPrefs, value: boolean) => {
    const next = { ...prefs, [key]: value };
    setPrefs(next);
    localStorage.setItem(PREFS_KEY, JSON.stringify(next));
    toast.success("Preferences saved");
  };

  const changePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pw.next.length < 8) return toast.error("Password must be at least 8 characters");
    if (pw.next !== pw.confirm) return toast.error("Passwords do not match");
    setPwSaving(true);
    const { error } = await supabase.auth.updateUser({ password: pw.next });
    setPwSaving(false);
    if (error) return toast.error(error.message);
    setPw({ next: "", confirm: "" });
    toast.success("Password updated");
  };

  const logout = async () => {
    await supabase.auth.signOut();
    nav({ to: "/" });
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-sm text-muted-foreground mt-1">Manage appearance, notifications, and account security.</p>
      </header>

      {/* Appearance */}
      <section className="rounded-2xl border border-border bg-card p-6 space-y-4">
        <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Appearance</h2>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {theme === "dark" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
            <div>
              <div className="text-sm font-medium">Dark mode</div>
              <div className="text-xs text-muted-foreground">Reduces glare in low-light environments.</div>
            </div>
          </div>
          <Switch checked={theme === "dark"} onCheckedChange={toggle} />
        </div>
      </section>

      {/* Notifications */}
      <section className="rounded-2xl border border-border bg-card p-6 space-y-4">
        <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Notification Preferences</h2>
        <PrefRow label="Email updates" desc="Receive email alerts for major case updates." checked={prefs.email_updates} onChange={(v) => updatePref("email_updates", v)} />
        <PrefRow label="Claim alerts" desc="Notify me when someone claims my item." checked={prefs.claim_alerts} onChange={(v) => updatePref("claim_alerts", v)} />
        <PrefRow label="Match alerts" desc="Notify me when a possible match is found." checked={prefs.match_alerts} onChange={(v) => updatePref("match_alerts", v)} />
        <PrefRow label="Handover reminders" desc="Remind me if a case handover is not confirmed within 24 hours." checked={prefs.handover_reminders} onChange={(v) => updatePref("handover_reminders", v)} />
      </section>

      {/* Change password */}
      <form onSubmit={changePassword} className="rounded-2xl border border-border bg-card p-6 space-y-4">
        <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Change Password</h2>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label>New Password</Label>
            <Input type="password" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} minLength={8} />
          </div>
          <div className="space-y-1.5">
            <Label>Confirm Password</Label>
            <Input type="password" value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} minLength={8} />
          </div>
        </div>
        <Button type="submit" disabled={pwSaving || !pw.next}>{pwSaving ? "Updating..." : "Update password"}</Button>
      </form>

      {/* Account */}
      <section className="rounded-2xl border border-border bg-card p-6 space-y-4">
        <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Account</h2>
        <div className="text-sm text-muted-foreground">Signed in as {user?.email}</div>
        <Button variant="outline" onClick={logout} className="text-destructive hover:text-destructive">
          <LogOut className="h-4 w-4 mr-2" /> Log out
        </Button>
      </section>
    </div>
  );
}

function PrefRow({ label, desc, checked, onChange }: { label: string; desc: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div className="min-w-0">
        <div className="text-sm font-medium">{label}</div>
        <div className="text-xs text-muted-foreground">{desc}</div>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}