import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  CheckCircle2, Copy, Handshake, Mail, Phone, Shield, Package, ExternalLink,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { createNotification, logAudit } from "@/lib/tce";

export const Route = createFileRoute("/dashboard/shared-contacts")({
  component: SharedContactsPage,
});

type Row = {
  id: string;
  case_id: string;
  status: string;
  contact_shared_at: string | null;
  finder_confirmed: boolean;
  owner_confirmed: boolean;
  finder_confirmed_at: string | null;
  owner_confirmed_at: string | null;
  resolved_at: string | null;
  item_id: string;
  claimant_id: string;
  claimant: any;
  items: any;
};

function SharedContactsPage() {
  const { user, isAdmin } = useAuth();
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);

  const load = async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from("claims")
      .select(
        "id, case_id, status, contact_shared_at, finder_confirmed, owner_confirmed, finder_confirmed_at, owner_confirmed_at, resolved_at, item_id, claimant_id, claimant:profiles!claims_claimant_id_fkey(full_name,email,phone,department), items(id,case_id,item_name,report_type,status,reporter_id,reporter:profiles!items_reporter_id_fkey(full_name,email,phone,department))",
      )
      .not("contact_shared_at", "is", null)
      .neq("status", "resolved")
      .order("contact_shared_at", { ascending: false });
    setRows((data as any) ?? []);
    setLoading(false);
  };

  useEffect(() => {
    if (!user) return;
    load();
    const ch = supabase
      .channel(`shared-contacts-${user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "claims" }, () => load())
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const confirm = async (row: Row, side: "finder" | "owner", remarks: string) => {
    setBusy(row.id);
    try {
      const nowIso = new Date().toISOString();
      const patch = side === "finder"
        ? { finder_confirmed: true, finder_confirmed_at: nowIso, finder_confirm_remarks: remarks || null }
        : { owner_confirmed: true, owner_confirmed_at: nowIso, owner_confirm_remarks: remarks || null };
      const { error } = await supabase.from("claims").update(patch).eq("id", row.id);
      if (error) throw error;
      const caseRef = row.items?.case_id ?? row.case_id;
      if (side === "finder") {
        await createNotification({
          user_id: row.claimant_id, type: "item_handed_over",
          title: "Finder confirmed handover",
          message: `The finder confirmed handover for case ${caseRef}. Please confirm you have received the item.`,
          case_id: caseRef,
        });
      } else if (row.items?.reporter_id) {
        await createNotification({
          user_id: row.items.reporter_id, type: "item_received",
          title: "Owner confirmed receipt",
          message: `The owner confirmed receipt for case ${caseRef}.`,
          case_id: caseRef,
        });
      }
      await logAudit({ action: side === "finder" ? "finder_confirmed" : "owner_confirmed", entity: "claim", entity_id: row.id });
      toast.success(side === "finder" ? "Handover confirmed" : "Receipt confirmed");
      load();
    } catch (e: any) {
      toast.error(e.message ?? "Failed to confirm");
    } finally {
      setBusy(null);
    }
  };

  const visible = rows.filter((r) => {
    if (isAdmin) return true;
    return r.claimant_id === user?.id || r.items?.reporter_id === user?.id;
  });

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Shared User Details</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Contact details shared by the administrator after your claim was approved. Complete the handover and confirm below.
        </p>
      </header>

      {loading ? (
        <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground text-sm">Loading...</div>
      ) : visible.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground text-sm">
          <Shield className="h-6 w-6 mx-auto mb-2 opacity-50" />
          No shared contacts yet. Once an administrator shares contact details for one of your approved claims, they will appear here.
        </div>
      ) : (
        <div className="space-y-4">
          {visible.map((row) => (
            <SharedCard
              key={row.id}
              row={row}
              currentUserId={user?.id ?? ""}
              isAdmin={isAdmin}
              busy={busy === row.id}
              onConfirm={confirm}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function statusFor(row: Row) {
  if (row.status === "resolved") return { label: "Resolved", tone: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30" };
  if (row.finder_confirmed && row.owner_confirmed) return { label: "Both Confirmed", tone: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30" };
  if (row.finder_confirmed) return { label: "Waiting for Owner Confirmation", tone: "bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/30" };
  if (row.owner_confirmed) return { label: "Waiting for Finder Confirmation", tone: "bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/30" };
  return { label: "Contact Shared", tone: "bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-500/30" };
}

function SharedCard({
  row, currentUserId, isAdmin, busy, onConfirm,
}: {
  row: Row; currentUserId: string; isAdmin: boolean; busy: boolean;
  onConfirm: (row: Row, side: "finder" | "owner", remarks: string) => void;
}) {
  const [remarks, setRemarks] = useState("");
  const [ask, setAsk] = useState<null | "finder" | "owner">(null);

  const isFinderSide = row.items?.reporter_id === currentUserId;
  const isOwnerSide = row.claimant_id === currentUserId;
  const status = statusFor(row);

  // Show the OTHER party's details.
  const other = isFinderSide
    ? { role: "Owner", name: row.claimant?.full_name, email: row.claimant?.email, phone: row.claimant?.phone, dept: row.claimant?.department }
    : isOwnerSide
      ? { role: "Finder", name: row.items?.reporter?.full_name, email: row.items?.reporter?.email, phone: row.items?.reporter?.phone, dept: row.items?.reporter?.department }
      : null;

  return (
    <div className="rounded-2xl border border-border bg-card p-5 space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-[11px] font-mono text-muted-foreground">Case {row.items?.case_id} · Claim {row.case_id}</div>
          <div className="text-lg font-semibold mt-0.5">{row.items?.item_name}</div>
          <div className="text-xs text-muted-foreground mt-1">
            Contact shared on {row.contact_shared_at ? new Date(row.contact_shared_at).toLocaleString() : "—"}
          </div>
        </div>
        <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium ${status.tone}`}>{status.label}</span>
      </div>

      {isAdmin && !isFinderSide && !isOwnerSide ? (
        <div className="grid md:grid-cols-2 gap-3">
          <PartyPanel role="Owner (claimant)" p={row.claimant} />
          <PartyPanel role="Finder (reporter)" p={row.items?.reporter} />
        </div>
      ) : other ? (
        <PartyPanel role={other.role} p={other} />
      ) : null}

      <div className="grid sm:grid-cols-2 gap-2 text-xs">
        <StatusPill label="Finder" confirmed={row.finder_confirmed} at={row.finder_confirmed_at} />
        <StatusPill label="Owner" confirmed={row.owner_confirmed} at={row.owner_confirmed_at} />
      </div>

      {(isFinderSide && !row.finder_confirmed) && (
        ask === "finder" ? (
          <ConfirmBox
            label="Please confirm only after you have physically handed the item over."
            action="Yes, confirm handover"
            remarks={remarks}
            setRemarks={setRemarks}
            busy={busy}
            onCancel={() => setAsk(null)}
            onConfirm={() => { onConfirm(row, "finder", remarks); setAsk(null); setRemarks(""); }}
          />
        ) : (
          <Button size="sm" disabled={busy} onClick={() => setAsk("finder")} className="gap-1">
            <Handshake className="h-4 w-4" /> I have handed over the item
          </Button>
        )
      )}
      {(isOwnerSide && !row.owner_confirmed) && (
        ask === "owner" ? (
          <ConfirmBox
            label="Please confirm only after you have physically received the item."
            action="Yes, confirm receipt"
            remarks={remarks}
            setRemarks={setRemarks}
            busy={busy}
            onCancel={() => setAsk(null)}
            onConfirm={() => { onConfirm(row, "owner", remarks); setAsk(null); setRemarks(""); }}
          />
        ) : (
          <Button size="sm" disabled={busy} onClick={() => setAsk("owner")} className="gap-1">
            <CheckCircle2 className="h-4 w-4" /> I have received the item
          </Button>
        )
      )}

      <div className="pt-1">
        <Link to="/dashboard/case/$id" params={{ id: row.item_id }} className="text-xs text-primary inline-flex items-center gap-1 hover:underline">
          <ExternalLink className="h-3 w-3" /> View full case
        </Link>
      </div>
    </div>
  );
}

function PartyPanel({ role, p }: { role: string; p: any }) {
  if (!p) return null;
  const copy = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success(`${label} copied`);
    } catch {
      toast.error("Copy failed");
    }
  };
  return (
    <div className="rounded-xl border border-border bg-background p-4 space-y-2">
      <div className="text-[11px] uppercase tracking-wider text-muted-foreground">{role}</div>
      <div className="font-semibold">{p.name ?? p.full_name ?? "—"}</div>
      {p.dept ?? p.department ? (
        <div className="text-xs text-muted-foreground">{p.dept ?? p.department}</div>
      ) : null}
      <div className="space-y-1 text-sm">
        {p.email && (
          <div className="flex items-center justify-between gap-2">
            <span className="flex items-center gap-1.5 min-w-0"><Mail className="h-3.5 w-3.5 text-muted-foreground" /> <span className="truncate">{p.email}</span></span>
            <div className="flex gap-1 shrink-0">
              <Button asChild size="sm" variant="ghost" className="h-7 px-2">
                <a href={`mailto:${p.email}`}><Mail className="h-3.5 w-3.5" /></a>
              </Button>
              <Button size="sm" variant="ghost" className="h-7 px-2" onClick={() => copy(p.email, "Email")}>
                <Copy className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        )}
        {p.phone && (
          <div className="flex items-center justify-between gap-2">
            <span className="flex items-center gap-1.5 min-w-0"><Phone className="h-3.5 w-3.5 text-muted-foreground" /> <span className="truncate">{p.phone}</span></span>
            <div className="flex gap-1 shrink-0">
              <Button asChild size="sm" variant="ghost" className="h-7 px-2">
                <a href={`tel:${p.phone}`}><Phone className="h-3.5 w-3.5" /></a>
              </Button>
              <Button size="sm" variant="ghost" className="h-7 px-2" onClick={() => copy(p.phone, "Phone number")}>
                <Copy className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function StatusPill({ label, confirmed, at }: { label: string; confirmed: boolean; at: string | null }) {
  return (
    <div className="rounded-md border border-border bg-background p-2">
      <div className="font-medium">{label}</div>
      <div className={confirmed ? "text-emerald-700 dark:text-emerald-400" : "text-amber-600 dark:text-amber-400"}>
        {confirmed ? "Confirmed" : "Waiting"}
      </div>
      {at && <div className="text-[11px] text-muted-foreground mt-0.5">{new Date(at).toLocaleString()}</div>}
    </div>
  );
}

function ConfirmBox({
  label, action, remarks, setRemarks, busy, onConfirm, onCancel,
}: {
  label: string; action: string; remarks: string; setRemarks: (v: string) => void;
  busy: boolean; onConfirm: () => void; onCancel: () => void;
}) {
  return (
    <div className="rounded-md border border-border bg-background p-3 space-y-2">
      <Label className="text-xs">Remarks (optional)</Label>
      <Textarea rows={2} value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="Any notes about the exchange." />
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="flex gap-2">
        <Button size="sm" onClick={onConfirm} disabled={busy}>{action}</Button>
        <Button size="sm" variant="ghost" onClick={onCancel}>Cancel</Button>
      </div>
    </div>
  );
}