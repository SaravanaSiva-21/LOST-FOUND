import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { DashboardSidebar } from "@/components/DashboardSidebar";

export const Route = createFileRoute("/dashboard")({
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/auth", search: { tab: "login" } });
  },
  component: DashboardLayout,
});

function DashboardLayout() {
  return (
    <AppShell>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-6 grid lg:grid-cols-[240px_1fr] gap-6">
        <DashboardSidebar />
        <div className="min-w-0">
          <Outlet />
        </div>
      </div>
    </AppShell>
  );
}