import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  ArrowRight,
  CheckCircle2,
  Handshake,
  Search,
  Shield,
  Sparkles,
  Users,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { APP_NAME, COLLEGE_NAME } from "@/lib/tce";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/")({
  component: Index,
});

interface RecentItem {
  id: string;
  case_id: string;
  item_name: string;
  category: string;
  general_location: string;
  incident_date: string;
  status: string;
  report_type: "lost" | "found";
}

function Index() {
  const [stats, setStats] = useState({ lost: 0, found: 0, resolved: 0, users: 0 });
  const [recentLost, setRecentLost] = useState<RecentItem[]>([]);
  const [recentFound, setRecentFound] = useState<RecentItem[]>([]);
  const [q, setQ] = useState("");

  useEffect(() => {
    (async () => {
      const [lost, found, resolved, users] = await Promise.all([
        supabase.from("items").select("id", { count: "exact", head: true }).eq("report_type", "lost"),
        supabase.from("items").select("id", { count: "exact", head: true }).eq("report_type", "found"),
        supabase.from("items").select("id", { count: "exact", head: true }).eq("status", "resolved"),
        supabase.from("profiles").select("id", { count: "exact", head: true }),
      ]);
      setStats({
        lost: lost.count ?? 0,
        found: found.count ?? 0,
        resolved: resolved.count ?? 0,
        users: users.count ?? 0,
      });
      const { data: rl } = await supabase
        .from("items")
        .select("id,case_id,item_name,category,general_location,incident_date,status,report_type")
        .eq("report_type", "lost")
        .in("status", ["approved", "matched", "claimed"])
        .order("created_at", { ascending: false })
        .limit(4);
      setRecentLost((rl as RecentItem[]) ?? []);
      const { data: rf } = await supabase
        .from("items")
        .select("id,case_id,item_name,category,general_location,incident_date,status,report_type")
        .eq("report_type", "found")
        .in("status", ["approved", "matched", "claimed"])
        .order("created_at", { ascending: false })
        .limit(4);
      setRecentFound((rf as RecentItem[]) ?? []);
    })();
  }, []);

  return (
    <AppShell>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-background pointer-events-none" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 pt-16 pb-20 md:pt-24 md:pb-28">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/5 px-3 py-1 text-xs font-medium text-primary mb-6">
              <Sparkles className="h-3.5 w-3.5" /> Verified by TCE Administration
            </div>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-foreground">
              Lost something on campus?
              <br />
              <span className="text-primary">We'll help you find it — safely.</span>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground max-w-2xl">
              {APP_NAME} is the official secure portal for {COLLEGE_NAME} to report lost items,
              submit found items, and reunite belongings with their owners under administrator supervision.
            </p>
            <form
              className="mt-8 flex flex-col sm:flex-row gap-3 max-w-2xl"
              onSubmit={(e) => {
                e.preventDefault();
                window.location.href = `/search?q=${encodeURIComponent(q)}`;
              }}
            >
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Search by item name, category, location..."
                  className="pl-10 h-12"
                />
              </div>
              <Button type="submit" size="lg" className="gap-2">
                Search <ArrowRight className="h-4 w-4" />
              </Button>
            </form>
            <div className="mt-4 flex flex-wrap gap-3">
              <Link to="/auth" search={{ tab: "register" }}>
                <Button variant="outline" size="sm">Register with TCE Email</Button>
              </Link>
              <Link to="/auth" search={{ tab: "login" }}>
                <Button variant="ghost" size="sm">Login to report an item</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: "Lost Reports", value: stats.lost },
            { label: "Found Reports", value: stats.found },
            { label: "Resolved Cases", value: stats.resolved },
            { label: "Registered Users", value: stats.users },
          ].map((s) => (
            <div key={s.label} className="rounded-2xl border border-border bg-card p-6">
              <div className="text-3xl font-bold tabular-nums">{s.value}</div>
              <div className="text-sm text-muted-foreground mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-12">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl font-bold">Built for a safe campus</h2>
          <p className="mt-3 text-muted-foreground">
            Every step is verified by the administration. Contact details are never shared without mutual consent.
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { icon: Shield, title: "Admin-Verified", desc: "Every report and every claim is reviewed by the TCE administrator before it becomes visible or actionable." },
            { icon: Users, title: "Whitelisted Access", desc: "Only pre-approved @tce.edu, @student.tce.edu, and @admin.tce.edu accounts can register. No public sign-ups." },
            { icon: Handshake, title: "Safe Handover", desc: "The administrator shares contact details only after verifying the claim. Both parties then confirm the handover directly in the portal." },
          ].map((f) => (
            <div key={f.title} className="rounded-2xl border border-border bg-card p-6 hover:border-primary/40 transition-colors">
              <div className="h-11 w-11 rounded-xl bg-primary/10 text-primary grid place-items-center mb-4">
                <f.icon className="h-5 w-5" />
              </div>
              <div className="font-semibold mb-1">{f.title}</div>
              <p className="text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Recent items */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-12">
        <div className="grid md:grid-cols-2 gap-8">
          <RecentColumn title="Recent Lost Reports" items={recentLost} />
          <RecentColumn title="Recent Found Reports" items={recentFound} />
        </div>
      </section>

      {/* FAQ */}
      <section className="mx-auto max-w-4xl px-4 sm:px-6 py-12">
        <h2 className="text-3xl font-bold mb-8 text-center">Frequently Asked Questions</h2>
        <div className="space-y-3">
          {[
            { q: "Who can register?", a: "Only students and faculty whose @tce.edu or @student.tce.edu email is on the pre-approved whitelist. Administrators use @admin.tce.edu." },
            { q: "Are photos and contact details public?", a: "No. Public visitors only see the item name, category, general location, date, and status. Descriptions, photos, exact location, identification marks, and contact numbers are visible only to the administrator." },
            { q: "How do I claim an item?", a: "Log in, open the found item's page, and submit a claim with details only the owner would know. The administrator reviews your claim before either party is contacted." },
            { q: "How is contact information shared?", a: "After the admin approves a match, both users must independently agree to reveal contact details. Only then are numbers exchanged." },
            { q: "How does the handover work?", a: "Once the administrator verifies your claim, they share both parties' contact details. You then coordinate directly with the other person and both confirm the handover in the portal within 24 hours." },
          ].map((item) => (
            <details key={item.q} className="group rounded-xl border border-border bg-card p-5">
              <summary className="cursor-pointer font-medium flex justify-between items-center">
                {item.q}
                <span className="text-muted-foreground group-open:rotate-45 transition-transform">+</span>
              </summary>
              <p className="mt-3 text-sm text-muted-foreground">{item.a}</p>
            </details>
          ))}
        </div>
      </section>
    </AppShell>
  );
}

function RecentColumn({ title, items }: { title: string; items: RecentItem[] }) {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">{title}</h3>
      {items.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
          <CheckCircle2 className="h-6 w-6 mx-auto mb-2 opacity-50" />
          No verified reports yet.
        </div>
      ) : (
        <ul className="space-y-3">
          {items.map((it) => (
            <li key={it.id}>
              <Link
                to="/item/$id"
                params={{ id: it.id }}
                className="block rounded-xl border border-border bg-card p-4 hover:border-primary/40 transition-colors"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="font-medium truncate">{it.item_name}</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {it.category} · {it.general_location} · {it.incident_date}
                    </div>
                    <div className="text-[11px] font-mono text-muted-foreground mt-1">{it.case_id}</div>
                  </div>
                  <StatusBadge status={it.status} />
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
