import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, Bookmark, BookmarkCheck, Calendar, LogIn, MapPin, Package } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/StatusBadge";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { recordHistory } from "@/lib/tce";

export const Route = createFileRoute("/item/$id")({
  head: () => ({
    meta: [
      { title: "Item — TCE Lost & Found" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ItemPage,
});

function ItemPage() {
  const { id } = Route.useParams();
  const nav = useNavigate();
  const { user } = useAuth();
  const [item, setItem] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [bookmarkId, setBookmarkId] = useState<string | null>(null);
  const [bmBusy, setBmBusy] = useState(false);

  useEffect(() => {
    supabase.from("items").select("*").eq("id", id).maybeSingle().then(({ data }) => {
      setItem(data);
      setLoading(false);
    });
  }, [id]);

  // Record item view and load current bookmark state.
  useEffect(() => {
    if (!user || !item) return;
    recordHistory({ user_id: user.id, viewed_item_id: item.id, kind: "view" });
    supabase.from("bookmarks").select("id").eq("user_id", user.id).eq("item_id", item.id).maybeSingle().then(({ data }) => {
      setBookmarkId(data?.id ?? null);
    });
  }, [user?.id, item?.id]);

  const toggleBookmark = async () => {
    if (!user || !item) return;
    setBmBusy(true);
    if (bookmarkId) {
      await supabase.from("bookmarks").delete().eq("id", bookmarkId);
      setBookmarkId(null);
      toast.success("Bookmark removed");
    } else {
      const { data } = await supabase.from("bookmarks").insert({ user_id: user.id, item_id: item.id }).select("id").maybeSingle();
      setBookmarkId(data?.id ?? null);
      toast.success("Bookmarked");
    }
    setBmBusy(false);
  };

  if (loading) return <AppShell><div className="text-center py-16 text-muted-foreground">Loading...</div></AppShell>;
  if (!item) return <AppShell><div className="text-center py-16 text-muted-foreground">Item not found or not yet verified.</div></AppShell>;

  return (
    <AppShell>
      <div className="mx-auto max-w-3xl px-4 sm:px-6 py-8">
        <Link to="/search" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft className="h-4 w-4" /> Back to search
        </Link>
        <div className="rounded-2xl border border-border bg-card p-6 space-y-5">
          <div className="flex justify-between items-start gap-4">
            <div>
              <div className="text-xs font-mono text-muted-foreground">{item.case_id}</div>
              <h1 className="text-2xl font-bold mt-1">{item.item_name}</h1>
              <div className="mt-2 flex flex-wrap gap-2">
                <span className={`text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded ${item.report_type === "lost" ? "bg-red-500/10 text-red-600 dark:text-red-400" : "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"}`}>
                  {item.report_type}
                </span>
                <StatusBadge status={item.status} />
              </div>
            </div>
            {user && (
              <button
                onClick={toggleBookmark}
                disabled={bmBusy}
                aria-label={bookmarkId ? "Remove bookmark" : "Bookmark this item"}
                className={`h-10 w-10 grid place-items-center rounded-full border transition-colors ${
                  bookmarkId ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:text-foreground"
                } disabled:opacity-50`}
              >
                {bookmarkId ? <BookmarkCheck className="h-5 w-5" /> : <Bookmark className="h-5 w-5" />}
              </button>
            )}
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <Info label="Category" value={item.category} />
            <Info label="Date" value={item.incident_date} icon={<Calendar className="h-3.5 w-3.5" />} />
            <Info label="General Location" value={item.general_location} icon={<MapPin className="h-3.5 w-3.5" />} />
            <Info label="Status" value={item.status} />
          </div>
          <div className="rounded-lg border border-dashed border-border p-4 text-xs text-muted-foreground">
            Photos, descriptions, contact numbers, exact locations, and identification marks are visible only to the administrator to protect user privacy.
          </div>
          {item.report_type === "found" ? (
            user ? (
              <Button className="w-full" onClick={() => nav({ to: "/dashboard/case/$id", params: { id: item.id } })}>
                <Package className="h-4 w-4 mr-2" /> This might be mine — Submit a claim
              </Button>
            ) : (
              <Button className="w-full gap-2" onClick={() => nav({ to: "/auth", search: { tab: "login" } })}>
                <LogIn className="h-4 w-4" /> Sign in to submit a claim
              </Button>
            )
          ) : user ? (
            <Button className="w-full gap-2" onClick={() => nav({ to: "/dashboard/report-found" })}>
              <Package className="h-4 w-4" /> I found this — Report a Found Item
            </Button>
          ) : (
            <Button className="w-full gap-2" onClick={() => nav({ to: "/auth", search: { tab: "login" } })}>
              <LogIn className="h-4 w-4" /> Sign in to help return this item
            </Button>
          )}
        </div>
      </div>
    </AppShell>
  );
}

function Info({ label, value, icon }: { label: string; value: string; icon?: React.ReactNode }) {
  return (
    <div>
      <div className="text-[11px] uppercase tracking-wider text-muted-foreground flex items-center gap-1">
        {icon} {label}
      </div>
      <div className="mt-1 font-medium">{value}</div>
    </div>
  );
}