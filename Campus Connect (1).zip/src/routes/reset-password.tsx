import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { z } from "zod";
import { AppShell } from "@/components/AppShell";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Reset Password — TCE Lost & Found" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ResetPassword,
});

const pwSchema = z
  .string()
  .min(8, "At least 8 characters")
  .regex(/[A-Z]/, "Uppercase required")
  .regex(/[a-z]/, "Lowercase required")
  .regex(/[0-9]/, "Number required")
  .regex(/[^A-Za-z0-9]/, "Special char required");

function ResetPassword() {
  const nav = useNavigate();
  const [ready, setReady] = useState(false);
  const [pw, setPw] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Supabase places recovery info in hash — presence of type=recovery means valid.
    const hash = window.location.hash;
    setReady(hash.includes("type=recovery") || hash.includes("access_token"));
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pw !== confirm) return toast.error("Passwords do not match");
    try {
      pwSchema.parse(pw);
    } catch (err: any) {
      return toast.error(err.errors?.[0]?.message ?? "Invalid password");
    }
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password: pw });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Password updated. Please sign in again.");
    await supabase.auth.signOut();
    nav({ to: "/auth", search: { tab: "login" } });
  };

  return (
    <AppShell>
      <div className="min-h-[70vh] grid place-items-center px-4 py-12">
        <div className="w-full max-w-md rounded-2xl border border-border bg-card p-6">
          <div className="text-center mb-6">
            <div className="inline-flex mx-auto mb-3">
              <Logo size={48} />
            </div>
            <h1 className="text-xl font-semibold">Reset your password</h1>
          </div>
          {!ready ? (
            <p className="text-sm text-muted-foreground text-center">
              This page opens from the password reset email. If you arrived here directly,
              please request a reset link from the login page.
            </p>
          ) : (
            <form onSubmit={submit} className="space-y-4">
              <div className="space-y-1.5">
                <Label>New Password</Label>
                <Input type="password" value={pw} onChange={(e) => setPw(e.target.value)} required />
              </div>
              <div className="space-y-1.5">
                <Label>Confirm Password</Label>
                <Input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} required />
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "Updating..." : "Update password"}
              </Button>
            </form>
          )}
        </div>
      </div>
    </AppShell>
  );
}