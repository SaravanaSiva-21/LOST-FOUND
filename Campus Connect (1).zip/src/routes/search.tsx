import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Search as SearchIcon, Filter } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/StatusBadge";
import { supabase } from "@/integrations/supabase/client";
import { GENERAL_LOCATIONS, ITEM_CATEGORIES } from "@/lib/tce";

export const Route = createFileRoute("/search")({
  head: () => ({
    meta: [
      { title: "Search Items — TCE Lost & Found" },
      { name: "description", content: "Search verified lost and found reports across the TCE campus." },
    ],
  }),
  validateSearch: (s: Record<string, unknown>) => ({
    q: (s.q as string) ?? "",
  }),
  component: SearchPage,
});

interface Row {
  id: string;
  case_id: string;
  item_name: string;
  category: string;
  general_location: string;
  incident_date: string;
  status: string;
  report_type: "lost" | "found";
  created_at: string;
}

function SearchPage() {
  const { q: initialQ } = Route.useSearch();
  const [q, setQ] = useState(initialQ);
  const [category, setCategory] = useState("");
  const [location, setLocation] = useState("");
  const [type, setType] = useState<"" | "lost" | "found">("");
  const [sort, setSort] = useState<"newest" | "oldest">("newest");
  const [items, setItems] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 12;

  // Reset to page 1 whenever filters or query change
  useEffect(() => {
    setPage(1);
  }, [q, category, location, type, sort]);

  useEffect(() => {
    (async () => {
      setLoading(true);
      let query = supabase
        .from("items")
        .select("id,case_id,item_name,category,general_location,incident_date,status,report_type,created_at")
        .in("status", ["approved", "matched", "claimed", "handed_over", "resolved"]);
      if (category) query = query.eq("category", category);
      if (location) query = query.eq("general_location", location);
      if (type) query = query.eq("report_type", type);
      query = query.order("created_at", { ascending: sort === "oldest" });
      const { data } = await query.limit(200);
      setItems((data as Row[]) ?? []);
      setLoading(false);
    })();
  }, [category, location, type, sort]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return items;
    return items.filter(
      (i) =>
        i.item_name.toLowerCase().includes(s) ||
        i.category.toLowerCase().includes(s) ||
        i.general_location.toLowerCase().includes(s) ||
        i.case_id.toLowerCase().includes(s)
    );
  }, [items, q]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageItems = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  return (
    <AppShell>
      <div className="mx-auto max-w-6xl px-4 sm:px-6 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Search Verified Reports</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Only admin-approved reports are shown. Full descriptions and contact details are visible after login and admin approval.
          </p>
        </div>
        <div className="rounded-2xl border border-border bg-card p-4 mb-6 space-y-3">
          <div className="relative">
            <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search item name, category, case ID..." className="pl-10 h-11" />
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <select value={type} onChange={(e) => setType(e.target.value as any)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
              <option value="">All Types</option>
              <option value="lost">Lost</option>
              <option value="found">Found</option>
            </select>
            <select value={category} onChange={(e) => setCategory(e.target.value)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
              <option value="">All Categories</option>
              {ITEM_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
            <select value={location} onChange={(e) => setLocation(e.target.value)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
              <option value="">All Locations</option>
              {GENERAL_LOCATIONS.map((l) => <option key={l} value={l}>{l}</option>)}
            </select>
            <select value={sort} onChange={(e) => setSort(e.target.value as any)} className="h-10 px-3 rounded-md border border-input bg-background text-sm">
              <option value="newest">Newest first</option>
              <option value="oldest">Oldest first</option>
            </select>
          </div>
          <div className="flex justify-between text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><Filter className="h-3 w-3" /> {filtered.length} result{filtered.length === 1 ? "" : "s"}</span>
            <Button variant="ghost" size="sm" onClick={() => { setQ(""); setCategory(""); setLocation(""); setType(""); setSort("newest"); }}>
              Clear filters
            </Button>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12 text-muted-foreground">Loading...</div>
        ) : filtered.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground">
            No verified reports match your filters yet.
          </div>
        ) : (
          <>
          <div className="grid gap-3 md:grid-cols-2">
            {pageItems.map((it) => (
              <Link
                key={it.id}
                to="/item/$id"
                params={{ id: it.id }}
                className="rounded-xl border border-border bg-card p-4 hover:border-primary/40 transition-colors"
              >
                <div className="flex justify-between items-start gap-3">
                  <div className="min-w-0">
                    <div className="text-xs font-mono text-muted-foreground mb-1">{it.case_id}</div>
                    <div className="font-semibold truncate">{it.item_name}</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {it.category} · {it.general_location} · {it.incident_date}
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <span className={`text-[10px] font-bold uppercase tracking-wider ${it.report_type === "lost" ? "text-red-600 dark:text-red-400" : "text-emerald-600 dark:text-emerald-400"}`}>
                      {it.report_type}
                    </span>
                    <StatusBadge status={it.status} />
                  </div>
                </div>
              </Link>
            ))}
          </div>
          {totalPages > 1 && (
            <div className="flex items-center justify-between mt-6">
              <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}>
                Previous
              </Button>
              <span className="text-xs text-muted-foreground">
                Page {page} of {totalPages}
              </span>
              <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page === totalPages}>
                Next
              </Button>
            </div>
          )}
          </>
        )}
      </div>
    </AppShell>
  );
}